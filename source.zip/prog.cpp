#include "stdafx.h"
#include "afxdtctl.h"

#include "cpw.h"  
#include "cpwdefs.h"  
#include "AbSpan.h"
#include "prog.h" 
#include "cpwDoc.h"
#include "cpwDb.h"
#include "cpwExt.h"
#include "cache.h"            
#include "ProgMaq.h"
#include "OrdMaq.h"
#include "strstrea.h"
#include "DlgDebug.h"
#include "OrdenDlg.h"  

#include "obarrord.h"

#include "strstrea.h"
#include "fstream.h"


IMPLEMENT_SERIAL(CProg, CObject, 1)
 
CProg::CProg()
{
	CTime FecIni = CTime::GetCurrentTime();  
	FecIni = CTime(FecIni.GetYear(), FecIni.GetMonth(), FecIni.GetDay(), TK_TURNO3_FIN,0,0);
    CTime FecFin = FecIni;
	FecFin = AddDays(FecFin, TK_MIN_PROG);
    m_Abs = CAbSpan(FecIni , FecFin);
	m_lTimeScale = (long) AfxGetApp()->GetProfileInt("Valores Iniciales", "Escala", TK_ESCALA_DEF);
    ASSERT(g_pCache); 
    m_pArrPMs = new CObArray();         
    ASSERT(m_pArrPMs);
    CStringArray ArrMaquinas;
	if (g_pCache->GetArrMaquinas(ArrMaquinas))
	{                                
		for (int i=0; i< ArrMaquinas.GetSize(); i++)
		{                                  
			CProgMaq* pPM = new CProgMaq(ArrMaquinas[i]);
			pPM->SetpBufMaq( g_pCache->AddMaquina( ArrMaquinas[i] ) );  
			AddPM(pPM);
		}
	} else 
	{
		AfxMessageBox(STRID(IDS_ERR_NOMAQAB));
		return;
	}  
	m_pArrOMs = new CObArrayOrd(&OMC_Bigger, &OMC_Equal);
}

CProg::~CProg()
{                  
	ClearPMs();    
	delete m_pArrPMs;
	ClearOMs();
	delete m_pArrOMs;
} 

void
CProg::ClearPMs()
{
	int i;
	ASSERT_VALID (m_pArrPMs);
	for ( i=0; i< m_pArrPMs->GetSize(); i++)
	{                                  
		CProgMaq* pPM = (CProgMaq *) ((*m_pArrPMs)[i]);
		ASSERT( pPM->IsKindOf( RUNTIME_CLASS( CProgMaq ) ) );
		delete pPM;
	}
	m_pArrPMs->RemoveAll();
}

void
CProg::ClearOMs()
{
	int i;
	ASSERT_VALID (m_pArrOMs);
	for ( i=0; i< m_pArrOMs->GetSize(); i++)
	{                                  
		COMC* pOM = (COMC *) ((*m_pArrOMs)[i]);
		ASSERT( pOM->IsKindOf( RUNTIME_CLASS( COMC ) ) );
		// Borramos las OMComb
		for (int j = 0; j < pOM->m_pArrCOMComb->GetSize() ; j++)
		{
			COMComb* pOMComb = (COMComb*) pOM->m_pArrCOMComb->GetAt(j);
			delete pOMComb;
		}
		delete pOM->m_pArrCOMComb;
		if (pOM->m_pArrOM != NULL) delete pOM->m_pArrOM;
		delete pOM;
	}
	m_pArrOMs->RemoveAll();
}

void
CProg::RelinkAll()
{
	for(int i=0; i< GetNumPM() ; i++)
	{
		CProgMaq* pPM = GetpPM(i);
		ASSERT_VALID(pPM);
		pPM->Relink();
		for (int j=0; j< pPM->GetNumOM() ; j++)
		{
			COrdMaq* pOM = pPM->GetpOM(j);
			ASSERT_VALID(pOM);
			pOM->Relink();
		}
	}
}
// Realizamos una copia de un CProg existente. Todos los objetos dependientes de �l
// (PMs y OMs) deben ser copiados.
CProg&
CProg::operator =(const CProg& p_Prog)
{
	ClearPMs();
	SetFecIni(p_Prog.GetFecIni());
	SetFecFin(p_Prog.GetFecFin());
	m_lTimeScale = p_Prog.GetTimeScale();
    for (int i=0; i< p_Prog.GetNumPM(); i++)
	{                               
		CProgMaq* pPMCop = p_Prog.GetpPM(i);
		CProgMaq* pPM = new CProgMaq(pPMCop->GetsID());
		pPM->SetpBufMaq( g_pCache->AddMaquina( pPMCop->GetsID() ) );  
		AddPM(pPM);
		*pPM = *pPMCop;
	}
	return *this;
}

// Borra la ProgMaq indicada por el �ndice p_iPM.
void 
CProg::DeletePM( int p_iPM )
{
	CProgMaq* pPM = GetpPM(p_iPM);
	ASSERT_VALID(pPM);
	delete pPM;
	m_pArrPMs->RemoveAt(p_iPM);
}

// Mueve una ProgMaq a la izquierda o a la derecha. Devuelve False si no puede.
BOOL
CProg::MovePM( CProgMaq* p_pPM, enum EDirMove p_eDirMove)
{
	int iPM = Find(p_pPM);
	if (iPM == INT_MAX) return FALSE;
	// Calculamos el indice de fin. 
	int iPMEnd = (p_eDirMove == Left  ? iPM - 1 : iPM + 1); 

	if (iPMEnd < 0 || iPMEnd >= GetNumPM()) return FALSE;
	CString sGFH = p_pPM->GetsGFH();
	
	CProgMaq* pPMSubs = GetpPM(iPMEnd);

	if (sGFH != pPMSubs->GetsGFH()) return FALSE; // Los GFHs deben ser continuos. No se
												  // puede mover tras una maquina de otro.

	m_pArrPMs->RemoveAt(iPM);
	m_pArrPMs->InsertAt(iPMEnd, p_pPM);

	return TRUE;
}

void
CProg::SwitchPM( int p_iInd, int p_iInd2 )
{
	CProgMaq* pPM = (CProgMaq*) m_pArrPMs->GetAt(p_iInd);
	CProgMaq* pPM2 = (CProgMaq*) m_pArrPMs->GetAt(p_iInd2);

	m_pArrPMs->SetAt( p_iInd , pPM2);
	m_pArrPMs->SetAt( p_iInd2 , pPM);
}
		
void
CProg::UnselectAll()
{
	int numPM = GetNumPM();
	for (int i = 0; i < numPM; i++)
	{
		CProgMaq* pMaq = GetpPM(i);
		ASSERT_VALID(pMaq);
		int numOM = pMaq->GetNumOM();     
		for (int j=0; j< numOM; j++)
		{                                   
			COrdMaq* pOM = pMaq->GetpOM(j);
			ASSERT_VALID(pOM);
			pOM->SetBSelected(FALSE);
		}
	}
}

void CProg::Serialize(CArchive& ar)
{                     
	long lVoid = 0;
	double dVoid = 0;
	CTime FecVoid;
	CString sVoid = "";

	ASSERT_VALID(g_pCache);

	CObject::Serialize(ar);
	
	if (!ar.IsStoring()) ClearPMs();
	
	m_Abs.Serialize(ar);
	m_pArrPMs->Serialize(ar);   

	// Escribimos los miembros de Prog
	if (ar.IsStoring())
	{        
  		ar << m_lTimeScale;
		ar << m_lNumDias;
		
		ar << lVoid;
		ar << dVoid;
		ar << FecVoid;
		ar << sVoid;
		ar << lVoid;
		ar << dVoid;
		ar << FecVoid;
		ar << sVoid;
		ar << lVoid;
		ar << dVoid;
		ar << FecVoid;
		ar << sVoid;
		ar << lVoid;
		ar << dVoid;
		ar << FecVoid;
		ar << sVoid;
  	}
	else
	{
		ar >> m_lTimeScale;
		ar >> m_lNumDias;

		ar >> lVoid;
		ar >> dVoid;
		ar >> FecVoid;
		ar >> sVoid;
		ar >> lVoid;
		ar >> dVoid;
		ar >> FecVoid;
		ar >> sVoid;
		ar >> lVoid;
		ar >> dVoid;
		ar >> FecVoid;
		ar >> sVoid;
		ar >> lVoid;
		ar >> dVoid;
		ar >> FecVoid;
		ar >> sVoid;
		
	}
	
	if (!ar.IsStoring())
	{
		ASSERT_VALID (m_pArrPMs);
		for (int i=0; i< m_pArrPMs->GetSize(); i++)
		{                                  
			CProgMaq* pPM = (CProgMaq *) ((*m_pArrPMs)[i]);
			ASSERT( pPM->IsKindOf( RUNTIME_CLASS( CProgMaq ) ) );
			pPM->SetProg(this);
		}                     
		
	}
}

void
CProg::RecalcInacts()
{                                                               
	for (int i=0; i< GetNumPM(); i++)
	{                                  
		CProgMaq* pPM = GetpPM(i);
    	g_pCache->AssignInacts(*pPM);
	}          
}

void
CProg::Recalc()
{             
	// Hay que recalcular al rev�s para que los m�rgenes salgan bien
	for (int i=GetNumPM() - 1; i>= 0; i--)
	{                                  
		CProgMaq* pPM = GetpPM(i);
    	pPM->Recalc();
	}  

	CalcArrOMC();
	CalcMezclas();
	// Ahora recalculamos las OFs
	
	g_pCache->RecalcOFs(this);
	
	CCpwDoc* pDoc = GetpDoc();
	
	pDoc->SetModifiedFlag();
	pDoc->UpdateAllViews(NULL);
}

void
CProg::CalcMezclas()
{
		
	CObArray* pArrBufArt = g_pCache->GetArrBufArt();
	int iLim = pArrBufArt->GetSize();
	// Hacemos un ciclo por todos los Art�culos
	for(int i = 0; i < iLim; i++)
	{
		CBufArticulo* pBufArt = (CBufArticulo*) pArrBufArt->GetAt(i);
		ASSERT( pBufArt->IsKindOf( RUNTIME_CLASS( CBufArticulo ) ) );
		
		// buscamos la Orden combinada que le corresponde
		COMC* pOMC = GetpOMC(pBufArt->m_sID);
		if (!pOMC) continue;
		// La cantidad de piezas que se pueden fabricar con la mezcla es
		if (pBufArt->m_lPeso <= 0) continue;
		long lCant = pBufArt->GetlCantMezcla() * 1000 / pBufArt->m_lPeso;
		// Si s�lo hay una orden y no tiene inactividades, calculamos
		
		if (pOMC->m_pOM && pOMC->m_pArrCOMComb->GetSize() < 2)
		{
			CProgMaq* pPM = pOMC->m_pOM->GetpPM();
			pOMC->m_pOM->SetTsMezcla(pOMC->m_pOM->CalcTsMezcla(lCant));
			continue;
		}
		// En caso contrario, vamos descontando por la matriz de solapados
		// Repartimos la cantidad entre las OMs
		(void) pOMC->ReparteCant(lCant);
		// Ahora tenemos la cantidad en el m_lAux de cada OM
		// Hacemos un ciclo por las OMs afectadas a ver qu� hay
		if (pOMC->m_pOM)
		{
			long lRepCant = pOMC->m_pOM->m_lAux;
			if (lRepCant <= 0) continue;
			pOMC->m_pOM->SetTsMezcla(pOMC->m_pOM->CalcTsMezcla(lRepCant));
		} else
		{
			for (int i=0; i < pOMC->m_pArrOM->GetSize(); i++)
			{
				COrdMaq* pOM = (COrdMaq*) pOMC->m_pArrOM->GetAt(i);
				long lRepCant = pOM->m_lAux;
				if (lRepCant <= 0) continue;
				pOM->SetTsMezcla(pOM->CalcTsMezcla(lRepCant));
			}
		}

		// Debug
		/*
		int iNumOM;
		CDlgDebug DlgD;
		if (pOMC->m_pArrOM)
		{
			iNumOM = pOMC->m_pArrOM->GetSize();
			for (int iD=0; iD< iNumOM; iD++)
			{
				COrdMaq* pOM = (COrdMaq*) pOMC->m_pArrOM->GetAt(iD);
				ASSERT( pOM->IsKindOf( RUNTIME_CLASS( COrdMaq ) ) );

				if (pOM->GetlPeso() <= 0) continue;
				long lCant = pBufArt->GetlCantMezcla() * 1000 / pOM->GetlPeso();
	
				CString sMsg;
				sMsg.Format(" %s ; %s - %s" 
					, FormatLong(lCant, 10)
					, pOM->GetsMaquina()
					, FormatLong(pOM->m_lAux, 10)
				);
				
				DlgD.m_ArrStr.Add(sMsg);
				
			}
		} 	if (DlgD.DoModal() != IDOK) return ;
		*/
		
		// End Debug

	}
}
// Devuelve el numero de ProgMaq en Prog.
int
CProg::GetNumPM() const
{ 
	if (m_pArrPMs) return m_pArrPMs->GetSize();
	else return 0;
}   

CProgMaq* 
CProg::GetpPM(int p_NumMaq) const
{                               
	ASSERT_VALID(m_pArrPMs);
	return (CProgMaq*) m_pArrPMs->GetAt(p_NumMaq);
}  

CProgMaq*
CProg::FindMaq(const char* p_ID) const
{
	for(int i=0; i<m_pArrPMs->GetSize(); i++)
	{
		CProgMaq* pPM = (CProgMaq *) m_pArrPMs->GetAt(i);
		ASSERT( pPM->IsKindOf( RUNTIME_CLASS( CProgMaq ) ) );		
		if (pPM->GetsID() == p_ID) return pPM;
	}                                        
	return NULL;
}            

CProgMaq*
CProg::FindMaqByDesc(const char* p_sDesc) const
{
	for(int i=0; i<m_pArrPMs->GetSize(); i++)
	{
		CProgMaq* pPM = (CProgMaq *) m_pArrPMs->GetAt(i);
		ASSERT( pPM->IsKindOf( RUNTIME_CLASS( CProgMaq ) ) );		
		if (pPM->GetsDescripcion() == p_sDesc) return pPM;
	}                                        
	return NULL;
}            


// Obtenemos un array de OMs ordenados por m�quinas
int CProg::GetArrMaqOM(CObArray& p_ArrOM)
{
	p_ArrOM.RemoveAll();             
	for(int i=0; i< GetNumPM() ; i++)
	{
		CProgMaq* pPM = GetpPM(i);
		ASSERT_VALID(pPM);
		for (int j=0; j< pPM->GetNumOM() ; j++)
		{
			COrdMaq* pOM = pPM->GetpOM(j);
			ASSERT_VALID(pOM);
			p_ArrOM.Add(pOM);
		}
	}
	return p_ArrOM.GetSize();
}

// Obtenemos un array de BufLisMezclas para la consulta de necesidades externas de mezclas
int CProg::GetArrMezExt(CObArray& p_ArrMezExt)
{
	p_ArrMezExt.RemoveAll();             
	for(int i=0; i< GetNumPM() ; i++)
	{
		CProgMaq* pPM = GetpPM(i);
		if (pPM->GetsIDLocal() != "1")
		{
			for (int j=0; j< pPM->GetNumOM() ; j++)
			{
				COrdMaq* pOM = pPM->GetpOM(j);
				ASSERT_VALID(pOM);
				CBufOF* pBufOF = g_pCache->FindOFArt(pOM->GetsID());
				
				CBufLisMezclas* pBufLisMezclas = new CBufLisMezclas;
				pBufLisMezclas->m_sIDLocal = pPM->GetsIDLocal();
				pBufLisMezclas->m_sIDArticulo = pOM->GetsID();
				if (pBufOF)
					pBufLisMezclas->m_sIDCliente = pBufOF->m_sNomcli;
				else
					pBufLisMezclas->m_sIDCliente = "";
				pBufLisMezclas->m_lMezcla = pOM->GetlNecMezcla();
				pBufLisMezclas->m_FecIni = pOM->GetFecIni();
				pBufLisMezclas->m_lCant = pOM->GetlCantidad();
				p_ArrMezExt.Add(pBufLisMezclas);
			}
		}
	}
	return p_ArrMezExt.GetSize();
}

// Obtenemos un array de OMs que tengan la misma OF
int	
CProg::GetArrOM( CObArray* p_pArrOM, CBufOF* p_pOF )
{
	ASSERT_VALID(p_pArrOM);
	ASSERT_VALID(p_pOF);
	p_pArrOM->RemoveAll();             
	int retVal = 0;
	for(int i=0; i< GetNumPM() ; i++)
	{
		CProgMaq* pPM = GetpPM(i);
		ASSERT_VALID(pPM);
		for (int j=0; j< pPM->GetNumOM() ; j++)
		{
			COrdMaq* pOM = pPM->GetpOM(j);
			ASSERT_VALID(pOM);
			if (pOM->GetpOF() == p_pOF->GetID())			
			{
				retVal++;
				p_pArrOM->Add(pOM);
			}
		}
	}
	return retVal;
}
// Obtenemos un array de OMs que tengan el mismo articulo
int	
CProg::GetArrOMArt( CObArray* p_pArrOM, const CString p_sIDArt )
{
	ASSERT_VALID(p_pArrOM);
	p_pArrOM->RemoveAll();             
	int retVal = 0;
	for(int i=0; i< GetNumPM() ; i++)
	{
		CProgMaq* pPM = GetpPM(i);
		ASSERT_VALID(pPM);
		for (int j=0; j< pPM->GetNumOM() ; j++)
		{
			COrdMaq* pOM = pPM->GetpOM(j);
			ASSERT_VALID(pOM);
			if (p_sIDArt == pOM->GetsID())
			{
				retVal++;
				p_pArrOM->Add(pOM);
			}
		}
	}
	return retVal;
}


void 
CProg::MoveOrdMaq(CProgMaq* p_pPM, COrdMaq* p_pOM, int pInd)
{
	CProgMaq* pPM = p_pOM->GetpPM();
	ASSERT_VALID(pPM);
	int oInd = 0;
	if (pPM == p_pPM && pInd < p_pOM->PMIndex() ) pInd++;
	if (pPM)
	{
		oInd = pPM->Find(p_pOM);
		if (oInd > -1) pPM->RemoveAt(oInd);
		else 
		{
			TRACE("Error, no encontrada OM en CProg::MoveOrdMaq()");
			return;
		}
	}
	if (pPM == p_pPM) oInd = min(oInd, pInd);
	p_pPM->InsertOM(p_pOM, pInd);
	pPM->Recalc();
	if (pPM != p_pPM) p_pPM->Recalc();
}

  
COrdMaq*
CProg::GetPrevOM(const COrdMaq* p_pOM, const char* p_sGFH) const
{
	// Obtenemos el �ndice de la m�quina de la OrdMaq para empezar a
	// buscar a la derecha del mismo
	CProgMaq* pPM = p_pOM->GetpPM();
	if (!pPM) return NULL;
	CString sGFH = pPM->GetsGFH();
	int ind = Find(pPM);
	if (ind == INT_MAX) return NULL;
	// Calculamos el l�mite y a�adimos uno para buscar m�s a la derecha
	int lim = GetNumPM();
	ind++;
	//long UniqID = xpOM->GetUniqID();
	CString sPiezaBase = p_pOM->GetsNombre();
	
	while (ind < lim)
	{
		CProgMaq* pPMInd = GetpPM(ind);
		ASSERT_VALID(pPMInd);
		ind++;
		// Si estamos en el mismo GFH no es la operacion anterior, y seguimos
		if (sGFH == pPMInd->GetsGFH()) continue;
		// Si estamos buscando un GFH concreto (parametro p_sGFH <> NULL)
		// solo paramos en ese
		if (p_sGFH)
			if (pPMInd->GetsGFH() != p_sGFH) continue;

			
		for(int j = 0; j < pPMInd->GetNumOM(); j++)
		{
			COrdMaq* pOMInd = pPMInd->GetpOM(j);
			// Si la OrdMaq que estamos mirando es la misma
			if (*pOMInd == *p_pOM) return pOMInd;
		}
	}
	return NULL;
}

// Devuelve el �ndice de la ProgMaq en Prog o INT_MAX si no existe.
int 
CProg::Find(const CProgMaq* p_pPM) const 
{
	int lim = GetNumPM();
	for(int i = 0; i < lim; i++)
		if (p_pPM == GetpPM(i)) return i;
	return INT_MAX;
}

int 
CProg::GetNumPMsInGFHs(CString p_sDesdeGFH, CString p_sHastaGFH) const
{
	int iNumPMs = 0;
	int lim = GetNumPM();
	for(int i = 0; i < lim; i++)
	{
		CProgMaq* pPMInd = GetpPM(i);
		ASSERT_VALID(pPMInd);
		if (!(pPMInd->GetsGFH() < p_sDesdeGFH || pPMInd->GetsGFH() > p_sHastaGFH)) iNumPMs++;
	}
	return iNumPMs;
}

// Cargamos �rdenes en un GFH. Tomamos todas las �rdenes seleccionadas
// de los GFHs anteriores.
void
CProg::CargaGFH(const char* p_sGFH)
{
	// Des-seleccionamos el GFH al que vamos a cargar
	
	int iNumPMs = 0;
	int lim = GetNumPM();
	// Desseleccionamos todos los GFHs excepto el que se va a cargar
	for(int i = 0; i < lim; i++)
	{
		CProgMaq* pPM = GetpPM(i);
		ASSERT_VALID(pPM);
		if (pPM->GetsGFH() == p_sGFH)
			pPM->Selec(FALSE, SelecFalse);
	}
	
	// Creamos una lista con las ordenes que vamos a cargar, que
	// son todas las seleccionadas de los GFH's anteriores
	
	CObArray		ArrOMs;
	
	for(i = 0; i < lim; i++)
	{
		CProgMaq* pPM = GetpPM(i);
		ASSERT_VALID(pPM);
		if (pPM->GetsGFH() > p_sGFH)	//Ver2. Hacer dependiente de Hoja de ruta
		{
			for(int j = 0; j < pPM->GetNumOM(); j++)
			{
				COrdMaq* pOM = pPM->GetpOM(j);
				// Si est� seleccionada y no est� limitada al GFH
				if (pOM->GetBSelected() && ! pOM->LimitGFH(p_sGFH))	
				{
					pOM->SetBSelected(FALSE);	// La des-seleccionamos
					// Y la a�adimos, pero las dobles y triples hay que multiplicarlas
					// Al multiplicarlas se convierten en otras piezas, que ya no son
					// m�ltiples, por lo que no hay m�s que comprobar si son dobles o triples
					
					if (pOM->GetBTriple())
					{
						COrdMaq* pMedOM = new COrdMaq();
						pMedOM->SetValues(pOM);
						pMedOM->SetNewArt(Media);
						pMedOM->m_FecOrd = pOM->GetFecIni();
						AddOMOrd( ArrOMs, pMedOM );
						pMedOM->SetBSelected(TRUE);
					}
					if (pOM->GetBDoble() || pOM->GetBTriple())
					{
						COrdMaq* pExtOM = new COrdMaq();
						pExtOM->SetValues(pOM);
						pExtOM->SetNewArt(Externa);
						pExtOM->m_FecOrd = pOM->GetFecIni();
						AddOMOrd( ArrOMs, pExtOM );
						pExtOM->SetBSelected(TRUE);
						COrdMaq* pIntOM = new COrdMaq();
						pIntOM->SetValues(pOM);
						pIntOM->SetNewArt(Interna);
						pIntOM->m_FecOrd = pOM->GetFecIni();
						AddOMOrd( ArrOMs, pIntOM );
						pIntOM->SetBSelected(TRUE);
					} else
						// Si no es m�ltiple, no se desdobla
					{
						COrdMaq* pNewOM = new COrdMaq();
						pNewOM->SetValues(pOM);
						pNewOM->m_FecOrd = pOM->GetFecIni();
						AddOMOrd( ArrOMs, pNewOM );
						pNewOM->SetBSelected(TRUE);
					}
				} // Si est� seleccionada 
			} // Ciclo de OMs
		}	// Si es del GFH correcto
	} // Ciclo de PMs
	
	// Dado que algunas ordenes pueden haberse traspasado antes,
	// hay que borrarlas. Recorremos el GFH al que traspasamos
	// buscando las ordenes que correspondan.
	
	for(int iLista = 0; iLista < ArrOMs.GetSize(); iLista++) // Hacemos ciclo por las ordenes a traspasar
	{
		COrdMaq* pOMBorr = (COrdMaq	*) ArrOMs.GetAt(iLista);
		ASSERT_VALID(pOMBorr);
		
		for(i = 0; i < lim; i++)	// Buscamos las maquinas de GFH a traspasar
		{
			CProgMaq* pPM = GetpPM(i);
			ASSERT_VALID(pPM);
			if (pPM->GetsGFH() == p_sGFH) // Si la m�quina es del GFH, miramos si borrar
			{
				for(int j = 0; j < pPM->GetNumOM(); j++)
				{
					COrdMaq* pOM = pPM->GetpOM(j);
					if (*pOM == *pOMBorr)		// COrdMaq::Operator ==
					{
						pPM->RemoveAt(j);
						j--;
						// Aqu� probablemente en vez del j--
						// se pueda hacer un break,
						// pero lo dejamos por ahora.

					}	// Si es la misma orden
				} // Ciclo de OMs en la m�quina
			} // Si es del GFH
		} //Ciclo de las m�quinas en el programa
	} // Ciclo de la lista de OMs a borrar

	
	// Tras borrar las ordenes, las insertamos en su GFH
	InsertaEnGFH(ArrOMs, p_sGFH);
	// Recalculamos todo
	Recalc();
}

// Reprogramamos �rdenes en un GFH. Tomamos todas las �rdenes seleccionadas
// del GFH seleccionado

void
CProg::ReprogramaGFH(const char* p_sGFH)
{
	
	int lim = GetNumPM();
	
	// Creamos una lista con las ordenes que vamos a reprogramar,
	// que son todas las seleccionadas del GFH
	
	CObArray		ArrOMs;
	
	for(int i = 0; i < lim; i++)
	{
		CProgMaq* pPM = GetpPM(i);
		ASSERT_VALID(pPM);
		if (pPM->GetsGFH() == p_sGFH)
		{
			for(int j = 0; j < pPM->GetNumOM(); j++)
			{
				COrdMaq* pOM = pPM->GetpOM(j);
				// Si est� seleccionada y no est� limitada al GFH
				if (pOM->GetBSelected())	
				{
					// La a�adimos,
										
					pOM->m_FecOrd = pOM->GetFecLim();
					pOM->SetBFija(FALSE);	// Si la reprogramamos, ya no es fija.
					AddOMOrd( ArrOMs, pOM );
					pPM->RemoveAt(j);
					j--;		// Restamos 1 para no saltarnos 1
				} // Si est� seleccionada 
			} // Ciclo de OMs
		}	// Si es del GFH correcto
		pPM->Recalc();	// Recalculamos para que se reduzcan los huecos
	} // Ciclo de PMs

	InsertaEnGFH(ArrOMs, p_sGFH);
	Recalc();
}

void
CProg::InsertaEnGFH(CObArray& p_ArrOMs, const char* p_sGFH)
{
	CObArray ArrPMs;
	COrdMaq* pOMAct;
	// Hacemos un ciclo para cada orden del Array
	for (int i = 0; i < p_ArrOMs.GetSize(); i++)
	{
		pOMAct = (COrdMaq*) p_ArrOMs.GetAt(i);
		// Hacemos una lista de en qu� orden est� el primer hueco en cada m�quina
		// de ese GFH. Devuelve el n�mero de m�quinas v�lidas. Si es 0 damos un 
		// mensaje de error.
		if (BuscarHuecosGFH(p_sGFH, pOMAct, ArrPMs) == 0)
		{
			CString sMsg;
			sMsg.Format( STRID (IDS_WAR_NOINSOM) ,
				pOMAct->GetlOF(), pOMAct->GetsID() ); 
			AfxMessageBox(sMsg);
			continue;
		}
		CProgMaq* pPMIns = (CProgMaq*) ArrPMs.GetAt(0);
		pPMIns->Add(pOMAct);
		pOMAct->Recalc();
		BuscaOptimizar(p_ArrOMs, i);
	}
}

void
CProg::BuscaOptimizar( CObArray& p_ArrOMs, int p_iInd )
{
	COrdMaq* pOMBase = (COrdMaq*) p_ArrOMs.GetAt(p_iInd);
	ASSERT_VALID(pOMBase);

	CString sGFH = pOMBase->GetsGFH();
	CProgMaq* pPMIns = pOMBase->GetpPM();
	CTime FecBase = pOMBase->GetFecIni();
	CTimeSpan tsDespl = pOMBase->GetTimeSpan();
	// Solo optimizaremos llenadoras por el momento
	if (sGFH != TK_GFH_LLENADORAS) return;
	

	// La optimizacion en llenadoras consiste en buscar ordenes
	// con la misma masa y longitud dentro de un rango razonable (1 dia)
	// y agruparlas.
	
	for (int j = p_iInd + 1; j < p_ArrOMs.GetSize(); j++)
	{
		COrdMaq* pOM = (COrdMaq*) p_ArrOMs.GetAt(j);
		ASSERT_VALID(pOM);
		
				
		// Si la diferencia entre los dos comienzos es de mas
		// de un dia, lo dejamos

		CTimeSpan tsDiff = pOM->m_FecOrd - pOMBase->m_FecOrd;
		if (tsDiff.GetTotalSeconds() > TK_SEGS_DIA) break;
		if (tsDespl.GetTotalSeconds() > TK_SEGS_DIA) break;

				
		// Si no, est�n lo suficientemente proximas para agruparlas
		// si usan la misma masa y longitud.
		// Y siempre que la segunda est� seleccionada
		// Ver2. Realizar una segunda fase de optimizacion bas�ndose en el
		// resultado y tratando de mejorar la suma de m�rgenes
		if ( pOM->GetiMasa() == pOMBase->GetiMasa() &&
			 pOM->GetlLongitud() == pOMBase->GetlLongitud())
		{
			p_ArrOMs.RemoveAt(j);
			j--;
			pPMIns->Add(pOM);
			pOM->Recalc();
			tsDespl += pOM->GetTimeSpan();

		}
	}
}

int
CProg::BuscarHuecosGFH(const char* p_sGFH, COrdMaq* p_pOM, CObArray& p_ArrPMs) const 
{
	
	p_ArrPMs.RemoveAll();
	for (int ind = 0; ind < GetNumPM(); ind++)
	{
		CProgMaq* pActPM = GetpPM(ind);
		ASSERT_VALID(pActPM);
		// Si es del GFH correcto y la orden no est� limitada a la m�quina
		if (pActPM->GetsGFH() == p_sGFH && !(p_pOM->LimitMaquina(pActPM->GetsID())))
		{
			CTime FecUlt;
			// Si la m�quina tiene ordenes, es la fecha de fin de la �ltima orden
			if (pActPM->GetNumOM() > 0)
			{
				COrdMaq* pOM = pActPM->GetpOM(pActPM->GetNumOM() - 1);
				ASSERT_VALID(pOM);
				FecUlt = pOM->GetFecFin();
			} else	// si no, es la fecha de inicio del programa
				FecUlt = GetFecIni();
			
			pActPM->m_FecOrd = FecUlt;
			AddPMOrd(p_ArrPMs, pActPM);
		} // Si es m�quina v�lida
	} // Ciclo de m�quinas
	return p_ArrPMs.GetSize();
}

void
CProg::AddPM( CProgMaq* p_pPM, int p_iInd)
{
	if (p_iInd == -1)
		m_pArrPMs->Add ((CObject*) p_pPM);
	else
		m_pArrPMs->InsertAt ( p_iInd, (CObject*) p_pPM);
	
	p_pPM->SetProg(this);
}

void
CProg::SetFecIni(CTime p_Fec)
{	
	CTime FecTemp = AddDays(p_Fec, TK_MIN_PROG);
	m_Abs.SetFecIni(p_Fec); 
	if (FecTemp > GetFecFin()) SetFecFin(FecTemp);
	
	Recalc();
	RecalcInacts();
}

void
CProg::DescuentaVal(CTime p_Fec, int p_iLocal)
{
	CalcArrOMC(); // Calculamos las OMCs por si no estaban
	
	
    CObArray* pArrNoCambio = new CObArray();
	CObArray* pArrBufArt = g_pCache->GetArrBufArt();
	
	int iLim = pArrBufArt->GetSize();
	// Hacemos un ciclo por todos los Art�culos
	for(int i = 0; i < iLim; i++)
	{
		CBufArticulo* pBufArt = (CBufArticulo*) pArrBufArt->GetAt(i);
		ASSERT( pBufArt->IsKindOf( RUNTIME_CLASS( CBufArticulo ) ) );
		// Si tienen una cantidad fabricada en el Lisado Valorado
		if (pBufArt->m_LV_lCantidad_Fabricada <= 0) continue;
		
		// La vamos descontando
		
		// Lo a�adimos a la cantidad de las OFs
		g_pCache->UpdateOF(pBufArt->m_sID, pBufArt->m_LV_lCantidad_Fabricada);
		
		// buscamos la Orden combinada que le corresponde
		COMC* pOMC = GetpOMC(pBufArt->m_sID);
		if (!pOMC) continue;
		// Si s�lo hay una orden y no tiene inactividades, descontamos y acabamos.
		if (pOMC->m_pOM && pOMC->m_pArrCOMComb->GetSize() < 2)
		{
			CProgMaq* pPM = pOMC->m_pOM->GetpPM();
			if (p_iLocal == 1 && pPM->GetsIDLocal() == "1" || p_iLocal != 1 && pPM->GetsIDLocal() != "1" )
			{
				pOMC->m_pOM->SetlCantidad(pOMC->m_pOM->GetlCantidad() - pBufArt->m_LV_lCantidad_Fabricada);
				// Como s�lo hay una orden, ponemos toda la cantidad a esa orden
				pOMC->m_pOM->SetFab(pOMC->m_pOM->GetlCantFab() + pBufArt->m_LV_lCantidad_Fabricada, p_Fec);
				pOMC->m_pOM->SetBTiempoFijo(FALSE);
				pOMC->m_pOM->CalcTimeSpan();
				// Si ya hemos quedado sin cantidad
				if (pOMC->m_pOM->GetlCantidad() <= 0)
				{
					// Ponemos la orden en una hora para que sea eliminada por
					// AplicarCambiosMoldes
					pOMC->m_pOM->SetlCantidad(0);
					pOMC->m_pOM->SetTs((CTimeSpan) TK_SEGS_HORA);
					CString sTest = FormatLong(pOMC->m_pOM->GetTimeSpan().GetTotalSeconds(), 5);
					// Y la a�adimos a la matriz para comprobar que todas son eliminadas
					pArrNoCambio->Add(pOMC->m_pOM);
				}
			}
			// Por ahora el posible remanente de fabricadas nos da igual
		} else if (pOMC->m_pArrOM) // Si tenemos varias �rdenes 
		{
			// Hacemos un ciclo
			int iLimI = pOMC->m_pArrOM->GetSize();
			// Las �rdenes deben estar clasificadas por fecha de inicio
			
			long lCantR = pBufArt->m_LV_lCantidad_Fabricada;
			// Primero borramos todas las que no cumplen los requisitos de Local
			BOOL bAlgoBorrado = FALSE;
			for(int iI = 0; iI < iLimI; iI++)
			{
				COrdMaq* pOM = (COrdMaq*) pOMC->m_pArrOM->GetAt(iI);
				ASSERT( pOM->IsKindOf( RUNTIME_CLASS( COrdMaq ) ) );
				CProgMaq* pPM = pOM->GetpPM();
				if (!(p_iLocal == 1 && pPM->GetsIDLocal() == "1" || p_iLocal != 1 && pPM->GetsIDLocal() != "1" ))
				{
					bAlgoBorrado = TRUE;
					pOMC->m_pArrOM->RemoveAt(iI);
					iI--;
					iLimI--;	
				}
			}
			// Si nos hemos quedado sin ordenes, continuamos
			if (pOMC->m_pArrOM->GetSize() <= 0) continue;
			// Sincronizamos el Array de combinadas si es necesario
			if (bAlgoBorrado) DesolaparArrOMC( pOMC->m_pArrOM, pOMC->m_pArrCOMComb);
			
			// Y ahora descontamos
			// Si hay solapes
				DescuentoConSolapes(lCantR, pOMC, pArrNoCambio, p_Fec);
			/*
			if (pOMC->HaySolapes())
			{
				DescuentoConSolapes(lCantR, pOMC, pArrNoCambio, p_Fec);
			} else
			{
				// Si no hay solapes, el descuento es mas normal	
				for( iI = 0; iI < iLimI; iI++)
				{
					COrdMaq* pOM = (COrdMaq*) pOMC->m_pArrOM->GetAt(iI);
					ASSERT( pOM->IsKindOf( RUNTIME_CLASS( COrdMaq ) ) );
					// Si no hay solape, descontamos
					int iInt = pOM->GetlCantidad();
					pOM->SetlCantidad(pOM->GetlCantidad() - lCantR);
					pOM->SetFab(pOM->GetlCantFab() + 
									(lCantR > pOM->GetlCantidad() ? pOM->GetlCantidad() : lCantR ), 
								p_Fec);
					if (pOM->GetlCantidad() <= 0) pOM->SetlCantidad(0);
					pOM->SetBTiempoFijo(FALSE);
					pOM->CalcTimeSpan();
					lCantR -= iInt;
					// Si ya hemos quedado sin cantidad, la borramos
					if (pOM->GetlCantidad() <= 0)
					{
						// Ponemos la orden en una hora para que sea eliminada por
						// AplicarCambiosMoldes
						pOM->SetlCantidad(0);
						pOM->SetTs((CTimeSpan) TK_SEGS_HORA);
						CString sTest = FormatLong(pOM->GetTimeSpan().GetTotalSeconds(), 5);
						// Y la a�adimos a la matriz para comprobar que todas son eliminadas
						pArrNoCambio->Add(pOM);
					}
					// Si no nos queda cantidad por descontar, acabamos
					if (lCantR <= 0) break;
				}
			}
			*/
			// Antes hac�amos diferencias entre descuento con solapes y sin solapes.
			// pero al haber calendario, no se puede hacer �sto, porque el calendario afecta
			// al descuento incluso aunque no haya solapes.
		}
	}
	
	
	// Ahora aplicamos los cambios de moldes
	
	CObArray* pArrNoFab = new CObArray();
	CStringArray* pArrNotFound = new CStringArray();
	CObArray* pArrBorrar = new CObArray();
	AplicarCambiosMoldes(p_Fec, pArrNoCambio, pArrBorrar, pArrNoFab, pArrNotFound);
	
	
	InformarErrores(pArrNoCambio, pArrNoFab, pArrNotFound, pArrBorrar);
	
	//Ahora borramos las de ArrBorrar
	for(i=0; i < pArrBorrar->GetSize(); i++)
	{
		COrdMaq* pOM = (COrdMaq*) pArrBorrar->GetAt(i);
		// La a�adimos al hist�rico
		g_pCache->AddHistorico(pOM);
		// Y la borramos
		DeleteOM(pOM);
	}
	// y borramos y cambiamos las �rdenes sin art�culo que se solapen con el d�a.

	for(i=0; i< GetNumPM() ; i++)
	{
		CProgMaq* pPM = GetpPM(i);
		ASSERT_VALID(pPM);
		if (p_iLocal == 1 && pPM->GetsIDLocal() == "1" || p_iLocal != 1 && pPM->GetsIDLocal() != "1" )
		{
			for (int j = 0; j < pPM->GetNumOM(); j++)
			{
				COrdMaq* pOM = pPM->GetpOM(j);
				if (pOM->GetsID() != "") continue;
				if (pOM->GetFecIni() < p_Fec) // Hay solape
				{
					if (pOM->GetFecFin() <= p_Fec) // Est� entera dentro
					{
						// La borramos
						DeleteOM(pOM);

					} else // S�lo est� en parte
					{
						
						pOM->SetTs(pOM->GetFecFin() - p_Fec);
						pOM->SetBTiempoFijo(TRUE);
						pOM->SetFecIni(p_Fec);		// Recortamos lo que sobra
					}
				}
				
			
			}
		}
	}

	// Y cambiamos el orden en las que se ha cambiado el molde pero no se han completado,
	// buscamos el molde que venia detras y lo ponemos el primero.
	for(i=0; i < pArrNoFab->GetSize(); i++)
	{
		COrdMaq* pOM = (COrdMaq*) pArrNoFab->GetAt(i);
		CProgMaq* pPM = pOM->GetpPM();
		if (pOM->m_sAux == "") continue;
		COrdMaq* pPrimOM = pPM->FindOMbyMolde( pOM->m_sAux );
		if (pPrimOM)
		{
			MoveOrdMaq(pPM, pPrimOM, -1);
		}
	}
	


	delete pArrNoCambio;
	delete pArrNoFab;
	delete pArrNotFound;
	delete pArrBorrar;

	// Ahora ponemos las m�quinas afectadas un d�a m�s avanzado
	
	for(i=0; i< GetNumPM() ; i++)
	{
		CProgMaq* pPM = GetpPM(i);
		ASSERT_VALID(pPM);
		if (p_iLocal == 1 && pPM->GetsIDLocal() == "1" || p_iLocal != 1 && pPM->GetsIDLocal() != "1" )
		{
			if (pPM->GetNumOM())
			{
				COrdMaq* pOM = pPM->GetpOM(0);
				ASSERT_VALID(pOM);
				pOM->SetFecIni(p_Fec);
				pOM->SetBFija(TRUE);
			}
		}
	}
	
	Recalc();
	RecalcInacts();
	CalcArrOMC();		// Porque ha quedado mal tras borrar las m�quinas que no cumplen el p_iLocal
	
}

void
CProg::DescuentoConSolapes(long& p_rlCant, COMC* p_pOMC, CObArray* p_pArrNoCambio, CTime p_Fec)
{
	// Repartimos la cantidad entre las OMs
	(void) p_pOMC->ReparteCant(p_rlCant);
	// Ahora tenemos la cantidad en el m_lAux de cada OM
	// Hacemos un ciclo por las OMs afectadas a ver qu� hay
	if (!p_pOMC->m_pOM)	return;
	
	for (int i=0; i < p_pOMC->m_pArrOM->GetSize(); i++)
	{
		COrdMaq* pOM = (COrdMaq*) p_pOMC->m_pArrOM->GetAt(i);
		long lDescCant = pOM->m_lAux;
		if (lDescCant <= 0) continue;

		pOM->SetlCantidad(pOM->GetlCantidad() - lDescCant);
		pOM->SetFab(pOM->GetlCantFab() + (lDescCant > pOM->GetlCantidad() ? pOM->GetlCantidad() : lDescCant)
			, p_Fec);
		if (pOM->GetlCantidad() < 0) pOM->SetlCantidad(0);
		pOM->SetBTiempoFijo(FALSE);
		pOM->CalcTimeSpan();
		// Si ya hemos quedado sin cantidad
		if (pOM->GetlCantidad() <= 0)
		{
			p_pArrNoCambio->Add(pOM);
		}
	}
	
	/*	IMPLEMENTACION ANTERIOR, SIN ReparteCant(). LA GUARDO PORQUE FUNCIONABA
	//Si hay solapes, utilizaremos directamente la matriz de OMComb
	CObArray* pArrComb = p_pOMC->m_pArrCOMComb;
	// Necesitaremos una matriz de OMs
	
	CObArray ArrOMs;
	// Hacemos un ciclo por los elementos del pArrComb
	for (int i = 0; i < pArrComb->GetSize(); i++)
	{
		COMComb* pOMComb = (COMComb*) pArrComb->GetAt(i);
		ASSERT( pOMComb->IsKindOf( RUNTIME_CLASS( COMComb ) ) );
		// Ahora tenemos que saber a cu�ntas OMs afecta esta
		p_pOMC->GetArrOMsAfec(pOMComb, &ArrOMs);
		// Tambi�n el n�mero de piezas que se fabrica en esta combinada
		long lCant = pOMComb->GetlCantFab();
		// No podemos descontar m�s de lo que hay
		if (lCant > p_rlCant) lCant = p_rlCant;
		// Calculamos el porcentaje que le corresponde a cada orden. Primero la suma
		// de las cadencias afectadas
		double dSumaCad = 0;
		for (int iK = 0; iK < ArrOMs.GetSize(); iK++)
		{
			COrdMaq* pOM = (COrdMaq*) ArrOMs.GetAt(iK);
			dSumaCad += pOM->GetdCadencia();
		}
		if (dSumaCad != pOMComb->m_dCadencia)
		{
			CString sMsg;
			sMsg.Format("Distintas cadencias en DescuentoConSolapes : %f %f \n", dSumaCad, pOMComb->m_dCadencia );
			TRACE(sMsg);
		}
		for (iK = 0; iK < ArrOMs.GetSize(); iK++)
		{
			COrdMaq* pOM = (COrdMaq*) ArrOMs.GetAt(iK);
			pOM->m_dAux = pOM->GetdCadencia() / dSumaCad;
		}
		for (iK = 0; iK < ArrOMs.GetSize(); iK++)
		{
			COrdMaq* pOM = (COrdMaq*) ArrOMs.GetAt(iK);
			long lDesCant = (long) (pOM->m_dAux * (double) lCant + 1);
			pOM->SetlCantidad(pOM->GetlCantidad() - lDesCant);
			pOM->SetFab(pOM->GetlCantFab() + (lDesCant > pOM->GetlCantidad() ? pOM->GetlCantidad() : lDesCant)
						, p_Fec);
			if (pOM->GetlCantidad() < 0) pOM->SetlCantidad(0);
			pOM->SetBTiempoFijo(FALSE);
			pOM->CalcTimeSpan();
			// Si ya hemos quedado sin cantidad
			if (pOM->GetlCantidad() <= 0)
			{
				p_pArrNoCambio->Add(pOM);
			}
		}

		// Descontamos las piezas asignadas
		p_rlCant -= lCant;
		// Si ya hemos asignado todas, terminamos
		if (p_rlCant <= 0) break;
	}
*/
}


void 
CProg::InformarErrores(CObArray *p_pArrNoCambio, CObArray *p_pArrNoFab, CStringArray *p_pArrNotFound, CObArray *p_pArrBorrar)
{
	int iNumOM;
	CDlgDebug DlgD;
	DlgD.m_ArrStr.Add("Bloques Fabricados pero sin Cambio de Molde");
	DlgD.m_ArrStr.Add("-------------------------------------------");
	
	iNumOM = p_pArrNoCambio->GetSize();
	for (int iD=0; iD< iNumOM; iD++)
	{
		COrdMaq* pOM = (COrdMaq*) p_pArrNoCambio->GetAt(iD);
		ASSERT( pOM->IsKindOf( RUNTIME_CLASS( COrdMaq ) ) );
		
		CString sMsg;
		sMsg.Format(" [%s] ; %s (%s)"
			, pOM->GetsMaquina()
			, pOM->GetsID()
			, pOM->GetsMolde()
			);
		
		DlgD.m_ArrStr.Add(sMsg);
	}
	
	
	iNumOM = p_pArrNotFound->GetSize();
	if (iNumOM > 0)
	{
		DlgD.m_ArrStr.Add("");
		DlgD.m_ArrStr.Add("CAMBIOS DE MOLDE NO ENCONTRADOS");
		DlgD.m_ArrStr.Add("-------------------------------");
		
		for (iD=0; iD< iNumOM; iD++)
		{
			CString sMsg = p_pArrNotFound->GetAt(iD);
			
			DlgD.m_ArrStr.Add(sMsg);
		}
	}

	DlgD.m_ArrStr.Add("");
	DlgD.m_ArrStr.Add("Bloques con Cambio de Molde pero con + de 5 horas restantes");
	DlgD.m_ArrStr.Add("-----------------------------------------------------------");
	
	iNumOM = p_pArrNoFab->GetSize();
	for (iD=0; iD< iNumOM; iD++)
	{
		COrdMaq* pOM = (COrdMaq*) p_pArrNoFab->GetAt(iD);
		ASSERT( pOM->IsKindOf( RUNTIME_CLASS( COrdMaq ) ) );
		
		CString sMsg;
		sMsg.Format(" [%s] ; %s (%s)"
			, pOM->GetsMaquina()
			, pOM->GetsID()
			, pOM->GetsMolde()
			);
		
		DlgD.m_ArrStr.Add(sMsg);
	}
	
	DlgD.m_ArrStr.Add("");
	DlgD.m_ArrStr.Add("Bloques que se borran");
	DlgD.m_ArrStr.Add("---------------------");
	
	iNumOM = p_pArrBorrar->GetSize();
	for ( iD=0; iD< iNumOM; iD++)
	{
		COrdMaq* pOM = (COrdMaq*) p_pArrBorrar->GetAt(iD);
		ASSERT( pOM->IsKindOf( RUNTIME_CLASS( COrdMaq ) ) );
		
		CString sMsg;
		sMsg.Format(" [%s] ; %s (%s)"
			, pOM->GetsMaquina()
			, pOM->GetsID()
			, pOM->GetsMolde()
			);
		
		DlgD.m_ArrStr.Add(sMsg);
	}
	
	//Volcamos la matriz en un fichero, para otras consultas.
	ofstream outf( TK_FILE_CAMBIO, ios::out );  // Output file stream.
	if (outf)
	{
		for(int ind = 0; ind < DlgD.m_ArrStr.GetSize() ; ind++)
		{
			CString sLin = DlgD.m_ArrStr.GetAt(ind);
			outf.write(sLin, sLin.GetLength() );
			outf.put('\n');
		}
		outf.close();
	}
	DlgD.m_ArrStr.Add("");
	CString sInt;
	sInt.Format("(%s %s)","Esta informacion se encuentra en el fichero : ", TK_FILE_CAMBIO);
	DlgD.m_ArrStr.Add(sInt);


	DlgD.DoModal();	
	
}

void
CProg::AplicarCambiosMoldes(CTime p_Fec, CObArray* p_pArrNoCambio, CObArray* p_pArrBorrar, CObArray* p_pArrNoFab, CStringArray* p_pArrNotFound )
{
	// Hacemos un ciclo por los cambios de los moldes
	CBufCambiosMoldes* pBufCM = g_pCache->GetFirstCambioMolde(p_Fec);
	while (pBufCM)
	{
		CProgMaq* pPM = FindMaq(pBufCM->m_sIDMaquina);
		if (pPM)
		{
			// Buscamos el primer molde en la maquina, teniendo en cuenta las ya encontradas,
			// que o bien estan en ArrBorrar o en ArrNoFab
			COrdMaq* pOM = pPM->FindOMbyMolde(pBufCM->m_sIDMoldeSal, p_pArrBorrar, p_pArrNoFab);
			if (pOM)
			{
				// Y la a�adimos bien a uno o a otro, dependiendo de lo que le quede por fabricar
				if (pOM->GetTimeSpan().GetTotalSeconds() <= TK_DEL_MINSECS )
				{
					p_pArrBorrar->Add(pOM);
					// Y lo quitamos del array de sin Cambios, si esta
					for (int iJ = 0; iJ < p_pArrNoCambio->GetSize(); iJ++)
					{
						COrdMaq* pOMJ = (COrdMaq*) p_pArrNoCambio->GetAt(iJ);
						if (pOM == pOMJ)
						{
							p_pArrNoCambio->RemoveAt(iJ);
							break;
						}
					}
				} else
				{
					// Guardamos el molde entrante para poderlo poner por delante luego
					pOM->m_sAux = pBufCM->m_sIDMoldeEnt;
					p_pArrNoFab->Add(pOM);
				}	
			} else // Si no encontrado ese molde, es un error, guardamos una cadena con informacion
			{
				p_pArrNotFound->Add(pBufCM->m_sIDMoldeSal + " en Maquina [" + pBufCM->m_sIDMaquina + "]");
			}
		}
		pBufCM = g_pCache->GetNextCambioMolde(p_Fec);
	}

}
void
CProg::DeleteOM(COrdMaq* p_pOM)
{
	COrdMaq* pOM = p_pOM;
	ASSERT_VALID(pOM); 
	CProgMaq* pPMi = pOM->GetpPM();
	ASSERT_VALID(pPMi);
	int i = pOM->PMIndex();
	if ( i < 0 ) TRACE("Error en CProg::DeleteOM, no se encuentra la orden en la m�quina");
	pPMi->RemoveAt(i);
	delete pOM;
}

BOOL
CProg::VerifStruct()
{	
	BOOL BErr = FALSE;
	BOOL BRes;
	CString sMsg;
	
	// Recorremos todas las ordenes en celulas (a partir de TK_NUMDIAS_VERIF
	// d�as tras el inicio de la programaci�n) y miramos que est�n
	// completas, es decir que est�n en todos los GFH�s para los
	// que no est�n limitadas
	for( int i = GetNumPM() - 1; i >= 0 ; i--)
	{
		
		CProgMaq* pPM = (CProgMaq*) GetpPM(i);
		ASSERT_VALID(pPM);
		// Si nos salimos del primer GFH, nos vamos.
		if (pPM->GetsGFH() != TK_GFH_CELULAS) break;
		
		CString sUltGFH;
		int iLimOM = pPM->GetNumOM();
		int iPM;
		for(int j = 0; j < iLimOM; j++)
		{
			COrdMaq* pOM = pPM->GetpOM(j);
			BRes = TRUE;
			sUltGFH = TK_GFH_CELULAS;
			iPM = i - 1;
			CTimeSpan tsDiff = pOM->GetFecIni() - GetFecIni();
			// Tenemos una orden, si est� a menos de siete d�as del comienzo
			// de la programaci�n, es que a lo mejor no est� completa porque
			// empezaba antes del comienzo, y por tanto no se puede comprobar.
			if (tsDiff.GetDays() < TK_NUMDIAS_VERIF) continue;
			// Hacemos un ciclo por los GFH�s anteriores comprobando que se encuentra en todos
			for (;;)
			{
				// Ahora buscamos el siguiente GFH hacia atr�s, comenzando por una m�quina
				// anterior a la que vamos comprobando del primer GFH
				for (; iPM >= 0; iPM--)
				{
					CProgMaq* pPM = (CProgMaq*) GetpPM(iPM);
					ASSERT_VALID(pPM);
					if (pPM->GetsGFH() != sUltGFH) 
					{
						sUltGFH = pPM->GetsGFH();
						break;
					}
				}
				// Si no hay m�s GFH, nos salimos del ciclo de buscar GFHs
				if ( iPM < 0 ) break;
				// Si est� limitada a ese GFH, vamos a por otro GFH
				if (pOM->LimitGFH(sUltGFH)) continue;
				// Buscamos dentro del GFH hasta encontrarla, iPM marca la primera maquina
				// de ese GFH. Marcamos el resultado como FALSE hasta encontrarla
				BRes = FALSE;
				for (iPM; iPM >= 0; iPM--)
				{
					CProgMaq* pPMCic = GetpPM(iPM);
					if (pPMCic->GetsGFH() != sUltGFH) break;
					
					int iLimOM = pPMCic->GetNumOM();
					for(int l = 0; l < iLimOM; l++)
					{
						COrdMaq* pOMCic = pPMCic->GetpOM(l);
						// Si la encontramos, marcamos el resultado como  TRUE y nos salimos
						if (pOMCic->GetlOF() == pOM->GetlOF())
						{
							BRes = TRUE;
							break;
						}
					} // Fin ciclo interno �rdenes
				}	// Fin ciclo interno m�quinas
				// Si BRes es FALSE, es que no esta limitada al GFH y no se encuentra en el.
				// Entonces damos un aviso.
				if (!BRes)
				{
					// Marcamos que ha habido errores, para el mensaje final
					BErr = TRUE;
					CTime FecEnt = pOM->GetFecEnt();
					sMsg.Format( STRID( IDS_ERR_OFINC ), 
						pOM->GetlOF(),
						FormatFec(FecEnt,Fecha));
					AfxMessageBox(sMsg);
				}
			} // Fin ciclo de buscar GFHs anteriores
		} // Fin ciclo externo �rdenes
	} // Fin ciclo externo m�quinas
	if (!BErr)
	{
		CTime FecEnt = GetFecIni();
		FecEnt = AddDays(FecEnt, TK_NUMDIAS_VERIF);
		sMsg.Format(STRID( IDS_ERR_NOOMINC ),
			FormatFec(FecEnt,Fecha));
		AfxMessageBox(sMsg);
	}
	return BErr;
}

COrdMaq* 
CProg::FindOMArt(const CString &p_sArticulo)
{
	for(int i=0; i< GetNumPM() ; i++)
	{
		CProgMaq* pPM = GetpPM(i);
		ASSERT_VALID(pPM);
		for (int j=0; j< pPM->GetNumOM() ; j++)
		{
			COrdMaq* pOM = pPM->GetpOM(j);
			ASSERT_VALID(pOM);
			if (pOM->GetsID() == p_sArticulo)
			{
				return pOM;
				break;
			}
		}
	}
	return NULL;

}

long 
CProg::GetlCantArt(const CString &m_sIDArt)
{
	COMC OMC;
	OMC.m_sID = m_sIDArt;
	int iInd = m_pArrOMs->Find(&OMC);
	if (iInd < 0) return 0;
	COMC* pOMC = (COMC*) m_pArrOMs->GetAt(iInd);
	if (pOMC->m_pArrOM == NULL)
		if (pOMC->m_pOM != NULL) return pOMC->m_pOM->GetlCantidad();
		else return 0;

	int iLim = pOMC->m_pArrOM->GetSize();
	long lCant = 0;
	for (int i = 0; i < iLim; i++)
	{
		COrdMaq* pOM = (COrdMaq*) pOMC->m_pArrOM->GetAt(i);
		ASSERT_VALID(pOM);
		lCant += pOM->GetlCantidad();
	}

	return lCant;
}

 // Calculamos la cantidad que se habr� fabricado para una fecha dada, 
 // en base al array combinado.
long
CProg::CalcCantAFecha(const CString& p_sIDArticulo, CTime p_Fec)
{
	 COMC OMCt;
	 OMCt.m_sID = p_sIDArticulo;
	 int iInd = m_pArrOMs->Find(&OMCt);
	 if (iInd < 0) return 0;
	 COMC* pOMC = (COMC*) m_pArrOMs->GetAt(iInd);
	 int iLimComb = pOMC->m_pArrCOMComb->GetSize();
	 if (iLimComb <= 0) return 0;
	 // Establecemos un acumulado de lo que vamos fabricando en cada Combinada
	 long lCant = 0;
	 // Las fechas de las combinadas deben ser consecutivas.
	 for (int i=0; i< iLimComb; i++)
	 {
		 COMComb* pOMComb = (COMComb*) pOMC->m_pArrCOMComb->GetAt(i);
		 // Si el siguiente combinado empieza despu�s de la fecha, es que no puede aportar nada
		 if (pOMComb->m_AbSpan.GetFecIni() >= p_Fec)
			 break;
		 // Si el combinado est� completamente comprendido
		 if (pOMComb->m_AbSpan.GetFecFin() < p_Fec)
		 {
			// Sumamos toda la fabricaci�n
			 lCant += pOMComb->GetlCantFab();
			 continue;
		 }
		 if (pOMComb->m_AbSpan.GetFecFin() >= p_Fec)
		 {
			 CTimeSpan tsInt = p_Fec - pOMComb->m_AbSpan.GetFecIni();
			 long lInt = (long) (tsInt.GetTotalSeconds() / ( 1.0 + ( TK_INACT_DEF / 100.0 )));
	
			 lCant += (long) (tsInt.GetTotalSeconds() * pOMComb->m_dCadencia / (double) TK_SEGS_HORA ) + 1;
			 continue;
		 }
	 }
	 return lCant;
}
//Calculamos a qu� fecha vamos a tener la cantidad fabricada. Si no alcanzamos
// devolvemos la fecha de fin de programa. Si ya est� hecho (cant <= 0) devolvemos la de inicio
CTime
CProg::CalcFecParaCant(const CString& p_sIDArticulo, long p_lCant)
{
	 if (p_lCant <= 0) return GetFecIni();
	 COMC OMCt;
	 OMCt.m_sID = p_sIDArticulo;
	 int iInd = m_pArrOMs->Find(&OMCt);
	 if (iInd < 0) return GetFecFin();
	 COMC* pOMC = (COMC*) m_pArrOMs->GetAt(iInd);
	 int iLimComb = pOMC->m_pArrCOMComb->GetSize();
	 if (iLimComb <= 0) return GetFecFin();
	 // Establecemos un acumulado de lo que vamos fabricando en cada Combinada
	 long lCant = 0;
	 COMComb OMCombFin;
	 // Las fechas de las combinadas deben ser consecutivas.
	 for (int i=0; i< iLimComb; i++)
	 {
		 COMComb* pOMComb = (COMComb*) pOMC->m_pArrCOMComb->GetAt(i);
		 // Despreciamos los Combinados menores de un minuto.
		 if (pOMComb->m_AbSpan.GetSecs() < 60 ) continue;
		 // Si ya hemos alcanzado la cantidad, salimos
		// Sumamos toda la fabricaci�n
		 lCant += pOMComb->GetlCantFab();
		 if (lCant >= p_lCant)
		 {
			 OMCombFin = *pOMComb;
			 break;
		 }
	 }
	 if (lCant >= p_lCant) // Eso es que lo llegamos a fabricar
	 {
		 long lDiff = lCant - p_lCant;
		 CTime FecFin = OMCombFin.m_AbSpan.GetFecFin();
		 long lDiffSecs = (long) (( lDiff * (double) TK_SEGS_HORA ) / OMCombFin.m_dCadencia );
		 lDiffSecs = (long) ((double) lDiffSecs * ( 1.0 + ( TK_INACT_DEF / 100.0 )));
		 FecFin -= (CTimeSpan) lDiffSecs;
		 return FecFin;
	 }
	 return GetFecFin();
}

// Calcula un Array de OrdMaqs Combinadas, es decir, una entrada para cada art�culo,
// Si s�lo hay una OM para ese art�culo tendr� m_pOM != NULL y m_pArrOMs == NULL
// Si hay m�s, m_pOM ser� NULL y m_pArrOMs apuntar� a una matriz de punteros a 
// OMs con todas las OMs de este art�culo
// Tambi�n calcular� el array de OMComb, que nos dan las una serie lineal de �rdenes,
// con las cadencias sumadas en los momentos en los que se solapan, en m_pArrCOMComb.
int 
CProg::CalcArrOMC()
{
	ClearOMs();
	COMC OMCt;
	for(int i=0; i< GetNumPM() ; i++)
	{
		CProgMaq* pPM = GetpPM(i);
		ASSERT_VALID(pPM);
		for (int j=0; j< pPM->GetNumOM() ; j++)
		{
			COrdMaq* pOM = pPM->GetpOM(j);
			ASSERT_VALID(pOM);
			pOM->SetbConfMolde(FALSE);
					
			OMCt.m_sID = pOM->GetsID();
			int iInd = m_pArrOMs->Find(&OMCt);
			if ( iInd < 0)
			{
				// Si no encontrado
				COMC* pOMC = new COMC;
				pOMC->m_sID = pOM->GetsID();
				pOMC->m_pOM = pOM;
				m_pArrOMs->Add(pOMC);
			}
			else
			{
				// Si encontrado
				COMC* pOMC = (COMC*) m_pArrOMs->GetAt(iInd);
				if (pOMC->m_pArrOM == NULL)
				{
					// Vamos a a�adir las OMs ordenadas por fecha de inicio, pero la primera
					// la podemos a�adir sin m�s.
					pOMC->m_pArrOM = new CObArray;
					pOMC->m_pArrOM->Add(pOMC->m_pOM);
					pOMC->m_pOM->m_FecOrd = pOMC->m_pOM->GetFecIni();
					pOMC->m_pOM = NULL;
				}
				pOM->m_FecOrd = pOM->GetFecIni();
				//Verificamos que no haya conflictos de moldes
				for (int iM=0; iM < pOMC->m_pArrOM->GetSize(); iM++)
				{
					COrdMaq* pOMM = (COrdMaq*) pOMC->m_pArrOM->GetAt(iM);
					if (pOM->GetpPM() != pOMM->GetpPM() &&
						pOM->GetsMolde() == pOMM->GetsMolde() 
						&& pOM->Overlaps(pOMM)
						&& pOM->GetsID() != ""		// Si es una parada, el molde no importa
					)
					{
						pOM->SetbConfMolde(TRUE);
						pOMM->SetbConfMolde(TRUE);
					}
				}
				// A�adimos en orden de fecha de inicio.
				AddOMOrd( *(pOMC->m_pArrOM) , pOM );
			}
		}
	}
	// Ahora ya tenemos las matrices iniciales por orden de fecha de inicio, vamos
	// a calcular la matriz de las OMComb. Lo hacemos en una funci�n 
		
	int iLimOMs = m_pArrOMs->GetSize();
	for ( i=0; i < iLimOMs; i++)
	{
		COMC* pOMC = (COMC*) m_pArrOMs->GetAt(i);
		// Primero creamos el Array, que siempre existir�
		pOMC->m_pArrCOMComb = new CObArray();
		if (pOMC->m_pArrOM == NULL) // Eso es que s�lo hay una orden
		{
			// La metemos en el array.
			if (pOMC->m_pOM->TieneInacts())
			{
				CObArray ArrOMTemp;
				ArrOMTemp.Add(pOMC->m_pOM);
			// Hay que desolapar aunque s�lo sea una, porque tiene inactividades
				DesolaparArrOMC( &ArrOMTemp, pOMC->m_pArrCOMComb);
			} else
			{
				COMComb* pOMComb = new COMComb(pOMC->m_pOM);
				pOMC->m_pArrCOMComb->Add(pOMComb);
			}
		} else
		{
			
			// Ahora empiezan los problemas, hay que convertir la matriz de �rdenes en
			// una matriz de pseudo-ordenes, de cadencias combinadas. Lo hacemos en una
			// funci�n aparte para no eternizar �sta.
			DesolaparArrOMC( pOMC->m_pArrOM, pOMC->m_pArrCOMComb);
		}

		// Debug
		/*
		int iNumOM;
		CDlgDebug DlgD;
		if (pOMC->m_pArrOM)
		{
			iNumOM = pOMC->m_pArrOM->GetSize();
			for (int iD=0; iD< iNumOM; iD++)
			{
				COrdMaq* pOM = (COrdMaq*) pOMC->m_pArrOM->GetAt(iD);
				ASSERT( pOM->IsKindOf( RUNTIME_CLASS( COrdMaq ) ) );

				CString sMsg;
				sMsg.Format(" %s ; %s - %s", pOM->GetsMaquina()
					, FormatFec(pOM->GetFecIni(), FecHoraSec)
					, FormatFec(pOM->GetFecFin(), FecHoraSec)
				);
				
				DlgD.m_ArrStr.Add(sMsg);
				
			}
		} else
		{
			COrdMaq* pOM = (COrdMaq*) pOMC->m_pOM;
			CString sMsg;
			sMsg.Format(" %s ; %s - %s", pOM->GetsMaquina()
					, FormatFec(pOM->GetFecIni(), FecHoraSec)
					, FormatFec(pOM->GetFecFin(), FecHoraSec)
					);						
			DlgD.m_ArrStr.Add(sMsg);
		}
		DlgD.m_ArrStr.Add("-----Combinadas-----");
		int iNumOMC = pOMC->m_pArrCOMComb->GetSize();
		for (int iD=0; iD< iNumOMC; iD++)
		{
			CObArray ArrOMAfec;
			COMComb* pOMComb = (COMComb*) pOMC->m_pArrCOMComb->GetAt(iD);
			pOMC->GetArrOMsAfec(pOMComb, &ArrOMAfec);
			CString sMsg;
			sMsg.Format(" %s ; %s - %s Afectadas: ", FormatLong((long) pOMComb->m_dCadencia, 6)
				, FormatFec(pOMComb->m_AbSpan.GetFecIni(), FecHoraSec)
				, FormatFec(pOMComb->m_AbSpan.GetFecFin(), FecHoraSec)
				);
			for (int iAdd = 0; iAdd < ArrOMAfec.GetSize(); iAdd++)
			{
				COrdMaq* pOM = (COrdMaq*) ArrOMAfec.GetAt(iAdd);
				
				sMsg += pOM->GetsMaquina() + " ";
			}

			DlgD.m_ArrStr.Add(sMsg);
		}
		
		if (DlgD.DoModal() != IDOK) return 0;
		*/
		// End Debug
	}
	return m_pArrOMs->GetSize();
}

// Convierte un array de OMs, ordenado por FecIni, en un array de OMComb. Tiene en cuenta calendario.
int 
CProg::DesolaparArrOMC(CObArray* p_pArrOM, CObArray* p_pArrOMComb)
{
	// Recibimos como entrada el array de OMs, y debemos sacar el array de OMComb
	CObArray ArrOM, ArrOMSort;
	// Borramos lo que pueda haber en OMComb
	for (int iDel = 0; iDel < p_pArrOMComb->GetSize(); iDel++)
	{
		COMComb* pOMComb = (COMComb*) p_pArrOMComb->GetAt(iDel);
		delete pOMComb;
	}
	p_pArrOMComb->RemoveAll();
	int iNumOM = p_pArrOM->GetSize();
	if (iNumOM <= 0) return 0;
	
	// Creamos la primera OMComb como una copia de la primera OM
	COrdMaq* pOMBase = (COrdMaq*) p_pArrOM->GetAt(0);
	COMComb* pOMCBase = new COMComb(pOMBase);
	p_pArrOMComb->Add(pOMCBase);
	// Si hay m�s, vamos creando el array de OMComb, con las OMs combinadas
	if (iNumOM > 1)
	{
		int iIns = 0;
		for (int i=1; i < iNumOM; i++)  // Empezamos en 1 porque el 0 est� ya procesado
		{
			COrdMaq* pOM = (COrdMaq*) p_pArrOM->GetAt(i);
			// Ahora buscamos dentro del array de OM�s al primero que tenga la fecha
			// de fin mayor que la de inicio de la nueva OM. Esto nos da el punto de
			// insercion. Guardamos el �ndice en iIns y un puntero a la OM en pOMCIni.
			iIns = -1;
			COMComb* pOMC;
			// Para empezar creamos una nueva COMComb
			BOOL bNewInsert = FALSE;
			COMComb* pOMCNew = new COMComb(pOM);
			for(;;)
			{
				// Buscamos ahora un solapamiento entre la nueva OM que tenemos y las
				// OMComb que est�n ya en la matriz.
				for (int j=0; j < p_pArrOMComb->GetSize(); j++)
				{
					COMComb* pOMCj = (COMComb*) p_pArrOMComb->GetAt(j);
					
					if (pOMCj->m_AbSpan.GetFecFin() > pOMCNew->m_AbSpan.GetFecIni())
					{
						iIns = j;
						pOMC = pOMCj;
						break;
					}
				}
				if (iIns < 0) // Si no hemos encontrado ninguno es que no hay solapamiento
				{				// por lo que a�adimos una nueva OMComb al final del array.
					p_pArrOMComb->Add(pOMCNew);
					bNewInsert = TRUE;
					break;
				}
				// Si iIns >= 0, es que hay que insertar, y puede haber solapamiento.
				// Comprobamos si hay solapamiento
				CString sU;
				
				sU.Format("%s %s %s %s",
				FormatFec(pOMCNew->m_AbSpan.GetFecIni()),
				FormatFec(pOMCNew->m_AbSpan.GetFecFin()),
				FormatFec(pOMC->m_AbSpan.GetFecIni()),
				FormatFec(pOMC->m_AbSpan.GetFecFin()));
				
				if (!pOMCNew->m_AbSpan.Overlaps(pOMC->m_AbSpan))
				{
					// Si no hay solapamiento, sencillamente insertamos, porque todas
					// las OMComb no tienen solapamientos entre si
					p_pArrOMComb->InsertAt( iIns+1, pOMCNew );
					bNewInsert = TRUE;
					break;
				}
				// Si hay solapamiento, podemos tener varios casos.
				
				//	Que sean exactamente iguales
				if (pOMCNew->m_AbSpan == pOMC->m_AbSpan)
				{
					// Sumamos las dos cadencias y borramos la nueva
					pOMC->m_dCadencia += pOMCNew->m_dCadencia ;
					// Ahora el �ndice de fin es i, no puede haber huecos (creo)
					//delete pOMCNew;
					break;
				}
				// Que la fecha de inicio de la nueva sea menor que la de inicio de la insertada
				if (pOMCNew->m_AbSpan.GetFecIni() < pOMC->m_AbSpan.GetFecIni())
				{
					// Creamos una orden con lo que sobra por arriba de la nueva
					COMComb* pOMCArriba = new COMComb(*pOMCNew);
					pOMCArriba->m_AbSpan.SetFecFin(pOMC->m_AbSpan.GetFecIni());
					// Y actualizamos la nueva para que comienze a la par con la insertada
					pOMCNew->m_AbSpan.SetFecIni(pOMC->m_AbSpan.GetFecIni());
					
					// Cerramos el nuevo al comenzar el insertado y lo insertamos antes
					p_pArrOMComb->InsertAt( iIns, pOMCArriba );
					continue;
				}
				// Ahora el comienzo de la nueva es igual o superior al de la antigua
				
				// Si es superior, dividimos la insertada en 2 para que sean iguales
				if (pOMCNew->m_AbSpan.GetFecIni() > pOMC->m_AbSpan.GetFecIni())
				{
					// Creamos una orden con lo que sobra por arriba de la insertada
					COMComb* pOMCArriba = new COMComb(*pOMC);
					pOMCArriba->m_AbSpan.SetFecFin(pOMCNew->m_AbSpan.GetFecIni());
					p_pArrOMComb->InsertAt( iIns, pOMCArriba );
					// Y actualizamos la insertada para que comienze a la par con la nueva
					pOMC->m_AbSpan.SetFecIni(pOMCNew->m_AbSpan.GetFecIni());
					iIns++;
					continue;
				}
				// Ahora comienzan a la vez. Nos preocupamos por el final
				// Ahora tenemos 3 posibles casos:
				// 1) Que el fin de la nueva sea antes que el de la insertada
				if ( pOMCNew->m_AbSpan.GetFecFin() < pOMC->m_AbSpan.GetFecFin())
				{
					// Creamos una nueva OMComb para cubrir el resto, bas�ndonos en la 
					// ya insertada
					COMComb* pOMCComp = new COMComb(*pOMC);
					// Sumamos las dos cadencias en la ya insertada y le ponemos la fecha
					// de fin igual a la de fin de la nueva
					pOMCComp->m_dCadencia += pOMCNew->m_dCadencia ;
					pOMCComp->m_AbSpan.SetFecFin(pOMCNew->m_AbSpan.GetFecFin());
					// En la reci�n creada, ponemos la fecha de inicio como la misma
					pOMC->m_AbSpan.SetFecIni(pOMCNew->m_AbSpan.GetFecFin());
					// Y la insertamos tras la nueva insertada, actualizando los �ndices
					p_pArrOMComb->InsertAt( iIns, pOMCComp );
					iIns++;					
					break;
					
				}
				// 2) Que sea el mismo
				if ( pOMCNew->m_AbSpan.GetFecFin() == pOMC->m_AbSpan.GetFecFin())
				{
					// Nos limitamos a cambiar la cadencia
					pOMC->m_dCadencia += pOMCNew->m_dCadencia ;
					break;
				}
				// 3) Que sea despu�s
				if ( pOMCNew->m_AbSpan.GetFecFin() > pOMC->m_AbSpan.GetFecFin())
				{
					
					// Cambiamos la cadencia de la actual
					pOMC->m_dCadencia += pOMCNew->m_dCadencia ;
					
					// Y actualizamos el nuevo para que comienze al final del insertado
					pOMCNew->m_AbSpan.SetFecIni(pOMC->m_AbSpan.GetFecFin());
				}
			} // end for(;;)
			if (!bNewInsert) delete pOMCNew;
			bNewInsert = FALSE;
		}
	}
	// Ahora aplicamos el calendario, es decir, las posibles inactividades que tengas las �rdenes.
	AplicarCalendarioOMC(p_pArrOM, p_pArrOMComb);
	return p_pArrOMComb->GetSize();
}

void
CProg::AplicarCalendarioOMC(CObArray* p_pArrOM, CObArray* p_pArrOMComb)
{
	// Empezamos buscando inactividades que afecten a alguna de las �rdenes. Para ello primero hacemos 
	// un ciclo por las OMs, para ver cu�les est�n afectadas por alguna inactividad.
	for (int i = 0; i < p_pArrOM->GetSize(); i++)
	{
		COrdMaq* pOM = (COrdMaq*) p_pArrOM->GetAt(i);
		ASSERT( pOM->IsKindOf( RUNTIME_CLASS( COrdMaq ) ) );
		CObArray pArrInact;
		if (!pOM->GetArrInacts(pArrInact)) continue;	// Si no tiene inactividades vamos al siguiente
		// Resulta que s� que tenemos inactividades. Bueno, pues vamos a ver 
		// con qu� tramos de las combinadas nos coinciden.
		// Hacemos un ciclo por cada una de las inactividades
		for (int j=0; j < pArrInact.GetSize(); j++)
		{
			CAbSpan* pAbSpanInact = (CAbSpan*) pArrInact.GetAt(j);
			// Y la desacoplamos
			DesacoplarInact(pAbSpanInact, pOM, p_pArrOMComb);
		}
	}
}

void
CProg::DesacoplarInact(CAbSpan* p_pAbSpanInact, COrdMaq* p_pOM, CObArray* p_pArrOMComb)
{
	// Tenemos una inactividad asociada a una OM
	// Recorremos la matriz de OMs combinadas, buscando solapamientos.
	CTime FecIniInact = p_pAbSpanInact->GetFecIni();
	CTime FecFinInact = p_pAbSpanInact->GetFecFin();
	for (int i=0; i < p_pArrOMComb->GetSize(); i++)
	{
		COMComb* pOMC = (COMComb*) p_pArrOMComb->GetAt(i);
		CTime FecIniOMC = pOMC->m_AbSpan.GetFecIni();
		CTime FecFinOMC = pOMC->m_AbSpan.GetFecFin();
		CString sDebFecIniOMC = FormatFec(FecIniOMC, FecHora);
		CString sDebFecFinOMC = FormatFec(FecFinOMC, FecHora);
		CString sDebFecIniInact = FormatFec(FecIniInact, FecHora);
		CString sDebFecFinInact = FormatFec(FecFinInact, FecHora);

		if (FecFinOMC <= FecIniInact) continue;
		if (FecIniOMC >= FecFinInact) break;
		// Bien, ahora tenemos varias posibilidades.
		// La primera y m�s sencilla, es que la inactividad englobe por completo a la OMComb
		if (FecFinOMC <= FecFinInact && FecIniOMC >= FecIniInact)
		{
			// Sencillamente descontamos la OM
			pOMC->m_dCadencia -= p_pOM->GetdCadencia();
			if (pOMC->m_dCadencia <= 0)
			{
				p_pArrOMComb->RemoveAt(i);
				delete pOMC;
				i--;
			}
			FecIniInact = FecFinOMC;			
			// Si NO, a lo mejor es la OMComb la que engloba a la inactividad
		} else if (FecIniOMC < FecIniInact && FecFinOMC > FecFinInact)
		{
			// Entonces hay que dividir la orden en 3
			// Habr� que descontar la cadencia s�lo de la parte correspondiente,
			// para lo que habr� que crear dos nuevas OMComb
			COMComb* pOMCNew = new COMComb(*pOMC);
			COMComb* pOMCNew2 = new COMComb(*pOMC);
			// Primero acortamos la completa para que acabe donde empieza la inactividad
			pOMC->m_AbSpan.SetFecFin( FecIniInact );
			// Y ahora hacemos que la nueva sea igual a la inactividad y le ponemos la buena cadencia
			pOMCNew->m_AbSpan.SetFecIni( FecIniInact );
			pOMCNew->m_AbSpan.SetFecFin( FecFinInact );
			pOMCNew->m_dCadencia -= p_pOM->GetdCadencia();
			if (pOMCNew->m_dCadencia <= 0) // Si nos hemos quedado sin cadencia la borramos
			{
				delete pOMCNew;
			} else	// Si nos queda cadencia la insertamos tras la otra
			{
				p_pArrOMComb->InsertAt(i+1, pOMCNew);
				i++;	// Para que siga con la siguiente
			}
			pOMCNew2->m_AbSpan.SetFecIni( FecFinInact );
			p_pArrOMComb->InsertAt(i+1, pOMCNew2);
			// Realmente ya hemos terminado con esa inactividad
			break;
		// Si no , puede solaparse por el inicio de la inactividad
		} else if (FecIniOMC < FecIniInact)
		{
			// Habr� que descontar la cadencia s�lo de la parte correspondiente,
			// para lo que habr� que crear una nueva OMComb
			COMComb* pOMCNew = new COMComb(*pOMC);
			// Primero acortamos la completa para que acabe donde empieza la inactividad
			pOMC->m_AbSpan.SetFecFin( FecIniInact );
			// Y ahora hacemos que la nueva comienze tambi�n ah� y le ponemos la buena cadencia
			pOMCNew->m_AbSpan.SetFecIni( FecIniInact );
			pOMCNew->m_dCadencia -= p_pOM->GetdCadencia();
			if (pOMCNew->m_dCadencia <= 0) // Si nos hemos quedado sin cadencia la borramos
			{
				delete pOMCNew;
			} else	// Si nos queda cadencia la insertamos tras la otra
			{
				p_pArrOMComb->InsertAt(i+1, pOMCNew);
				i++;	// Para que siga con la siguiente
			}
			FecIniInact = FecFinOMC;			
			// o por el final
		} else if (FecFinOMC > FecFinInact)
		{
			// Habr� que descontar la cadencia s�lo de la parte correspondiente,
			// para lo que habr� que crear una nueva OMComb
			COMComb* pOMCNew = new COMComb(*pOMC);
			// Primero acortamos la completa para que empieze donde acaba la inactividad
			pOMC->m_AbSpan.SetFecIni( FecFinInact );
			// Y ahora hacemos que la nueva acabe tambi�n ah� y le ponemos la buena cadencia
			pOMCNew->m_AbSpan.SetFecFin( FecFinInact );
			pOMCNew->m_dCadencia -= p_pOM->GetdCadencia();
			if (pOMCNew->m_dCadencia <= 0) // Si nos hemos quedado sin cadencia la borramos
			{
				delete pOMCNew;
			} else	// Si nos queda cadencia la insertamos antes de la otra
			{
				p_pArrOMComb->InsertAt(i, pOMCNew);
			}
			// Ya hemos terminado
			break;
		}
	}
}


// Inserta una nueva orden, dando la opcion de modificar los datos o cancelar
BOOL 
CProg::InsertNewOM(COrdMaq* p_pOM, BOOL& p_rbModif)
{
	BOOL bCancelar;
	p_rbModif = FALSE;
	if (p_pOM == NULL)
	{          
		AfxMessageBox(STRID(IDS_ERR_NOORDSEL));
		return FALSE;
	}
	COrdenDlg OrdenDlg(p_pOM, this, AfxGetMainWnd());
	
	OrdenDlg.m_BReadOnly = FALSE;
	
	OrdenDlg.m_sCantidad = FormatLong(p_pOM->GetlCantidad(), 6);
	OrdenDlg.m_FecEnt = p_pOM->GetFecEnt();;
	OrdenDlg.m_sFinal =	FormatFec( p_pOM->GetFecFin() );
	OrdenDlg.m_FecIni = p_pOM->GetFecIni() ;
	
	OrdenDlg.m_lLote = p_pOM->GetlLote();
	OrdenDlg.m_sChatarras.Format("%.1lf", p_pOM->GetdChatarras());
	OrdenDlg.m_lOrdFab = p_pOM->GetlOF();
	OrdenDlg.m_sTiempo = FormatFec( p_pOM->GetTimeSpan() );
	OrdenDlg.m_BFecFija = p_pOM->GetBFija();
	BOOL bFecFijaIni = OrdenDlg.m_BFecFija;
	OrdenDlg.m_sCadencia.Format("%.0lf ", p_pOM->GetdCadencia());
	OrdenDlg.m_BTiempoFijo = p_pOM->GetBTiempoFijo();
	BOOL bTiempoFijoIni = OrdenDlg.m_BTiempoFijo;
	OrdenDlg.m_BSelected = p_pOM->GetBSelected();
	if (p_pOM->GetlCantFab())
	{
		OrdenDlg.m_sFabricadas = FormatLong(p_pOM->GetlCantFab(), 6);
		OrdenDlg.m_FecFab = p_pOM->GetFecFab();
		OrdenDlg.m_sRestantes = FormatLong(p_pOM->GetlCantidad() - p_pOM->GetlCantFab(), 6);
	} else {
		OrdenDlg.m_sFabricadas = "";
		OrdenDlg.m_FecFab = CTime::GetCurrentTime();
		OrdenDlg.m_sRestantes = "";
	}
	OrdenDlg.m_sInactividad.Format("%.1lf %%", p_pOM->GetdInactividad());
	
	
	CString sTemp = p_pOM->GetsNombre() + ' '
		+ " (" + p_pOM->GetsID() + ')';
	if (p_pOM->GetpPM() != NULL)
	{
		sTemp += " en " + p_pOM->GetpPM()->GetsID();
	}
	OrdenDlg.m_sCaption = sTemp;
	
	int iDlgStat = OrdenDlg.DoModal();
	bCancelar = OrdenDlg.m_bCancelar;
	p_rbModif = OrdenDlg.m_bInsertada;
	if (!OrdenDlg.m_bInsertada) 
	{
		delete p_pOM;
		return bCancelar;
	}
		
	if (iDlgStat != IDOK) return bCancelar;
	
	if (bFecFijaIni != OrdenDlg.m_BFecFija)
	{
		CWaitCursor WaitCursor;
		p_pOM->SetBFija(OrdenDlg.m_BFecFija);
		Recalc();
	}
	if (bTiempoFijoIni != OrdenDlg.m_BTiempoFijo)
	{
		CWaitCursor WaitCursor;
		p_pOM->SetBTiempoFijo(OrdenDlg.m_BTiempoFijo);
		Recalc();
	}

	return bCancelar;
}



void CProg::GetArrPM(CObArray &p_PMArr)
{
		p_PMArr.RemoveAll();
		p_PMArr.Copy(*m_pArrPMs);
}

int CProg::GetNumOM()
{
	int iNumOM = 0;
	for (int i=0; i< GetNumPM(); i++)
	{                               
		CProgMaq* pPM = GetpPM(i);
		iNumOM += pPM->GetNumOM();
	}
	return iNumOM;

}

// Devolvemos el puntero a la COMC correspondiente a un Art�culo
COMC*
CProg::GetpOMC(const CString& p_sIDArt)
{
	if (p_sIDArt == "") return NULL;
	COMC BuscOMC;
	BuscOMC.m_sID = p_sIDArt;
	int iInd = m_pArrOMs->Find(&BuscOMC);
	if (iInd < 0) return NULL;
	COMC* pOMC = (COMC*) m_pArrOMs->GetAt(iInd);
	if (!pOMC) return NULL;
	ASSERT( pOMC->IsKindOf( RUNTIME_CLASS( COMC ) ) );
	return pOMC;
}

// Comc Class

IMPLEMENT_SERIAL(COMC, CObject, 1)

BOOL
COMC::HaySolapes()
{
	// Solo hay una, es falso
	if (m_pOM) return FALSE;
	if (m_pArrOM->GetSize() < 2) return FALSE;
	// Si los arrays son distintos, es que hay solapes
	if (m_pArrOM->GetSize() != m_pArrCOMComb->GetSize()) return TRUE;
	for (int i=1; i < m_pArrOM->GetSize(); i++)
	{
		COrdMaq* pOM = (COrdMaq*) m_pArrOM->GetAt(i);
		COMComb* pOMComb = (COMComb*) m_pArrCOMComb->GetAt(i);
		if (pOM->GetFecIni() != pOMComb->m_AbSpan.GetFecIni() ||
			pOM->GetFecFin() != pOMComb->m_AbSpan.GetFecFin() )
			return TRUE;
	}
	return FALSE;
}

void
COMC::GetArrOMsAfec( COMComb* p_pOMComb, CObArray* p_pArrOMs)
{
	p_pArrOMs->RemoveAll();

	for (int i=0; i < m_pArrOM->GetSize(); i++)
	{
		COrdMaq* pOM = (COrdMaq*) m_pArrOM->GetAt(i);
		CProgMaq* pPM = pOM->GetpPM();
		// Si est� comprendido y no est� afectada por inactividad en ese periodo
		if (pOM->GetFecIni() <= p_pOMComb->m_AbSpan.GetFecIni() &&
			pOM->GetFecFin() >= p_pOMComb->m_AbSpan.GetFecFin() &&
			pPM && !pPM->HayInactEn(p_pOMComb->m_AbSpan))
		{
			p_pArrOMs->Add(pOM);
		}
	}
}

// Reparte una cantidad entre las OMs de la COMC, de acuerdo con los solapes
// e inactividades reflejadas en las COMComb. Las cantidades que le tocan a
// cada OM se meten en las OMs, en el campo m_lAux
long
COMC::ReparteCant(long p_lCant)
{
	// Primero ponemos a 0 los m_lAux
	if (m_pArrOM)
	{
		for(int i = 0; i < m_pArrOM->GetSize(); i++)
		{
			COrdMaq* pOM = (COrdMaq*) m_pArrOM->GetAt(i);
			pOM->m_lAux = 0;
		}
	} else
	{
		if (m_pOM) m_pOM->m_lAux = 0;
	}
	//Recorremos directamente la matriz de OMComb
	CObArray* pArrComb = m_pArrCOMComb;
	// Necesitaremos una matriz de OMs
	CObArray ArrOMs;
	// Y Un acumulado para saber cu�ntas llevamos repartidas
	long lAcumCant = 0;
	// Hacemos un ciclo por los elementos del pArrComb
	for (int i = 0; i < pArrComb->GetSize(); i++)
	{
		COMComb* pOMComb = (COMComb*) pArrComb->GetAt(i);
		ASSERT( pOMComb->IsKindOf( RUNTIME_CLASS( COMComb ) ) );
		// Ahora tenemos que saber a cu�ntas OMs afecta esta COMComb
		GetArrOMsAfec(pOMComb, &ArrOMs);
		// Tambi�n el n�mero de piezas que se fabrica en esta combinada
		long lCant = pOMComb->GetlCantFab();
		// No podemos descontar m�s de lo que hay
		if (lCant > p_lCant) lCant = p_lCant;
		// Calculamos el porcentaje que le corresponde a cada orden. Primero la suma
		// de las cadencias afectadas
		double dSumaCad = 0;
		for (int iK = 0; iK < ArrOMs.GetSize(); iK++)
		{
			COrdMaq* pOM = (COrdMaq*) ArrOMs.GetAt(iK);
			dSumaCad += pOM->GetdCadencia();
		}
		if (dSumaCad != pOMComb->m_dCadencia)
		{
			CString sMsg;
			sMsg.Format("Distintas cadencias en ReparteCant : %f %f \n", dSumaCad, pOMComb->m_dCadencia );
			TRACE(sMsg);
		}
		// Ahora repartimos la cantidad de acuerdo a los porcentajes
		// Primero ponemos el porcentaje en m_dAux
		for (iK = 0; iK < ArrOMs.GetSize(); iK++)
		{
			COrdMaq* pOM = (COrdMaq*) ArrOMs.GetAt(iK);
			pOM->m_dAux = pOM->GetdCadencia() / dSumaCad;
		}
		for (iK = 0; iK < ArrOMs.GetSize(); iK++)
		{
			COrdMaq* pOM = (COrdMaq*) ArrOMs.GetAt(iK);
			long lDescCant = (long) (pOM->m_dAux * (double) lCant + 1);
			pOM->m_lAux += lDescCant;
			lAcumCant += lDescCant;

		}

		// Descontamos las piezas asignadas
		p_lCant -= lCant;
		// Si ya hemos asignado todas, terminamos
		if (p_lCant <= 0) break;
	}
	return lAcumCant;
}

