// OrdenDlg.cpp : implementation file
//

#include "stdafx.h"
#include "afxdtctl.h"
#include "cpw.h"

#include "AbSpan.h"
#include "prog.h" 
#include "cpwDb.h"
#include "cpwExt.h"
#include "cpwDefs.h"
#include "cache.h"            
#include "ProgMaq.h"
#include "OrdMaq.h"    
#include "Dialogs.h"
#include "cpwView.h"
#include "TextView.h"
#include "OrdenDlg.h"

#include "strstrea.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COrdenDlg dialog


COrdenDlg::COrdenDlg( COrdMaq* p_pOM, CProg* p_pProg, CWnd* p_pParent /*=NULL*/)
	: CDialog(COrdenDlg::IDD, p_pParent)
{
	ASSERT_VALID(p_pOM);   
	m_bInsertada = FALSE;
	m_bCancelar = FALSE;
	m_pOM = p_pOM;
	m_pProg = p_pProg;
	m_sCaption = "";
	m_pView = (CView*) p_pParent;
	if (m_pView->IsKindOf( RUNTIME_CLASS( CCpwView ) ))
	{
		m_bEntrada = FALSE;
		m_pCpwView = (CCpwView*) m_pView;
	} else
	{
		m_bEntrada = TRUE;
	}

	//{{AFX_DATA_INIT(COrdenDlg)
	m_sCantidad = _T("");
	m_sFinal = _T("");
	m_sMaquinas = _T("");
	m_lOrdFab = 0;
	m_sTiempo = _T("");
	m_FecEnt = 0;
	m_BFecFija = FALSE;
	m_FecIni = 0;
	m_sCadencia = _T("");
	m_sFabricadas = _T("");
	m_FecFab = 0;
	m_sInactividad = _T("");
	m_sRestantes = _T("");
	m_BTiempoFijo = FALSE;
	m_BSelected = FALSE;
	m_sMaqMol = _T("");
	m_lLote = 0;
	m_sChatarras = _T("");
	m_sMolde = _T("");
	m_sInsMaq = _T("");
	m_sCavidades = _T("");
	m_sConsumo = _T("");
	m_sMezcla = _T("");
	m_sMezclaKilos = _T("");
	m_sPesoGramos = _T("");
	m_sRestCant = _T("");
	m_sRestHoras = _T("");
	//}}AFX_DATA_INIT
}


void COrdenDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(COrdenDlg)
	DDX_Control(pDX, IDC_INSMAQ, m_ComboInsMaq);
	DDX_Control(pDX, IDC_CADENCIA, m_EditCadencia);
	DDX_Control(pDX, IDC_FINALIZAR, m_ButtonFinalizar);
	DDX_Control(pDX, IDC_BORRAR, m_ButtonBorrar);
	DDX_Control(pDX, IDC_AJUSTAR, m_ButtonAjustar);
	DDX_Control(pDX, IDC_MOLDE, m_ComboMolde);
	DDX_Control(pDX, IDC_MAQMOL, m_LstMaqMol);
	DDX_Control(pDX, IDC_TIEMPO, m_EditTiempo);
	DDX_Control(pDX, IDC_SELECTED, m_ButtonSelected);
	DDX_Control(pDX, IDC_CANTIDAD, m_EditCantidad);
	DDX_Control(pDX, IDC_TIEMPO_FIJO, m_ButtonTiempoFijo);
	DDX_Control(pDX, IDC_FECFAB, m_DTctrlFecFab);
	DDX_Control(pDX, IDC_FECINI, m_DTctrlFecIni);
	DDX_Control(pDX, IDC_FECHA_FIJA, m_ButtonFecFija);
	DDX_Control(pDX, IDC_FECENT, m_DTctrlFecEnt);
	DDX_Control(pDX, IDC_MAQUINAS, m_LstMaquinas);
	DDX_Text(pDX, IDC_CANTIDAD, m_sCantidad);
	DDX_Text(pDX, IDC_FINAL, m_sFinal);
	DDX_LBString(pDX, IDC_MAQUINAS, m_sMaquinas);
	DDX_Text(pDX, IDC_ORDFAB, m_lOrdFab);
	DDX_Text(pDX, IDC_TIEMPO, m_sTiempo);
	DDX_DateTimeCtrl(pDX, IDC_FECENT, m_FecEnt);
	DDX_Check(pDX, IDC_FECHA_FIJA, m_BFecFija);
	DDX_DateTimeCtrl(pDX, IDC_FECINI, m_FecIni);
	DDX_Text(pDX, IDC_CADENCIA, m_sCadencia);
	DDX_Text(pDX, IDC_FABRICADAS, m_sFabricadas);
	DDX_DateTimeCtrl(pDX, IDC_FECFAB, m_FecFab);
	DDX_Text(pDX, IDC_INACTIVIDAD, m_sInactividad);
	DDX_Text(pDX, IDC_RESTANTES, m_sRestantes);
	DDX_Check(pDX, IDC_TIEMPO_FIJO, m_BTiempoFijo);
	DDX_Check(pDX, IDC_SELECTED, m_BSelected);
	DDX_LBString(pDX, IDC_MAQMOL, m_sMaqMol);
	DDX_Text(pDX, IDC_LOTE, m_lLote);
	DDX_Text(pDX, IDC_CHATARRAS, m_sChatarras);
	DDX_CBString(pDX, IDC_MOLDE, m_sMolde);
	DDX_CBString(pDX, IDC_INSMAQ, m_sInsMaq);
	DDX_Text(pDX, IDC_CAVIDADES, m_sCavidades);
	DDX_Text(pDX, IDC_CONSUMO, m_sConsumo);
	DDX_Text(pDX, IDC_MEZCLA, m_sMezcla);
	DDX_Text(pDX, IDC_MEZCLAKILOS, m_sMezclaKilos);
	DDX_Text(pDX, IDC_PESOGRAMOS, m_sPesoGramos);
	DDX_Text(pDX, IDC_RESTCANT, m_sRestCant);
	DDX_Text(pDX, IDC_RESTHORAS, m_sRestHoras);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(COrdenDlg, CDialog)
	//{{AFX_MSG_MAP(COrdenDlg)
	ON_BN_CLICKED(IDC_BORRAR, OnBorrar)
	ON_LBN_DBLCLK(IDC_MAQUINAS, OnDblclkMaquinas)
	ON_LBN_SELCHANGE(IDC_MAQUINAS, OnSelchangeMaquinas)
	ON_LBN_DBLCLK(IDC_MAQMOL, OnDblclkMaqmol)
	ON_BN_CLICKED(IDC_FINALIZAR, OnFinalizar)
	ON_BN_CLICKED(IDC_AJUSTAR, OnAjustar)
	ON_CBN_SELCHANGE(IDC_INSMAQ, OnSelchangeInsmaq)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COrdenDlg message handlers

BOOL COrdenDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	ASSERT_VALID(m_pOM);
	
	
	// Si no esta ya hacemos una lista de maquinas a las que puede ir
	g_pCache->GetArrMaq(m_pOM->GetsID(), m_ArrListaMaq, m_ArrListaMoldes);
	int iLimListaMaq = m_ArrListaMaq.GetSize();
	CString sMolAnt = "";
	BOOL bRep = FALSE;
	for(int ix = 0; ix < iLimListaMaq; ix++)
	{
		CBufMaquina* pBufMaquina = (CBufMaquina*) m_ArrListaMaq.GetAt(ix);
		CBufMolde* pBufMolde = (CBufMolde*) m_ArrListaMoldes.GetAt(ix);
		//ASSERT_VALID(pBufMaquina);
		CProgMaq* pPM = m_pProg->FindMaq(pBufMaquina->m_sID);
		CString sLin;
		if (sMolAnt == pBufMolde->m_sID ) bRep = TRUE;
		else bRep = FALSE;
		sLin.Format("%3.3s %s", pBufMaquina->m_sID, ( bRep ? "" : pBufMolde->m_sID));
		sMolAnt = pBufMolde->m_sID;
		m_LstMaqMol.AddString(sLin);
		// Tambi�n a�adimos los moldes al combo de moldes
		if (!bRep) m_ComboMolde.AddString(pBufMolde->m_sID);
	}
	// Hacemos una lista de todas las m�quina, para que inserte si no le valen las otras
	m_pProg->GetArrPM( m_ArrTodasMaq );
	for (int i=0; i<m_ArrTodasMaq.GetSize(); i++)
	{                           
		CProgMaq* pPM = (CProgMaq*) m_ArrTodasMaq.GetAt(i);
		//ASSERT_VALID(pPM);           
		m_ComboInsMaq.AddString(pPM->GetsID());
	}               
	
	m_pProg->GetArrOMArt( &m_ArrOM , m_pOM->GetsID());
	
	for (i=0; i<m_ArrOM.GetSize(); i++)
	{                           
		COrdMaq* pOM = (COrdMaq*) m_ArrOM.GetAt(i);
		//ASSERT_VALID(pOM);           
		m_LstMaquinas.AddString(pOM->GetsInfo());
	}               
	
	m_DTctrlFecIni.SetFormat("dd/MM/yy H:mm");
	if (!m_bEntrada)
	{
		m_sCaption = " DATOS OFERTA " + m_pOM->GetsID() + ' ';
		if (m_pOM->GetpPM() != NULL)
		{
			m_sCaption += " en " + m_pOM->GetpPM()->GetsNombre();
		}
	}
	else
	{
		m_sCaption = "PROGRAMANDO OFERTA " + m_pOM->GetsID();
	}
	
	SetWindowText(m_sCaption);
	
	m_sMolde = m_pOM->GetsMolde();
	m_sInsMaq = m_pOM->GetsMaquina();
	

	m_ComboMolde.SetWindowText(m_sMolde);
	m_ComboInsMaq.SetWindowText(m_sInsMaq);
	//m_ButtonAjustar.SetWindowText(FormatLong(m_pOM->CalcCantLote(),7));
	
	if (m_bEntrada)
	{
		m_ButtonBorrar.EnableWindow(FALSE);
		m_ButtonFinalizar.EnableWindow(TRUE);
	}
	else
	{
		m_ButtonBorrar.EnableWindow(TRUE);
		m_ButtonFinalizar.EnableWindow(FALSE);
	}
	// Si el documento es Read Only, no permitiremos modificar la BD
	
	if (m_BReadOnly)
	{
		m_EditCantidad.SetReadOnly();
		m_DTctrlFecEnt.EnableWindow(FALSE);
	}

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void COrdenDlg::OnBorrar() 
{
	CString sMsg = STRID( IDS_CONF_BORRORD );
	CString sCap = STRID( IDS_CONF_CAPTION );
	if (MessageBox( sMsg, sCap, MB_OKCANCEL ) != IDOK ) return;

	CObArray DelArray;                                             
	
	CProgMaq* pPM = m_pOM->GetpPM();
	ASSERT_VALID(pPM);
//	CObArray ArrOM;
//	if ( m_pProg->GetArrOM( &ArrOM , m_pOM->GetpOF()) == 0)
//		TRACE("Error en COrdenDlg::OnInitDialog, no hay OMs asociadas"); 

	COrdMaq* pOM = m_pOM;
	ASSERT_VALID(pOM); 
	CProgMaq* pPMi = pOM->GetpPM();
	ASSERT_VALID(pPMi);
	int i = pOM->PMIndex();
	if ( i < 0 ) TRACE("Error en COrdenDlg::OnInitDialog, no se encuentra la orden en la m�quina");
	pPMi->RemoveAt(i);
	delete pOM;
	CWaitCursor();
	m_pProg->Recalc();
	EndDialog(IDOK);	
}


void COrdenDlg::OnOK() 
{
	ActOM();		// Actualizamos la OM
	CDialog::OnOK();
}

void COrdenDlg::OnDblclkMaquinas() 
{
	ASSERT_VALID(m_pOM);
	
	CString sSelection;
	int iSel = m_LstMaquinas.GetCurSel();
	if (iSel == LB_ERR || iSel >= m_ArrOM.GetSize()) return;
	
	
	COrdMaq* pOMenPM = (COrdMaq*) m_ArrOM.GetAt(iSel);
	ActOM();
	if (!m_bEntrada)
	{
		m_pProg->UnselectAll();			
	
		
		CRect RectOM = m_pCpwView->GetRect(pOMenPM);
		RectOM.left += m_pCpwView->m_SepWidth;
		CRect RectWnd;
		m_pCpwView->GetClientRect(&RectWnd);
		CFrameWnd* pFrame = GetParentFrame();
		if (!pFrame) return;
		
		CPoint PointDesp;
		PointDesp.x = RectOM.left - TK_POINTS_COL;
		if (PointDesp.x < 0) PointDesp.x = 0;
		m_pCpwView->SetScrollPos(SB_HORZ, PointDesp.x);
		PointDesp.y = RectOM.top - m_pCpwView->m_HeadHeight;
		if (PointDesp.y < 0) PointDesp.y = 0;
		m_pCpwView->SetScrollPos(SB_VERT, PointDesp.y);
		
		PointDesp = m_pCpwView->GetDeviceScrollPosition();
		CRect RectWin;
		m_pCpwView->GetWindowRect(&RectWin);
		CRect RectCursorPos = RectOM - PointDesp + CPoint(RectWin.left, RectWin.top);
		SetCursorPos(pOMenPM->GetBFija() ? RectCursorPos.left - m_pCpwView->m_SepWidth + 3 : RectCursorPos.left,
			RectCursorPos.top + 3	);
		
		PostMessage(WM_CLOSE);
		m_pCpwView->Invalidate();
	}
	else // Es una entrada de OM
	{
		// Como es una entrada de �rdenes, quiere decir que lo queremos a�adir
		// a la ya existente. Pedimos confirmaci�n.
		CString sMsg;
		sMsg.Format(STRID(IDS_CONF_ADDCANT), m_pOM->GetlCantidad() );
		if (MessageBox(sMsg, STRID(IDS_CONF_CAPTION), MB_OKCANCEL) != IDOK) return;
		
		pOMenPM->ModifCant(pOMenPM->GetlCantidad() + m_pOM->GetlCantidad());
		pOMenPM->RecalcFin();
		PostMessage(WM_CLOSE);

	}
	
}

void COrdenDlg::OnSelchangeMaquinas() 
{
	ASSERT_VALID(m_pOM);
	
	CString sSelection;
	int iSel = m_LstMaquinas.GetCurSel();
	if (iSel == LB_ERR || iSel >= m_ArrOM.GetSize()) return;
	
	
		
	// Buscamos la m�quina por ID
	COrdMaq* pOMenPM = (COrdMaq*) m_ArrOM.GetAt(iSel);
	if (pOMenPM == NULL)
	{
		CString sMsg = STRID(IDS_ERR_NOOMENPM );
		MessageBox(sMsg, "Error");
		return;
	}
	CProgMaq* pPM = pOMenPM->GetpPM();
	if (pPM == NULL)
	{
		CString sMsg = STRID( IDS_ERR_NOMAQID );
		MessageBox(sMsg, STRID( IDS_ERROR ));
		return;
	}
	// Ahora ya tenemos la orden, rellenamos los datos del di�logo con los valores nuevos
	// Si es que estamos en consulta
	if (!m_bEntrada)
	{
		m_pCpwView = (CCpwView*) m_pView;

		m_sFinal =	FormatFec( pOMenPM->GetFecFin() );
		m_FecIni = pOMenPM->GetFecIni() ;
		
		m_sTiempo = FormatFec( pOMenPM->GetTimeSpan() );
		m_BFecFija = pOMenPM->GetBFija();
		m_sCadencia.Format("%.0lf", pOMenPM->GetdCadencia());
		m_BTiempoFijo = pOMenPM->GetBTiempoFijo();
		m_BSelected = pOMenPM->GetBSelected();
		if (pOMenPM->GetlCantFab())
		{
			m_sFabricadas = FormatLong(pOMenPM->GetlCantFab(), 6);
			m_FecFab = pOMenPM->GetFecFab();
			m_sRestantes = FormatLong(pOMenPM->GetlCantidad(), 6);
		} else {
			m_sFabricadas = "";
			m_FecFab = CTime::GetCurrentTime();
			m_sRestantes = "";
		}
		m_sCantidad = FormatLong(pOMenPM->GetlCantidad(), 6);
		m_sInactividad.Format("%.0lf %%", pOMenPM->GetdInactividad());
		
		m_sCaption = " DATOS OFERTA " + m_pOM->GetsID() + ' ';
		if (m_pOM->GetpPM() != NULL)
		{
			m_sCaption += " en " + m_pOM->GetpPM()->GetsNombre();
		}
		
		// Ahora tenemos que hacerla la seleccionada
		m_pProg->UnselectAll();			
		m_pCpwView->m_pSelOM = pOMenPM;			
		m_pCpwView->Invalidate();
		UpdateData(FALSE);
		SetWindowText(m_sCaption);
	}

}

void 
COrdenDlg::OnDblclkMaqmol() 
{
	ASSERT_VALID(m_pOM);
	
	CString sSelection;
	int iSel = m_LstMaqMol.GetCurSel();
	if (iSel == LB_ERR || iSel >= m_ArrListaMaq.GetSize()) return;
	
	CProgMaq* pPM = NULL;
	CBufMaquina* pBufMaq = (CBufMaquina*) m_ArrListaMaq.GetAt(iSel);
	CBufMolde* pBufMolde = (CBufMolde*) m_ArrListaMoldes.GetAt(iSel);
	int iLim = m_pProg->GetNumPM();
	for (int i = 0; i < iLim; i++)
	{
		CProgMaq* pPMi = m_pProg->GetpPM(i);
		if (pBufMaq->m_sID == pPMi->GetsID())
		{
			pPM = pPMi;
			break;
		}
	}
	if (pPM == NULL) return;
	
	if (!m_bEntrada)
	{
		if (pPM == m_pOM->GetpPM()) return;
		m_pProg->MoveOrdMaq(pPM, m_pOM, pPM->GetNumOM());
	}
	else
	{
		ActOM();
		if (MessageBox(STRID(IDS_CONF_ADDMAQ) + pPM->GetsID(), STRID(IDS_CONF_CAPTION), MB_OKCANCEL)
			!= IDOK) return;
		m_pOM->SetpBufMolde(pBufMolde);
		pPM->Add(m_pOM);
		m_pOM->RecalcFin();
		CBufArticulo* pBufArt = m_pOM->GetpBufArticulo();
		if (!pBufArt) return;
		if (pBufArt->m_pArrArtMol->GetSize() > 1) // Si s�lo hay un molde no tenemos m�s opciones
		{
			// Si no, miramos si hay algun otro molde mejor
			// Lo mejor es un molde que ya se haya usado hace poco en la m�quina
			BOOL bMejorMolde = FALSE;
			CObArray ArrMoldesUsados;
			pPM->GetArrMoldesYaUsados(m_pOM->GetsID(), ArrMoldesUsados);
			// Lo recorremos al rev�s porque es mejor usar el molde cuanto m�s cerca est� del final
			for (int iMU=ArrMoldesUsados.GetSize()-1;  iMU >= 0; iMU--)
			{
				CBufMolde* pBufMoldeUsado = (CBufMolde*) ArrMoldesUsados.GetAt(iMU);
				m_pOM->SetpBufMolde(pBufMoldeUsado);
				m_pOM->RecalcFin();
				m_pProg->CalcArrOMC(); // Para ver si hay conflictos de moldes
				if (m_pOM->GetbConfMolde()) continue; // Si lo hay, probamos con otro
				else
				{
					bMejorMolde = TRUE;
					break;
				}
			}
			// Si no hemos encontrado un mejor molde, seguimos buscando, ahora por todos
			// los posibles moldes
			CObArray ArrMoldesEnMaq;
			if (!bMejorMolde)
			{
				g_pCache->GetArrMolMaq(pPM->GetsID(), ArrMoldesEnMaq, &(m_pOM->GetsID()));
				for (int iMM=0; iMM < ArrMoldesEnMaq.GetSize(); iMM++)
				{
					CBufMolde* pBufMoldeEnMaq = (CBufMolde*) ArrMoldesEnMaq.GetAt(iMM);
					m_pOM->SetpBufMolde(pBufMoldeEnMaq);
					m_pOM->RecalcFin();
					m_pProg->CalcArrOMC(); // Para ver si hay conflictos de moldes
					if (m_pOM->GetbConfMolde()) continue; // Si lo hay, probamos con otro
					else
					{
						bMejorMolde = TRUE;
						break;
					}
				}
				
			}		
			if (!bMejorMolde)	// Si no hay un mejor molde, cogemos el seleccionado
			{
				m_pOM->SetpBufMolde(pBufMolde);
				m_pOM->RecalcFin();			
			}
		}

		m_bInsertada = TRUE;
		PostMessage(WM_CLOSE);	
	}
}	
	

void COrdenDlg::OnFinalizar() 
{
	m_bCancelar = TRUE;	
	PostMessage(WM_CLOSE);
}

void COrdenDlg::OnAjustar() 
{
	/*
	CString sCant;
	sCant.Format("%ld", m_pOM->CalcCantLote());
	m_EditCantidad.SetWindowText(sCant);
	*/
	CDlgAjustar DlgAjustar;
	DlgAjustar.m_pOrdenDlg = this;
	DlgAjustar.m_sCantAct = m_sCantidad;
	DlgAjustar.m_sCadAnt = m_sCadencia;
	DlgAjustar.m_sExistencias = FormatLong(m_pOM->GetlCantMezcla(),7);
	CTimeSpan tsOM = m_pOM->GetTimeSpan();
	// Lo convertimos a horas * 100, esto es porque necesitamos enteros para que funcionen los spinners
	DlgAjustar.m_lHoras = (long) ((double) tsOM.GetTotalMinutes() / .6); 
	DlgAjustar.m_lRatio = (long) (((double) m_pOM->GetlCantidad() * m_pOM->GetlPeso()) / (10 * m_pOM->GetlLote())); 
	DlgAjustar.m_lCadNue = (long) (m_pOM->GetdCadencia() * 100);
											
	DlgAjustar.m_sLote = FormatLong(m_lLote,5);
	DlgAjustar.m_sMaterial.Format("%.1f", (double) (m_pOM->GetlCantidad() * m_pOM->GetlPeso()) / 1000);
	
	if (DlgAjustar.DoModal() == IDOK)
	{
	}
}

void COrdenDlg::OnSelchangeInsmaq() 
{
	
	ASSERT_VALID(m_pOM);
	
	int iSel = m_ComboInsMaq.GetCurSel();
	if (iSel == LB_ERR || iSel >= m_ArrTodasMaq.GetSize()) return;
	
	CProgMaq* pPM = (CProgMaq*) m_ArrTodasMaq.GetAt(iSel);
	if (pPM == NULL) return;
/*	
	if (m_pOM->LimitMaquina(pPM->GetsID()))
	{
		CString sMsg = STRID( IDS_WAR_MAQNOP );
		CString sCap = STRID( IDS_WARNING );
		
		if (MessageBox(sMsg, sCap, MB_OKCANCEL)  != IDOK)
			return;
		g_pCache->ActLimitMaq(m_pOM->GetsMolde(), pPM->GetsID());
	}
*/
	ActOM();	// Actualizamos la OrdMaq
	if (!m_bEntrada)
	{
		if (pPM == m_pOM->GetpPM()) return;
		m_pProg->MoveOrdMaq(pPM, m_pOM, pPM->GetNumOM());
		PostMessage(WM_CLOSE);
		m_pCpwView->Invalidate();
		
	}
	else
	{
		//m_pOM->SetpBufMolde(pBufMolde);
		pPM->Add(m_pOM);
		m_pOM->RecalcFin();
		m_bInsertada = TRUE;
		PostMessage(WM_CLOSE);

	}

	
}
/////////////////////////////////////////////////////////////////////////////
// CDlgAjustar dialog

	static BOOL bCut = FALSE;

CDlgAjustar::CDlgAjustar(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgAjustar::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgAjustar)
	m_sCadAnt = _T("");
	m_sCantAct = _T("");
	m_sCantNue = _T("");
	m_sExistencias = _T("");
	m_sMaterial = _T("");
	m_sLote = _T("");
	m_lCadNue = 0;
	m_lHoras = 0;
	m_lRatio = 0;
	//}}AFX_DATA_INIT
	m_UdAcRatio.nSec = 1;
	m_UdAcRatio.nInc = 10;
	m_UdAcHoras.nSec = 1;
	m_UdAcHoras.nInc = 10;
	m_UdAcCad.nSec = 1;
	m_UdAcCad.nInc = 10;

	m_pOrdenDlg = NULL; // Habr� de ser rellenado antes de OnInitDialog()
}


void CDlgAjustar::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgAjustar)
	DDX_Control(pDX, IDC_LOTE, m_EditLote);
	DDX_Control(pDX, IDC_SPIN_RATIO, m_SpinRatio);
	DDX_Control(pDX, IDC_SPIN_HORAS, m_SpinHoras);
	DDX_Control(pDX, IDC_SPIN_CAD, m_SpinCad);
	DDX_Control(pDX, IDC_RATIO, m_EditRatio);
	DDX_Control(pDX, IDC_MATERIAL, m_EditMaterial);
	DDX_Control(pDX, IDC_HORAS, m_EditHoras);
	DDX_Control(pDX, IDC_EXISTENCIAS, m_EditExistencias);
	DDX_Control(pDX, IDC_CANT_NUE, m_EditCantNue);
	DDX_Control(pDX, IDC_CANT_ACT, m_EditCantAct);
	DDX_Control(pDX, IDC_CAD_NUE, m_EditCadNue);
	DDX_Control(pDX, IDC_CAD_ANT, m_EditCadAnt);
	DDX_Text(pDX, IDC_CAD_ANT, m_sCadAnt);
	DDX_Text(pDX, IDC_CANT_ACT, m_sCantAct);
	DDX_Text(pDX, IDC_CANT_NUE, m_sCantNue);
	DDX_Text(pDX, IDC_EXISTENCIAS, m_sExistencias);
	DDX_Text(pDX, IDC_MATERIAL, m_sMaterial);
	DDX_Text(pDX, IDC_LOTE, m_sLote);
	DDX_Text(pDX, IDC_CAD_NUE, m_lCadNue);
	DDX_Text(pDX, IDC_HORAS, m_lHoras);
	DDX_Text(pDX, IDC_RATIO, m_lRatio);
	//}}AFX_DATA_MAP
	CString sText;
	sText = FormatLong(m_lHoras,8, Real2Dec);
	SetDlgItemText(IDC_HORAS_D, sText);
	sText = FormatLong(m_lCadNue,8, Real2Dec);
	SetDlgItemText(IDC_CAD_D, sText);
	sText = FormatLong(m_lRatio,8, Real2Dec);
	SetDlgItemText(IDC_RATIO_D, sText);

}


BEGIN_MESSAGE_MAP(CDlgAjustar, CDialog)
	//{{AFX_MSG_MAP(CDlgAjustar)
	ON_EN_CHANGE(IDC_RATIO, OnChangeRatio)
	ON_EN_CHANGE(IDC_HORAS, OnChangeHoras)
	ON_EN_CHANGE(IDC_CAD_NUE, OnChangeCadNue)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgAjustar message handlers

BOOL CDlgAjustar::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	m_SpinRatio.SetRange32(0,99999);
	m_SpinRatio.SetAccel(1, &m_UdAcRatio);

	m_SpinCad.SetRange32(0,99999);
	m_SpinCad.SetAccel(1, &m_UdAcCad);
	
	m_SpinHoras.SetRange32(0,999999);
	m_SpinHoras.SetAccel(1, &m_UdAcHoras);


	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgAjustar::OnChangeRatio() 
{
	long lRatio = atol(GetsDlgText(IDC_RATIO, this));
	
	CString sText;
	sText = FormatLong(lRatio,8, Real2Dec);
	SetDlgItemText(IDC_RATIO_D, sText);



}

void CDlgAjustar::OnChangeHoras() 
{
	long lHoras = atol(GetsDlgText(IDC_HORAS, this));
	
	CString sText;
	sText = FormatLong(lHoras,8, Real2Dec);
	bCut = TRUE;
	SetDlgItemText(IDC_HORAS_D, sText);

	
}

void CDlgAjustar::OnChangeCadNue() 
{
	long lCadencia = atol(GetsDlgText(IDC_CAD_NUE, this));
	
	CString sText;
	sText = FormatLong(lCadencia,8, Real2Dec);
	bCut = TRUE;
	SetDlgItemText(IDC_CAD_D, sText);

	if (m_pOrdenDlg)
	{
		m_OM = *(m_pOrdenDlg->m_pOM);	// Hacemos una copia de la OM para los c�lculos
		m_OM.SetdCadencia((double) lCadencia / 100);
		m_OM.CalcTimeSpan();
		sText.Format("%ld", (long) (m_OM.GetTimeSpan().GetTotalMinutes() / .6));
		SetDlgItemText(IDC_HORAS, sText);
	}
}
// Actualiza la OrdMaq con los datos del Di�logo
void COrdenDlg::ActOM()
{

	const int BufLen = 100;
	CTime FecEnt;    
	CTime FecIni;
	
	CDlgValidarCambio DlgVal;
	BOOL bModif = FALSE;
	char Buffer[BufLen];
	GetDlgItemText(IDC_CANTIDAD, Buffer, BufLen);
	if (m_sCantidad != Buffer)
	{
		DlgVal.m_sValAnt = m_sCantidad;
		DlgVal.m_sValNue = Buffer; 
		DlgVal.m_sCampo = "Cantidad";
		if (DlgVal.DoModal() == IDOK)
		{
			bModif = TRUE;
			m_pOM->ModifCant(Buffer);
		}
	}	

	GetDlgItemText(IDC_CADENCIA, Buffer, BufLen);
	if (m_sCadencia != Buffer)
	{
		DlgVal.m_sValAnt = m_sCadencia;
		DlgVal.m_sValNue = Buffer; 
		DlgVal.m_sCampo = "Cadencia";
		if (DlgVal.DoModal() == IDOK)
		{
			bModif = TRUE;
			double dCadencia = atof( Buffer );
			if (dCadencia == 0)
			{
				AfxMessageBox(STRID(IDS_ERR_CANTNOVAL ));
			}
			else
			{
				m_pOM->SetdCadencia(dCadencia);
			}
		}
	}	

	GetDlgItemText(IDC_MOLDE, Buffer, BufLen);
	if (m_sMolde != Buffer)
	{
		DlgVal.m_sValAnt = m_sMolde;
		DlgVal.m_sValNue = Buffer; 
		DlgVal.m_sCampo = "Molde";
		if (DlgVal.DoModal() == IDOK)
		{
			bModif = TRUE;
			if (!m_pOM->ModifMolde(Buffer))
			{
				MessageBox(STRID( IDS_ERR_MOLNOTFOUND ) + Buffer , STRID(IDS_ERROR));
			}
		}
	}	

	GetDlgItemText(IDC_TIEMPO, Buffer, BufLen);
	if (m_sTiempo != Buffer)
	{
		DlgVal.m_sValAnt = m_sTiempo;
		DlgVal.m_sValNue = Buffer; 
		DlgVal.m_sCampo = "Tiempo";
		if (DlgVal.DoModal() == IDOK)
		{
			bModif = TRUE;
			m_pOM->SetBTiempoFijo(TRUE);
			m_pOM->ModifTimeSpan(Buffer);
			m_ButtonTiempoFijo.SetCheck(1);
		}
	}	
	m_DTctrlFecEnt.GetTime(FecEnt);
	if (m_FecEnt != FecEnt)
	{
		bModif = TRUE;
		DlgVal.m_sValAnt = FormatFec(m_FecEnt, Fecha);
		DlgVal.m_sValNue = FormatFec(FecEnt, Fecha); 
		DlgVal.m_sCampo = "Fecha de Entrega";
		if (DlgVal.DoModal() == IDOK) 
		{
			bModif = TRUE;
			m_pOM->ModifFecEnt(FecEnt);
		}
	}
	m_DTctrlFecIni.GetTime(FecIni);
	if (m_FecIni != FecIni)
	{
		bModif = TRUE;
		DlgVal.m_sValAnt = FormatFec(m_FecIni, FecHoraSec);
		DlgVal.m_sValNue = FormatFec(FecIni, FecHoraSec); 
		DlgVal.m_sCampo = "Fecha de Inicio";
		if (DlgVal.DoModal() == IDOK) 
		{
			bModif = TRUE;
			m_pOM->SetFecIni(FecIni);
			m_pOM->SetBFija(TRUE);
		}
	}
	
	CTime FecFab;
	GetDlgItemText(IDC_FABRICADAS, Buffer, BufLen);
	m_DTctrlFecFab.GetTime(FecFab);
	if (m_sFabricadas != Buffer || FecFab != m_FecFab)
	{
		FecFab = CTime(FecFab.GetYear(), FecFab.GetMonth(), FecFab.GetDay(), TK_TURNO3_FIN,0,0);
		long lCantFab = atol(Buffer);
		CTime FecIni = m_pOM->GetFecIni();
		if (lCantFab >= m_pOM->GetlCantOF())
		{
			MessageBox(STRID( IDS_ERR_CANTMENOR ) , STRID(IDS_ERROR));
		} else 
//		if (FecIni > FecFab)
//		{
//			MessageBox(STRID( IDS_ERR_FECFABMAY ) , STRID(IDS_ERROR));
//		} else 
//		{
			DlgVal.m_sValAnt = m_sFabricadas + " - " + FormatFec(FecFab, Fecha);
			DlgVal.m_sValNue = (CString) Buffer + " - " + FormatFec(m_FecFab, Fecha); 
			DlgVal.m_sCampo = "Fabricaci�n";
			if (DlgVal.DoModal() == IDOK)
			{
				bModif = TRUE;
				m_pOM->SetFab(lCantFab, FecFab);
			}
//		}
	}	

	if (bModif) 
	{
		CProgMaq* pPM = m_pOM->GetpPM();
		if (pPM)
			pPM->Recalc();
		else
			m_pOM->Recalc();
	}


}
