// cpwDoc.cpp : implementation of the CCpwDoc class
//

#include "stdafx.h"
#include "afxdtctl.h"
#include "cpw.h"
#include "cpwDefs.h"
#include "ObArrOrd.h"     


#include "Dialogs.h"
#include "AbSpan.h"
#include "prog.h"
#include "cpwDb.h"
#include "cpwExt.h"
#include "cache.h"
#include "ProgMaq.h"
#include "OrdMaq.h"
#include "CpwView.h"
#include "TextView.h"

#include "cpwDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCpwDoc

IMPLEMENT_DYNCREATE(CCpwDoc, CDocument)

BEGIN_MESSAGE_MAP(CCpwDoc, CDocument)
	//{{AFX_MSG_MAP(CCpwDoc)
	ON_COMMAND(ID_ESCALA, OnEscala)
	ON_COMMAND(ID_RECALCULAR, OnRecalcular)
	ON_COMMAND(ID_CAMBIAR_FECHA_INICIO, OnCambiarFechaInicio)
	ON_COMMAND(ID_CONS_MAQORD, OnConsMaqord)
	ON_COMMAND(ID_CONS_CAMMOL, OnConsCammol)
	ON_COMMAND(ID_CONS_LOTES, OnConsLotes)
	ON_COMMAND(ID_OF_ORDEN, OnOfOrden)
	ON_COMMAND(ID_SELEC_FECHA, OnSelecFecha)
	ON_COMMAND(ID_NEXT_ART, OnNextArt)
	ON_COMMAND(ID_NEXT_PAGE, OnNextPage)
	ON_COMMAND(ID_PREV_ART, OnPrevArt)
	ON_COMMAND(ID_PREV_PAGE, OnPrevPage)
	ON_COMMAND(ID_PREV_SECCION, OnPrevSeccion)
	ON_COMMAND(ID_NEXT_SECCION, OnNextSeccion)
	ON_COMMAND(ID_SOLONOPROG, OnSolonoprog)
	ON_COMMAND(ID_OF_HASTAFECHA, OnOfHastafecha)
	ON_COMMAND(ID_CAMBIAR_FECHA_FIN, OnCambiarFechaFin)
	ON_COMMAND(ID_ORDENAR_MAQUINAS, OnOrdenarMaquinas)
	ON_COMMAND(ID_CONS_OFS, OnConsOfs)
	ON_COMMAND(ID_DESCONTAR_CIKA, OnDescontarCika)
	ON_COMMAND(ID_DESCONTAR_OTROS, OnDescontarOtros)
	ON_COMMAND(ID_VER_ACUMFECHA, OnVerAcumfecha)
	ON_COMMAND(ID_ESCALA_AMPLIA, OnEscalaAmplia)
	ON_COMMAND(ID_ESCALA_ESTRECHA, OnEscalaEstrecha)
	ON_COMMAND(ID_CONS_MEZ_EXT, OnConsMezExt)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCpwDoc construction/destruction

CCpwDoc::CCpwDoc()
{
	m_Prog.SetpDoc(this);
	m_BReadOnly = FALSE;
	m_Update = Otro;
}

CCpwDoc::~CCpwDoc()
{
}

BOOL CCpwDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CCpwDoc serialization

void CCpwDoc::Serialize(CArchive& ar)
{
	CObject::Serialize(ar);
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}

	m_Prog.Serialize(ar);
}

/////////////////////////////////////////////////////////////////////////////
// CCpwDoc diagnostics

#ifdef _DEBUG
void CCpwDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CCpwDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CCpwDoc commands

void CCpwDoc::CargaCelulas(long p_lBloque, long p_lSerieIni, long p_lSerieFin) 
{
}

void CCpwDoc::OnEscala() 
{
	DlgEscala tDlgEscala;

	tDlgEscala.m_Escala = (int) m_Prog.GetTimeScale();
	if (tDlgEscala.DoModal() == IDOK)
	{
		m_Prog.SetTimeScale(tDlgEscala.m_Escala);
		AfxGetApp()->WriteProfileInt("Valores Iniciales", "Escala", tDlgEscala.m_Escala);
	}

	UpdateAllViews(NULL);
	
}


void CCpwDoc::OnRecalcular() 
{
	CWaitCursor WaitCursor;
	
	CProg* pProg = GetpProg();
	pProg->Recalc();
	
	
}

void CCpwDoc::OnCambiarFechaInicio() 
{
	CDlgIntrDate	DlgIntrDate;
	
	DlgIntrDate.m_sCaption = "Introducir Fecha Inicio";
	CProg* pProg = GetpProg();
	ASSERT_VALID(pProg);
	DlgIntrDate.m_Fec = pProg->GetFecIni();

	if (DlgIntrDate.DoModal() != IDOK)
		return;
	
	if ( DlgIntrDate.m_Fec > pProg->GetFecIni())
	{
		if (AfxMessageBox( STRID(IDS_CONF_ADVINI), MB_OKCANCEL ) != IDOK ) return;
	}
	pProg->SetFecIni(DlgIntrDate.m_Fec);

	SetModifiedFlag();
	UpdateAllViews(NULL);
	
}

void 
CCpwDoc::OnCambiarFechaFin() 
{
	CDlgIntrDate	DlgIntrDate;
	
	DlgIntrDate.m_sCaption = "Introducir Fecha Fin";
	CProg* pProg = GetpProg();
	ASSERT_VALID(pProg);
	DlgIntrDate.m_Fec = pProg->GetFecFin();

	if (DlgIntrDate.DoModal() != IDOK)
		return;
	
	pProg->SetFecFin(DlgIntrDate.m_Fec);

	SetModifiedFlag();
	UpdateAllViews(NULL);
		
}




BOOL CCpwDoc::OnOpenDocument(LPCTSTR lpszPathName) 
{
	if (!CDocument::OnOpenDocument(lpszPathName))
		return FALSE;
	
	m_BReadOnly = FALSE;
	CFileException fe;
	CFile* pFile = GetFile(lpszPathName,
		CFile::modeRead|CFile::shareDenyNone, &fe);
	if (pFile != NULL)
	{
		CFileStatus FStatus;
		pFile->GetStatus(FStatus);
		if (FStatus.m_attribute & 0x01) m_BReadOnly = TRUE;
		pFile->Close();
		delete pFile;
	}
	return TRUE;
}

void CCpwDoc::OnConsMaqord() 
{
	CWaitCursor WaitCursor;
	CProg* pProg = GetpProg();
	ASSERT_VALID(pProg);

	CDlgMaqOrd DlgMaqOrd(this);
	DlgMaqOrd.m_FecDesde = pProg->GetFecIni();	
	DlgMaqOrd.m_FecHasta = pProg->GetFecFin();	
	pProg->GetArrMaqOM(DlgMaqOrd.m_ArrOM);
	DlgMaqOrd.m_eTipoCons = ConsMaqOrd;

	DlgMaqOrd.DoModal();
	
}


void CCpwDoc::OnConsCammol() 
{
	CWaitCursor WaitCursor;
	CProg* pProg = GetpProg();
	ASSERT_VALID(pProg);

	CDlgMaqOrd DlgMaqOrd(this);
	DlgMaqOrd.m_FecDesde = pProg->GetFecIni();	
	DlgMaqOrd.m_FecHasta = AddDays(pProg->GetFecIni(), 1);	
		
	pProg->GetArrMaqOM(DlgMaqOrd.m_ArrOM);
	DlgMaqOrd.m_eTipoCons = ConsCambioMolde;

	DlgMaqOrd.DoModal();
	
	
}

void CCpwDoc::OnConsLotes() 
{
	
	CWaitCursor WaitCursor;
	CProg* pProg = GetpProg();
	ASSERT_VALID(pProg);

	CDlgMaqOrd DlgMaqOrd(this);
	DlgMaqOrd.m_FecDesde = pProg->GetFecIni();	
	DlgMaqOrd.m_FecHasta = pProg->GetFecFin();	
	pProg->GetArrMaqOM(DlgMaqOrd.m_ArrOM);
	DlgMaqOrd.m_eTipoCons = ConsLotes;

	DlgMaqOrd.DoModal();
	
}

// Funcion que cambia la ordenacion de CTextview
void CCpwDoc::OnOfOrden() 
{
	
	CMenu* pMenu = AfxGetMainWnd()->GetMenu();
	if (!pMenu) return;
	enum eOrdenOF eOrdenOF = (pMenu->GetMenuState(ID_OF_ORDEN, MF_BYCOMMAND) == MF_CHECKED) ? Articulo : Seccion ;
	pMenu->CheckMenuItem(ID_OF_ORDEN, (pMenu->GetMenuState(ID_OF_ORDEN, MF_BYCOMMAND) == MF_UNCHECKED) ? MF_CHECKED : MF_UNCHECKED);
	g_VerOF.m_OrdenOF = eOrdenOF;
	
	GetpTextView()->SeteOrden();
}

void
CCpwDoc::UpdateTextView()
{
	GetpTextView()->SeteOrden();
}

// Funcion que permite seleccionar los pedidos hasta una fecha
void CCpwDoc::OnSelecFecha() 
{
	CDlgIntrDate	DlgIntrDate;
	
	DlgIntrDate.m_sCaption = "Introducir Fecha : ";
	CProg* pProg = GetpProg();
	ASSERT_VALID(pProg);
	DlgIntrDate.m_Fec = CTime::GetCurrentTime();

	if (DlgIntrDate.DoModal() != IDOK)
		return;
	

	g_pCache->SelecToFec(DlgIntrDate.m_Fec);

	GetpTextView()->Invalidate();
}

void CCpwDoc::OnNextArt() 
{
	GetpTextView()->DoScroll(VK_F11, 1, 0);
}
void CCpwDoc::OnPrevArt() 
{
	GetpTextView()->DoScroll(VK_F11, 1,	VK_SHIFT);
}
void CCpwDoc::OnNextSeccion() 
{
	GetpTextView()->DoScroll(VK_F12, 1, 0);
}
void CCpwDoc::OnPrevSeccion() 
{
	GetpTextView()->DoScroll(VK_F12, 1, VK_SHIFT);
}
void CCpwDoc::OnNextPage() 
{
	GetpTextView()->DoScroll(VK_NEXT, 1, 0);
}
void CCpwDoc::OnPrevPage() 
{
	GetpTextView()->DoScroll(VK_PRIOR, 1, 0);
}

/*
void CCpwDoc::OnNextLine() 
{
	GetpTextView()->DoScroll(VK_DOWN, 1, 0);
}
void CCpwDoc::OnPrevLine() 
{
	GetpTextView()->DoScroll(VK_UP, 1, 0);
}
*/

CTextView*
CCpwDoc::GetpTextView()
{
	POSITION pos = GetFirstViewPosition();
	while (pos != NULL)
	{
		CView* pView = GetNextView(pos);
		if ( pView->IsKindOf( RUNTIME_CLASS( CTextView ))) return (CTextView*) pView;
	}
	return NULL;
}


void CCpwDoc::OnSolonoprog() 
{
	CMenu* pMenu = AfxGetMainWnd()->GetMenu();
	if (!pMenu) return;
	pMenu->CheckMenuItem(ID_SOLONOPROG, (pMenu->GetMenuState(ID_SOLONOPROG, MF_BYCOMMAND) == MF_UNCHECKED) ? MF_CHECKED : MF_UNCHECKED);
	g_VerOF.m_bSoloNoProg = (pMenu->GetMenuState(ID_SOLONOPROG, MF_BYCOMMAND) == MF_CHECKED);
	GetpTextView()->SeteOrden();	
}

void CCpwDoc::OnOfHastafecha() 
{
	CDlgIntrDate	DlgIntrDate;
	
	DlgIntrDate.m_sCaption = "Introducir Fecha";
	CProg* pProg = GetpProg();
	ASSERT_VALID(pProg);
	DlgIntrDate.m_Fec = g_VerOF.m_FecSelec;
	
	
	CMenu* pMenu = AfxGetMainWnd()->GetMenu();
	if (!pMenu) return;
	
	CString sMsg;
	UINT uStatFec = pMenu->GetMenuState(ID_OF_HASTAFECHA, MF_BYCOMMAND);
	if ( uStatFec == MF_UNCHECKED)  // Si estamos poniendo por fecha
	{
		if (DlgIntrDate.DoModal() != IDOK) return;
		g_VerOF.m_FecSelec = DlgIntrDate.m_Fec;
		g_VerOF.m_bSelecFec = TRUE;
		sMsg = "HastaFecha : " + FormatFec(g_VerOF.m_FecSelec, Fecha);
	}
	else
	{
		g_VerOF.m_bSelecFec = FALSE;
		sMsg = "HastaFecha...";
	}
	pMenu->ModifyMenu(ID_OF_HASTAFECHA, MF_BYCOMMAND, ID_OF_HASTAFECHA, sMsg);
	pMenu->CheckMenuItem(ID_OF_HASTAFECHA, 
		(uStatFec == MF_UNCHECKED) ? MF_CHECKED : MF_UNCHECKED);

	GetpTextView()->SeteOrden();	

}


void CCpwDoc::OnOrdenarMaquinas() 
{
	CProg* pProg = GetpProg();
	ASSERT_VALID(pProg);

	int iLim = pProg->GetNumPM();
	for (int i = 0; i < iLim; i++)
	{
		CProgMaq* pPM = pProg->GetpPM(i);
		CProgMaq* pPMNext = NULL;
		for (int j = i+1; j < iLim; j++)
		{
			pPMNext = pProg->GetpPM(j);
			CString sID = pPM->GetsID();
			CString sIDNext = pPMNext->GetsID();
			long lID = atol(sID);
			long lIDNext = atol(sIDNext);
			if (lID > lIDNext)
			{
				pProg->SwitchPM(i, j);
				CProgMaq* pPMInt = pPM;
				pPM = pPMNext;
				pPMNext = pPMInt;
			}
		}
	}
	SetModifiedFlag();
	UpdateAllViews(NULL);

}

void CCpwDoc::OnConsOfs() 
{
	CWaitCursor WaitCursor;
	CProg* pProg = GetpProg();
	ASSERT_VALID(pProg);

	CDlgMaqOrd DlgMaqOrd(this);
	DlgMaqOrd.m_FecDesde = pProg->GetFecIni();	
	DlgMaqOrd.m_FecHasta = pProg->GetFecFin();	
	int iLim = g_pCache->GetArrConsOF(DlgMaqOrd.m_ArrOF);
	DlgMaqOrd.m_eTipoCons = ConsOF;
	int iLim2 = DlgMaqOrd.m_ArrOF.GetSize();
	DlgMaqOrd.DoModal();	

	for(int i=0; i < iLim2 ; i++ )
    {
		CComp* pComp = (CComp*) DlgMaqOrd.m_ArrOF.GetAt(i);
		delete pComp;    	
    }      

}


void CCpwDoc::OnConsMezExt() 
{
	CWaitCursor WaitCursor;
	CProg* pProg = GetpProg();
	ASSERT_VALID(pProg);

	CDlgMaqOrd DlgMaqOrd(this);
	DlgMaqOrd.m_FecDesde = pProg->GetFecIni();	
	DlgMaqOrd.m_FecHasta = pProg->GetFecFin();	
	pProg->GetArrMezExt(DlgMaqOrd.m_ArrMezExt);
	DlgMaqOrd.m_eTipoCons = ConsMezExt;

	DlgMaqOrd.DoModal();

	int iLim2 = DlgMaqOrd.m_ArrMezExt.GetSize();

	for(int i=0; i < iLim2 ; i++ )
    {
		CBufLisMezclas* pBufLisMezclas = (CBufLisMezclas*) DlgMaqOrd.m_ArrMezExt.GetAt(i);
		delete pBufLisMezclas;    	
    }      


}

void CCpwDoc::OnDescontarCika() 
{
	CDlgIntrDate	DlgIntrDate;
	
	DlgIntrDate.m_sCaption = "Fecha de avance : ";
	CProg* pProg = GetpProg();
	ASSERT_VALID(pProg);
	DlgIntrDate.m_Fec = pProg->GetFecIni();

	if (DlgIntrDate.DoModal() != IDOK)
		return;
	
	if ( DlgIntrDate.m_Fec > pProg->GetFecIni())
	{
		if (AfxMessageBox( STRID(IDS_CONF_DESC), MB_OKCANCEL ) != IDOK ) return;
	}
	pProg->DescuentaVal(DlgIntrDate.m_Fec, 1);

	SetModifiedFlag();
	UpdateAllViews(NULL);
	
	
}

void CCpwDoc::OnDescontarOtros() 
{
	CDlgIntrDate	DlgIntrDate;
	
	DlgIntrDate.m_sCaption = "Fecha de avance : ";
	CProg* pProg = GetpProg();
	ASSERT_VALID(pProg);
	DlgIntrDate.m_Fec = pProg->GetFecIni();

	if (DlgIntrDate.DoModal() != IDOK)
		return;
	
	if ( DlgIntrDate.m_Fec > pProg->GetFecIni())
	{
		if (AfxMessageBox( STRID(IDS_CONF_DESC), MB_OKCANCEL ) != IDOK ) return;
	}
	pProg->DescuentaVal(DlgIntrDate.m_Fec, 0);

	SetModifiedFlag();
	UpdateAllViews(NULL);
	
	
}

void CCpwDoc::OnVerAcumfecha() 
{
	CMenu* pMenu = AfxGetMainWnd()->GetMenu();
	if (!pMenu) return;
	g_VerOF.m_bAcumOFs = (pMenu->GetMenuState(ID_VER_ACUMFECHA, MF_BYCOMMAND) == MF_UNCHECKED );
	pMenu->CheckMenuItem(ID_VER_ACUMFECHA, (g_VerOF.m_bAcumOFs) ? MF_CHECKED : MF_UNCHECKED);
		
	CTextView* pTextView = GetpTextView();

	pTextView->SeteOrden();
	
}

void CCpwDoc::OnEscalaAmplia() 
{

	int iEscala = AfxGetApp()->GetProfileInt("Escalas", "Uno", 600);

	AfxGetApp()->WriteProfileInt("Escalas", "Uno", iEscala);
	m_Prog.SetTimeScale(iEscala);

	UpdateAllViews(NULL);
	
}

void CCpwDoc::OnEscalaEstrecha() 
{

	int iEscala = AfxGetApp()->GetProfileInt("Escalas", "Dos", 2700);

	AfxGetApp()->WriteProfileInt("Escalas", "Dos", iEscala);
	m_Prog.SetTimeScale(iEscala);

	UpdateAllViews(NULL);	
}

