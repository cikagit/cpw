// cpwdb.h : header file
//
/////////////////////////////////////////////////////////////////////////////
// CRsArticulo recordset

class CRsArticulo : public CRecordset
{
public:
	CRsArticulo(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CRsArticulo)

// Field/Param Data
	//{{AFX_FIELD(CRsArticulo, CRecordset)
	long	m_CantAlmacen;
	long	m_CantFabric;
	long	m_CantPauta;
	long	m_CentroReb;
	CString	m_ID;
	long	m_MaduracionMax;
	long	m_MaduracionMed;
	long	m_MaduracionMin;
	CString	m_Mezcla;
	long	m_P_H_iny;
	double	m_PCAct;
	double	m_PCBase;
	double	m_PCHist;
	double	m_PCUlt;
	long	m_Peso;
	double	m_PHAct;
	double	m_PHBase;
	double	m_PHHist;
	double	m_PHUlt;
	double	m_PiezasHoraReb;
	int		m_PorcChatarras;
	//}}AFX_FIELD


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRsArticulo)
	public:
	virtual CString GetDefaultConnect();    // Default connection string
	virtual CString GetDefaultSQL();    // Default SQL for Recordset
	virtual void DoFieldExchange(CFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

class CBufMezcla;

class CBufArticulo : public CObject
{
public:
	double GetdCadencia();
	double GetdChatarras();
	long GetlCantMezcla();

	CBufArticulo();
	CBufArticulo(CRsArticulo& p_RsArticulo);
	AssignData(CRsArticulo& p_RsArticulo);

	~CBufArticulo();

	long	m_lCantAlmacen;
	long	m_lCantFabric;
	long	m_lCantPauta;
	long	m_lCentroReb;
	CString	m_sID;
	long	m_lMaduracionMax;
	long	m_lMaduracionMed;
	long	m_lMaduracionMin;
	CString	m_sMezcla;
	long	m_lP_H_iny;
	double	m_dPCAct;
	double	m_dPCBase;
	double	m_dPCHist;
	double	m_dPCUlt;
	long	m_lPeso;
	double	m_dPHAct;
	double	m_dPHBase;
	double	m_dPHHist;
	double	m_dPHUlt;
	double	m_dPiezasHoraReb;
	int		m_iPorcChatarras;

	CString	m_LV_sCliente;
	double	m_LV_dP_H_real;
	double	m_LV_dRechazos;
	long	m_LV_lCantidad_Fabricada;
	long	m_LV_lCantidad_Rechazada;
	long	m_LV_lTotal_Horas;


	CObArray*	m_pArrArtMol;
	CBufMezcla* m_pBufMezcla;
// Implementation
protected:
	DECLARE_DYNAMIC(CBufArticulo)
	
};


/////////////////////////////////////////////////////////////////////////////
// CRsArtMol recordset

class CRsArtMol : public CRecordset
{
public:
	CRsArtMol(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CRsArtMol)

// Field/Param Data
	//{{AFX_FIELD(CRsArtMol, CRecordset)
	long	m_Cantidad;
	CString	m_IDArticulo;
	CString	m_IDMolde;
	long	m_Orden;
	CString	m_Postizo;
	//}}AFX_FIELD


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRsArtMol)
	public:
	virtual CString GetDefaultConnect();    // Default connection string
	virtual CString GetDefaultSQL();    // Default SQL for Recordset
	virtual void DoFieldExchange(CFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};


class CBufMolde;

class CBufArtMol : public CObject
{
public:
	CBufArtMol(CRsArtMol& p_RsArtMol);

	CString	m_sIDArticulo;
	long	m_lOrden;
	CString	m_sIDMolde;
	long	m_lCantidad;
	CString	m_sPostizo;

	CBufMolde* m_pBufMolde;
	CBufArticulo* m_pBufArticulo;
	// Implementation
protected:
	DECLARE_DYNAMIC(CBufArtMol)
	
//	double GetdCantidad( const char* IDMolde );
};


/////////////////////////////////////////////////////////////////////////////
// CRsCliente recordset

class CRsCliente : public CRecordset
{
public:
	CRsCliente(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CRsCliente)

// Field/Param Data
	//{{AFX_FIELD(CRsCliente, CRecordset)
	CString	m_ID;
	CString	m_Nombre;
	//}}AFX_FIELD


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRsCliente)
	public:
	virtual CString GetDefaultConnect();    // Default connection string
	virtual CString GetDefaultSQL();    // Default SQL for Recordset
	virtual void DoFieldExchange(CFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};
/////////////////////////////////////////////////////////////////////////////
// CRsEntregas recordset

class CRsEntregas : public CRecordset
{
public:
	CRsEntregas(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CRsEntregas)

// Field/Param Data
	//{{AFX_FIELD(CRsEntregas, CRecordset)
	CString	m_IDMezcla;
	CTime	m_Fecha;
	long	m_Orden;
	long	m_Cantidad;
	//}}AFX_FIELD


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRsEntregas)
	public:
	virtual CString GetDefaultConnect();    // Default connection string
	virtual CString GetDefaultSQL();    // Default SQL for Recordset
	virtual void DoFieldExchange(CFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};


class CBufEntregas : public CObject
{
public:
	CBufEntregas(CRsEntregas& p_RsEntregas);

	CString	m_sIDMezcla;
	CTime	m_Fecha;
	long	m_lOrden;
	long	m_lCantidad;

	// Implementation
protected:
	DECLARE_DYNAMIC(CBufEntregas)
	
};




/////////////////////////////////////////////////////////////////////////////
// CRsHistorico recordset

class CRsHistorico : public CRecordset
{
public:
	CRsHistorico(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CRsHistorico)

// Field/Param Data
	//{{AFX_FIELD(CRsHistorico, CRecordset)
	CString	m_IDMolde;
	CString	m_IDMaquina;
	CTime	m_FecIni;
	CTime	m_FecFin;
	long	m_Cantidad;
	CString	m_IDArticulo;
	double	m_Cadencia;
	double	m_Rechazos;
	//}}AFX_FIELD


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRsHistorico)
	public:
	virtual CString GetDefaultConnect();    // Default connection string
	virtual CString GetDefaultSQL();    // Default SQL for Recordset
	virtual void DoFieldExchange(CFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};
/////////////////////////////////////////////////////////////////////////////
// CRsLocales recordset

class CRsLocales : public CRecordset
{
public:
	CRsLocales(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CRsLocales)

// Field/Param Data
	//{{AFX_FIELD(CRsLocales, CRecordset)
	CString	m_ID;
	CString	m_Nombre;
	//}}AFX_FIELD


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRsLocales)
	public:
	virtual CString GetDefaultConnect();    // Default connection string
	virtual CString GetDefaultSQL();    // Default SQL for Recordset
	virtual void DoFieldExchange(CFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};
/////////////////////////////////////////////////////////////////////////////
// CRsMaquinas recordset

class CRsMaquinas : public CRecordset
{
public:
	CRsMaquinas(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CRsMaquinas)

// Field/Param Data
	//{{AFX_FIELD(CRsMaquinas, CRecordset)
	CString	m_ID;
	CString	m_Tipo;
	CString	m_Nombre;
	CString	m_IDLocal;
	long	m_Inact;
	//}}AFX_FIELD


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRsMaquinas)
	public:
	virtual CString GetDefaultConnect();    // Default connection string
	virtual CString GetDefaultSQL();    // Default SQL for Recordset
	virtual void DoFieldExchange(CFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};


class CBufMaquina : public CObject
{
public:
	CBufMaquina();
	CBufMaquina(CRsMaquinas& p_RsMaquinas);
	CBufMaquina(CBufMaquina& p_BufMaquina);
	~CBufMaquina();
	AssignData(CRsMaquinas& p_RsMaquinas);
	
	CString	m_sID;
	CString	m_sTipo;
	CString	m_sNombre;
	CString	m_sIDLocal;
	long	m_lInact;

	
// Implementation
protected:
	DECLARE_DYNAMIC(CBufMaquina)
	
};




/////////////////////////////////////////////////////////////////////////////
// CRsMezclas recordset

class CRsMezclas : public CRecordset
{
public:
	CRsMezclas(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CRsMezclas)

// Field/Param Data
	//{{AFX_FIELD(CRsMezclas, CRecordset)
	CString	m_ID;
	CString	m_Color;
	long	m_Cantidad;
	long	m_Lote;
	//}}AFX_FIELD


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRsMezclas)
	public:
	virtual CString GetDefaultConnect();    // Default connection string
	virtual CString GetDefaultSQL();    // Default SQL for Recordset
	virtual void DoFieldExchange(CFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};


class CBufMezcla : public CObject
{
public:
	CBufMezcla();
	CBufMezcla(CRsMezclas& p_RsMezclas);
	CBufMezcla(CBufMezcla& p_BufMezclas);
	~CBufMezcla();
	AssignData(CRsMezclas& p_RsMezclas);
	
	CString	m_sID;
	CString	m_sColor;
	long	m_lCantidad;
	long	m_lCantPlanta;
	long	m_lLote;

	CObArray*	m_pArrEntregas;
	
// Implementation
protected:
	DECLARE_DYNAMIC(CBufMezcla)
	
};





/////////////////////////////////////////////////////////////////////////////
// CRsMoldes recordset

class CRsMoldes : public CRecordset
{
public:
	CRsMoldes(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CRsMoldes)

// Field/Param Data
	//{{AFX_FIELD(CRsMoldes, CRecordset)
	CString	m_ID;
	CString	m_Alternancia;
	CString	m_Tipo;
	long	m_Tiradas;
	CString	m_Estado;
	CTime	m_Disponibilidad;
	//}}AFX_FIELD


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRsMoldes)
	public:
	virtual CString GetDefaultConnect();    // Default connection string
	virtual CString GetDefaultSQL();    // Default SQL for Recordset
	virtual void DoFieldExchange(CFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};


/////////////////////////////////////////////////////////////////////////////
// CBufMolde recordset

class CBufMolde : public CObject
{
public:
	CBufMolde();
	CBufMolde(CRsMoldes& p_RsMoldes);
	CBufMolde(CBufMolde& p_BufMoldes);
	~CBufMolde();
	AssignData(CRsMoldes& p_RsMoldes);
	
	CString	m_sID;
	CString	m_sAlternancia;
	CString	m_sTipo;
	long	m_lTiradas;
	CString	m_sEstado;
	CTime	m_FecDisponibilidad;
	
	CObArray*	m_pArrMolArt;
	CObArray*	m_pArrMolMaq;
// Implementation
protected:
	DECLARE_DYNAMIC(CBufMolde)
	
};



/////////////////////////////////////////////////////////////////////////////
// CRsMolMaq recordset

class CRsMolMaq : public CRecordset
{
public:
	CRsMolMaq(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CRsMolMaq)

// Field/Param Data
	//{{AFX_FIELD(CRsMolMaq, CRecordset)
	CString	m_IDMolde;
	long	m_Prioridad;
	CString	m_IDMaquina;
	//}}AFX_FIELD


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRsMolMaq)
	public:
	virtual CString GetDefaultConnect();    // Default connection string
	virtual CString GetDefaultSQL();    // Default SQL for Recordset
	virtual void DoFieldExchange(CFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

class CBufMolMaq : public CObject
{
public:
	CBufMolMaq() {};
	CBufMolMaq(CRsMolMaq& p_RsMolMaq);
	~CBufMolMaq() {};

	CString	m_sIDMolde;
	long	m_lPrioridad;
	CString	m_sIDMaquina;
	
	CBufMaquina* m_pBufMaquina;
	// Implementation
protected:
	DECLARE_DYNAMIC(CBufMolMaq)
	
};


/////////////////////////////////////////////////////////////////////////////
// CRsPedidos recordset

class CRsPedidos : public CRecordset
{
public:
	CRsPedidos(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CRsPedidos)

// Field/Param Data
	//{{AFX_FIELD(CRsPedidos, CRecordset)
	double	m_CantAlmac;
	double	m_CantCurso;
	double	m_CantOrig;
	double	m_CantPauta;
	double	m_CantPend;
	CTime	m_FecNec;
	CString	m_IDArticulo;
	long	m_IDCliente;
	CString	m_Necesidad;
	CString	m_Nomcli;
	long	m_Seccion;
	double	m_CantObsoletos;
	double	m_CantStockSeguridad;
	//}}AFX_FIELD


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRsPedidos)
	public:
	virtual CString GetDefaultConnect();    // Default connection string
	virtual CString GetDefaultSQL();    // Default SQL for Recordset
	virtual void DoFieldExchange(CFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

class CRsPedidosAyer;

class CBufOF : public CObject
{
public:
	void SetSelect(BOOL p_bSelected) {	m_bSelected = p_bSelected;};
	BOOL GetbSelected() { return m_bSelected;	};
	void SetComprimido(BOOL p_bComprimido) {	m_bComprimido = p_bComprimido; };
	BOOL GetbComprimido() {	return m_bComprimido;	};

	CBufOF(CRsPedidos& p_RsPedidos);
	CBufOF(CRsPedidosAyer& p_RsPedidosAyer);
//	CBufOF(CBufOF& p_BufOF);

	//virtual CBufOF& operator =(CBufOF& p_BufOF);


	CBufOF*	GetID() { return this; };		// same return type as COrdMaq::GetIDOF()

	long	m_lMargenMax;	// Margen sobre el periodo de maduraci�n maximo
	long	m_lMargenMed;	// Margen sobre el periodo de maduraci�n medio
	long	m_lMargenMin;	// Margen sobre el periodo de maduraci�n m�nimo
	CTime	m_FecFab;		// Fecha en la que realmente se va a fabricar. FecFin de Prog si no se llega a fabricar.
	double	m_dNoProg;		// Cantidad del Acumulado que no est� fabricada
	double	m_dNoCubierta;		// Cantidad del Acumulado que no est� cubierta
	double	m_dPendAcum;
	double	m_dCantAlmac;
	double	m_dCantCurso;
	double	m_dCantOrig;
	double	m_dCantPauta;
	double	m_dCantPend;
	double	m_dCantObsoletos;
	double	m_dCantStockSeguridad;
	CTime	m_FecNec;
	CString	m_sIDArticulo;
	long	m_lIDCliente;
	CString	m_sNecesidad;
	CString	m_sNomcli;
	long	m_lSeccion;
	                                        
	
// Implementation
protected:
	BOOL m_bSelected;
	BOOL m_bComprimido;
	DECLARE_DYNAMIC(CBufOF)   
	CBufOF();

	AssignData(CRsPedidos& p_RsPedidos);

	
//	virtual void Serialize(CArchive& ar);
	
};


/////////////////////////////////////////////////////////////////////////////
// CRsListadoValorado recordset

class CRsListadoValorado : public CRecordset
{
public:
	CRsListadoValorado(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CRsListadoValorado)

// Field/Param Data
	//{{AFX_FIELD(CRsListadoValorado, CRecordset)
	CString	m_Articulo;
	CString	m_Cliente;
	double	m_P_H_real;
	double	m__Rechazos;
	long	m_Cantidad_Fabricada;
	long	m_Cantidad_Rechazada;
	long	m_Total_Horas;
	//}}AFX_FIELD


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRsListadoValorado)
	public:
	virtual CString GetDefaultConnect();    // Default connection string
	virtual CString GetDefaultSQL();    // Default SQL for Recordset
	virtual void DoFieldExchange(CFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};
/////////////////////////////////////////////////////////////////////////////
// CRsPedidosAyer recordset

class CRsPedidosAyer : public CRecordset
{
public:
	CRsPedidosAyer(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CRsPedidosAyer)

// Field/Param Data
	//{{AFX_FIELD(CRsPedidosAyer, CRecordset)
	CString	m_IDArticulo;
	long	m_IDCliente;
	CString	m_Nomcli;
	CString	m_Necesidad;
	double	m_CantOrig;
	double	m_CantPend;
	CTime	m_FecNec;
	double	m_CantAlmac;
	double	m_CantCurso;
	double	m_CantPauta;
	long	m_Seccion;
	double	m_CantObsoletos;
	double	m_CantStockSeguridad;
	//}}AFX_FIELD


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRsPedidosAyer)
	public:
	virtual CString GetDefaultConnect();    // Default connection string
	virtual CString GetDefaultSQL();    // Default SQL for Recordset
	virtual void DoFieldExchange(CFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};
/////////////////////////////////////////////////////////////////////////////
// CRsCambiosMoldes recordset

class CRsCambiosMoldes : public CRecordset
{
public:
	CRsCambiosMoldes(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CRsCambiosMoldes)

// Field/Param Data
	//{{AFX_FIELD(CRsCambiosMoldes, CRecordset)
	long	m_Contador;
	CString	m_IDMaquina;
	CString	m_IDMoldeEnt;
	CString	m_IDMoldeSal;
	//}}AFX_FIELD


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRsCambiosMoldes)
	public:
	virtual CString GetDefaultConnect();    // Default connection string
	virtual CString GetDefaultSQL();    // Default SQL for Recordset
	virtual void DoFieldExchange(CFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

class CBufCambiosMoldes : public CObject
{
public:
	CBufCambiosMoldes(CRsCambiosMoldes& p_RsCambiosMoldes);


	CString	m_sIDMaquina;
	CTime	m_Fecha;
	CString	m_sIDMoldeSal;
	CString	m_sIDMoldeEnt;

// Implementation
protected:
	DECLARE_DYNAMIC(CBufCambiosMoldes)   
	CBufCambiosMoldes();
	
};

/////////////////////////////////////////////////////////////////////////////
// CRsMezclasPlanta recordset

class CRsMezclasPlanta : public CRecordset
{
public:
	CRsMezclasPlanta(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CRsMezclasPlanta)

// Field/Param Data
	//{{AFX_FIELD(CRsMezclasPlanta, CRecordset)
	CString	m_ID;
	long	m_Cantidad;
	//}}AFX_FIELD


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRsMezclasPlanta)
	public:
	virtual CString GetDefaultConnect();    // Default connection string
	virtual CString GetDefaultSQL();    // Default SQL for Recordset
	virtual void DoFieldExchange(CFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};
/////////////////////////////////////////////////////////////////////////////
// CRsLisMezclas recordset

class CRsLisMezclas : public CRecordset
{
public:
	CRsLisMezclas(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CRsLisMezclas)

// Field/Param Data
	//{{AFX_FIELD(CRsLisMezclas, CRecordset)
	long	m_Cant;
	CTime	m_FecIni;
	CString	m_IDArticulo;
	CString	m_IDCliente;
	CString	m_IDLocal;
	long	m_Mezcla;
	//}}AFX_FIELD


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRsLisMezclas)
	public:
	virtual CString GetDefaultConnect();    // Default connection string
	virtual CString GetDefaultSQL();    // Default SQL for Recordset
	virtual void DoFieldExchange(CFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

class CBufLisMezclas : public CObject
{
public:
	CBufLisMezclas(CRsLisMezclas& p_RsLisMezclas);


	CString		m_sIDLocal;
	CString		m_sIDCliente;
	CString		m_sIDArticulo;
	CTime		m_FecIni;
	long		m_lMezcla;
	long		m_lCant;
	

// Implementation
protected:
	DECLARE_DYNAMIC(CBufLisMezclas)   
	CBufLisMezclas();
	
};
/////////////////////////////////////////////////////////////////////////////
// CRsCalendario recordset

class CRsCalendario : public CRecordset
{
public:
	CRsCalendario(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CRsCalendario)

// Field/Param Data
	//{{AFX_FIELD(CRsCalendario, CRecordset)
	CString	m_ID;
	CTime	m_Fecha;
	BOOL	m_Turno1;
	BOOL	m_Turno2;
	BOOL	m_Turno3;
	//}}AFX_FIELD


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRsCalendario)
	public:
	virtual CString GetDefaultConnect();    // Default connection string
	virtual CString GetDefaultSQL();    // Default SQL for Recordset
	virtual void DoFieldExchange(CFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};
