// cpwPrint.cpp : implementation of the Printing funcions of the CCpwView class
//

#include "stdafx.h"
#include "afxdtctl.h"
#include "cpw.h"
#include "cpwDefs.h"

#include "AbSpan.h"
#include "prog.h"

#include "cpwDoc.h"

#include "cpwView.h"

#include "cpwDb.h"
#include "cpwExt.h"
#include "cache.h"            
#include "ProgMaq.h"
#include "OrdMaq.h"
#include "Dialogs.h" 
#include "OrdenDlg.h"  

#include "strstrea.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


	
void CCpwView::PrintGrafico(CDC* pDC, CPrintInfo* pInfo) 
{

	CCpwDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CProg* pProg = pDoc->GetpProg();
	ASSERT_VALID(pProg);

	CString buffer;

	CTime tempFec = m_PI.m_Abs.GetFecIni();
	tempFec += (CTimeSpan) (((pInfo->m_nCurPage - 1) * 
							m_PI.m_iDaysPerPage ) * TK_SEGS_DIA);
   
	CTimeSpan tsDespl;

	// Calculamos las fechas de inicio y de fin que realmente hay que pintar
	// en esta p�gina
	CTime FecIni = tempFec;
	CTime FecFin = tempFec + m_PI.m_iDaysPerPage * TK_SEGS_DIA;
	if (FecFin > m_PI.m_Abs.m_FecFin) FecFin = m_PI.m_Abs.m_FecFin;

 	// Sacamos las cabeceras
	CTime Hoy = CTime::GetCurrentTime();
	CString Tit;
	pDC->SelectObject(m_PI.m_pFont90);
	int iSiglo = (Hoy.GetYear() / 100) * 100;
	Tit.Format("P R O G R A M A C I O N     D E    I N Y E C C I O N      %d-%d-%d",
					Hoy.GetDay(),
					Hoy.GetMonth(),
					Hoy.GetYear() % iSiglo );
	pDC->TextOut(60, 1, Tit);
	pDC->SelectObject(m_PI.m_pFontNormal);
	
	
	// E imprimimos los d�as del calendario
	int x = (int) (m_PI.m_iPixCol / 4) ;
	int y = m_PI.m_iCabHeight;
	FecIni = CTime(FecIni.GetYear(), FecIni.GetMonth(), FecIni.GetDay(), TK_TURNO3_FIN,0,0);
	CTime Fec = FecIni; 
	FecFin = CTime(FecFin.GetYear(), FecFin.GetMonth(), FecFin.GetDay(), TK_TURNO3_FIN,0,0);
	
	CPen PenDash(PS_DASH, 1, RGB(0,0,0));
	CPen PenSolid(PS_SOLID, 1, RGB(0,0,0));
	int iDespIni = m_PI.m_iCabHeight;
	BOOL bResaltado = TRUE;
	while (Fec <= FecFin)
	{
		CString sDia;
		pDC->SelectObject(&PenSolid);			
		
		Fec = CTime(Fec.GetYear(), Fec.GetMonth(), Fec.GetDay(), TK_TURNO3_FIN,0,0);
		if (Fec > FecFin) break;
		if (Fec >= FecIni)
		{
			tsDespl = Fec - FecIni;
			y = (int) (tsDespl.GetTotalSeconds() / m_PI.m_lConvFactor) + m_PI.m_iCabHeight;
			pDC->MoveTo(0,y);
			pDC->LineTo(m_PI.m_iHres, y);
		}
		if (!bResaltado)
			bResaltado = TRUE;
		else
		{
			pDC->FillRect(CRect((int) (.25 * m_PI.m_iPixCol), 
							iDespIni, 
							m_PI.m_iHres, 
							y), 
							&CBrush(RGB(180,180,180)));
			bResaltado = FALSE;
		}
		iDespIni = y;

		Fec = CTime(Fec.GetYear(), Fec.GetMonth(), Fec.GetDay(), TK_TURNO1_FIN,0,0);
		if (Fec > FecFin) break;
		if (Fec >= FecIni)
		{
			tsDespl = Fec - FecIni;
			y = (int) (tsDespl.GetTotalSeconds() /  m_PI.m_lConvFactor) + m_PI.m_iCabHeight;
			pDC->SelectObject(&PenDash);
			pDC->MoveTo(0,y);
			pDC->LineTo(m_PI.m_iHres, y);
		}

		Fec = CTime(Fec.GetYear(), Fec.GetMonth(), Fec.GetDay(), (TK_TURNO1_FIN + TK_TURNO2_FIN) / 2,0,0);
		CTime FecI = Fec - (CTimeSpan) ((m_FontHeight *  m_PI.m_lConvFactor) / 2);
		CTime FecF = Fec + (CTimeSpan) ((m_FontHeight *  m_PI.m_lConvFactor) / 2);
		if (FecI > FecFin) break;
		if (FecF >= FecIni)
		{
			tsDespl = FecI - FecIni;
			y = (int) (tsDespl.GetTotalSeconds() /  m_PI.m_lConvFactor) + m_PI.m_iCabHeight;
			sDia.Format("%d", Fec.GetDay());
			pDC->TextOut(3, y, sDia );
		}


		Fec = CTime(Fec.GetYear(), Fec.GetMonth(), Fec.GetDay(), 22,0,0);
		if (Fec > FecFin) break;
		if (Fec >= FecIni)
		{
			tsDespl = Fec - FecIni;
			y = (int) (tsDespl.GetTotalSeconds() /  m_PI.m_lConvFactor) + m_PI.m_iCabHeight;
			pDC->MoveTo(0,y);
			pDC->LineTo(m_PI.m_iHres, y);
		}

		Fec += (CTimeSpan) TK_CAMBIO_DIA;
	}   
	int MaxY = y;
	if (Fec.GetDay() % 2)
	{
		pDC->FillRect(CRect((int) (.25 * m_PI.m_iPixCol), 
			iDespIni, 
			m_PI.m_iHres, 
			y), 
			&CBrush(RGB(180,180,180)));
	}
	pDC->SelectObject(&PenSolid);			
		
	int NumMaq = pProg->GetNumPM();
	CBrush gBrush(RGB(150,150,150));
	
	int iCol = 0;
	// Ahora sacamos las OM's
	for (int i=0; i<NumMaq ; i++)
	{
		CProgMaq* pMaq = pProg->GetpPM(i);
		ASSERT_VALID(pMaq);
			
		if (pMaq->GetsGFH() < m_PI.m_sDesdeGFH) continue;
		if (pMaq->GetsGFH() > m_PI.m_sHastaGFH) continue;

		int NumOrd = pMaq->GetNumOM();
		for (int j=0; j<NumOrd; j++)
		{
			COrdMaq* pOM = pMaq->GetpOM(j);
			ASSERT_VALID(pOM);
			if (pOM->GetFecIni() > FecFin) break;
			CRect Rect = GetRectPrint(pOM, iCol, FecIni);
			//Rect.left += int (m_PI.m_iPixCol*.25 / 2);
			//Rect.right -=  int (m_PI.m_iPixCol*.25 / 2);
			if (Rect.top < m_PI.m_iCabHeight) 
				Rect.top =  m_PI.m_iCabHeight - 2;
			if (Rect.bottom < m_PI.m_iCabHeight) 
				Rect.bottom =  m_PI.m_iCabHeight;
			if (Rect.top > MaxY ) 
				Rect.top =  MaxY;
			if (Rect.bottom > MaxY ) 
				Rect.bottom =  MaxY;
			int despl = Rect.left + 1;
			pDC->SelectObject(pOM->GetpBrush(Impresora));
			pDC->Rectangle(Rect);

		}
		iCol++;
	}
	
	// Pintamos las m�quinas
	CBrush BrushWhite(RGB(255,255,255));
	iCol = 0;
	for (i=0; i<NumMaq ; i++)
	{
		CProgMaq* pPM = pProg->GetpPM(i);
		ASSERT_VALID(pPM);
		
		if (pPM->GetsGFH() < m_PI.m_sDesdeGFH) continue;
		if (pPM->GetsGFH() > m_PI.m_sHastaGFH) continue;

		int xi = (int) ((iCol + .25 ) * m_PI.m_iPixCol); 
		int xf = xi + m_PI.m_iPixCol;
		pDC->FillRect(CRect(xi, m_PI.m_iTitleHeight, xf, m_PI.m_iCabHeight), &BrushWhite);
		pDC->MoveTo(xi, m_PI.m_iTitleHeight);
		pDC->LineTo(xi, m_PI.m_iCabHeight);
		pDC->LineTo(xf, m_PI.m_iCabHeight);
		pDC->SetBkMode(TRANSPARENT); 
		pDC->SelectObject(m_PI.m_pFont90);
		int xc = (xi+xf)/2 - pPM->GetsID().GetLength() * m_PI.m_iWidth90 / 2 ;
		if (xc < xi) xc = xi;
		pDC->TextOut( xc, m_PI.m_iTitleHeight, pPM->GetsID());
		pDC->SetBkMode(OPAQUE);
		pPM->SetPosition(CPoint(xi, m_PI.m_iCabHeight));
		pDC->SelectObject(m_PI.m_pFontNormal);
		
		// Pintamos ahora las inactividades de esa m�quina
	
		Fec = FecIni;
		for (int j = 0; j < pPM->GetNumInacts(); j++)
		{
			RECT InactRect;
			CAbSpan Inact = *(pPM->GetpInact(j));
			if (Inact.GetFecIni() > FecFin) break;
			tsDespl = Fec - FecIni;
			y = (int) (tsDespl.GetTotalSeconds() / m_PI.m_lConvFactor) + m_PI.m_iCabHeight;
			
			tsDespl = Inact.GetFecIni() - FecIni;
			InactRect.top = (int) ((tsDespl.GetTotalSeconds() 
									/ m_PI.m_lConvFactor) + m_PI.m_iCabHeight);
			tsDespl = Inact.GetFecFin() - Inact.GetFecIni();
			InactRect.bottom = (int) (InactRect.top + 
									(tsDespl.GetTotalSeconds() 
									/ m_PI.m_lConvFactor));
			InactRect.left = xi;
			InactRect.right = xf;
			if (InactRect.top < m_PI.m_iCabHeight) 
				InactRect.top =  m_PI.m_iCabHeight;
			if (InactRect.bottom < m_PI.m_iCabHeight) 
				InactRect.bottom =  m_PI.m_iCabHeight;
			if (InactRect.top > MaxY ) 
				InactRect.top =  MaxY;
			if (InactRect.bottom > MaxY ) 
				InactRect.bottom =  MaxY;
				pDC->MoveTo(InactRect.left,InactRect.top);
			pDC->LineTo(InactRect.right, InactRect.top);
			pDC->LineTo(InactRect.left, InactRect.bottom);
			pDC->LineTo(InactRect.right,InactRect.bottom);
			pDC->LineTo(InactRect.left, InactRect.top);
		}

		iCol++;
	}

// Ahora pintamos los textos de las OM�s
	iCol = 0;
	for ( i=0; i<NumMaq ; i++)
	{
		CProgMaq* pMaq = pProg->GetpPM(i);
		ASSERT_VALID(pMaq);
		
		if (pMaq->GetsGFH() < m_PI.m_sDesdeGFH) continue;
		if (pMaq->GetsGFH() > m_PI.m_sHastaGFH) continue;

		int NumOrd = pMaq->GetNumOM();     
		for (int j=0; j<NumOrd; j++)
		{   
			CString buffer;
			COrdMaq* pOM = pMaq->GetpOM(j);
			ASSERT_VALID(pOM);
			if (pOM->GetFecIni() > FecFin) break;
			CRect Rect = GetRectPrint(pOM, iCol, FecIni); 
			int despl = Rect.left + 1;
			if (Rect.top < m_PI.m_iCabHeight) 
				Rect.top =  m_PI.m_iCabHeight - 2;
			if (Rect.bottom < m_PI.m_iCabHeight) 
				continue;
			pDC->SetBkColor(RGB(255,255,255));
			pDC->SetBkMode(OPAQUE);              
			CFont FontReducido;
			int iMaxHeight = Rect.bottom - Rect.top - 4;
			if (iMaxHeight < 10) iMaxHeight = 10;
			FontReducido.CreateFont( iMaxHeight, 0, 0, 0, FW_NORMAL, 0, 0, 0, ANSI_CHARSET, 
				OUT_CHARACTER_PRECIS, CLIP_CHARACTER_PRECIS, DEFAULT_QUALITY, FIXED_PITCH, NULL); 
			CFont FontReducidoBold;
			FontReducidoBold.CreateFont( iMaxHeight, 0, 0, 0, FW_BOLD, 0, 0, 0, ANSI_CHARSET, 
				OUT_CHARACTER_PRECIS, CLIP_CHARACTER_PRECIS, DEFAULT_QUALITY, FIXED_PITCH, NULL); 
			
			if ( (pOM->GetBNuevoCel() && (pOM->GetsGFH() == TK_GFH_CELULAS ) ) ||
				(pOM->GetBNuevoLlen() && (pOM->GetsGFH() == TK_GFH_LLENADORAS ) ) )
			{
				if (iMaxHeight < m_PI.m_iFontHeight )
					pDC->SelectObject(&FontReducidoBold);
				else
					pDC->SelectObject(m_PI.m_pFontNormalBold);
			} else
			{
				if (iMaxHeight < m_PI.m_iFontHeight )
					pDC->SelectObject(&FontReducido);
				else
					pDC->SelectObject(m_PI.m_pFontNormal);
			} 
			
			buffer.Format("%5.5ld", pOM->GetlOF());
			pDC->TextOut(despl,Rect.top+2,buffer);
			despl += 5 * m_PI.m_iWidthNormal + 4;
			buffer.Format( "%-9.9s", (const char*) pOM->GetsNombre());
			pDC->TextOut(despl,Rect.top+2,buffer);
			despl += 9 * m_PI.m_iWidthNormal + 4;
			if (pOM->GetsGFH() == TK_GFH_CELULAS)
			{
				buffer.Format("%3.3lf", pOM->GetdMaxPerson());
			}
			else if (pOM->GetsGFH() == TK_GFH_CURVADORAS)
			{
				int pc = (int) 0;
				char cpc = (pc > 1 && pc < 10) ? ((char) pc)+'0' : ' ';
				buffer.Format("%c %c",pOM->GetcExtInt(),cpc);
			}
			else
			{
				buffer.Format("%c  ",pOM->GetcExtInt());
			}
			pDC->TextOut(despl,Rect.top+2, buffer,3);
			despl += 3 * m_PI.m_iWidthNormal + 4;
			if ( (pOM->GetBNuevoCel() && (pOM->GetsGFH() == TK_GFH_CELULAS ) ) ||
				(pOM->GetBNuevoLlen() && (pOM->GetsGFH() == TK_GFH_LLENADORAS ) ) )
			{
				pDC->TextOut(despl, Rect.top+2, "*", 1);
			}
			
		}
		iCol++;
	}

	// Y sacamos el pie, a ser posible por la ventanilla
	pDC->SelectObject(m_PI.m_pFont90);
	CString sPie;

	iSiglo = (Hoy.GetYear() / 100) * 100;

	sPie.Format( "          FECHA: %d-%d-%d  %d:%d    SUSTITUYE A:                 FIRMA:"
				,Hoy.GetDay(), Hoy.GetMonth(), Hoy.GetYear() % iSiglo, 
				 Hoy.GetHour(), Hoy.GetMinute() );
	pDC->TextOut(10, m_PI.m_iVres - m_PI.m_iFootHeight , sPie);

	
	pDC->SelectObject(&m_Brush);
}



void CCpwView::BeginPrintingGrafico(CDC* pDC, CPrintInfo* pInfo)
{
	CCpwDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CProg* pProg = pDoc->GetpProg();
	ASSERT_VALID(pProg);


	m_PI.m_iNumCols = pProg->GetNumPMsInGFHs(m_PI.m_sDesdeGFH, m_PI.m_sHastaGFH);

	// Cuantos pixels tenemos para cada una, teniendo en cuenta que 1/6
	// de columna es para separaci�n entre ellas, y hay una escala de 1/4
	// de columna al principio
	m_PI.m_iHres = pDC->GetDeviceCaps(HORZRES); 
	m_PI.m_iVres = pDC->GetDeviceCaps(VERTRES); 
	m_PI.m_iPixCol = (int) (m_PI.m_iHres / (m_PI.m_iNumCols + .25));
	// Teniendo en cuenta que por cada columna tenemos que meter  19 carac
	// teres, calculamos la anchura del font
	int iPixReal = (int) ( m_PI.m_iPixCol * .925 );
	int iWidth = iPixReal / 19;
	// calculamos la altura del font
	double dRatio = 1.67;
	m_PI.m_iFontHeight = (int) (iWidth*dRatio) + 1;

	if (m_PI.m_pFontNormal) 
	{
		m_PI.m_pFontNormal->DeleteObject();
		delete m_PI.m_pFontNormal;
	}
	if (m_PI.m_pFontNormalBold) 
	{
		m_PI.m_pFontNormalBold->DeleteObject();
		delete m_PI.m_pFontNormalBold;
	}
	if (m_PI.m_pFont90) 
	{
		m_PI.m_pFont90->DeleteObject();
		delete m_PI.m_pFont90;
	}
	
	m_PI.m_pFontNormal = new CFont;
	m_PI.m_pFontNormal->CreateFont(m_PI.m_iFontHeight , iWidth, 0, 0, FW_NORMAL, 0, 0, 0, ANSI_CHARSET, 
		OUT_CHARACTER_PRECIS, CLIP_CHARACTER_PRECIS, DEFAULT_QUALITY, FIXED_PITCH, NULL); 
	m_PI.m_pFontNormalBold = new CFont;
	m_PI.m_pFontNormalBold->CreateFont(m_PI.m_iFontHeight+2, iWidth, 0, 0, FW_BOLD, 0, 0, 0, ANSI_CHARSET, 
		OUT_CHARACTER_PRECIS, CLIP_CHARACTER_PRECIS, DEFAULT_QUALITY, FIXED_PITCH, NULL); 
	m_PI.m_pFont90 = new CFont;
	m_PI.m_pFont90->CreateFont((int) (m_PI.m_iHres/90*dRatio+1), m_PI.m_iHres/90, 0, 0, FW_BOLD, 0, 0, 0, ANSI_CHARSET, 
		OUT_CHARACTER_PRECIS, CLIP_CHARACTER_PRECIS, DEFAULT_QUALITY, FIXED_PITCH, NULL); 

	
	pDC->SelectObject(m_PI.m_pFont90);
	TEXTMETRIC TM;
	pDC->GetTextMetrics(&TM);

	m_PI.m_iLinHeight = TM.tmHeight;
	m_PI.m_iCabHeight = (int) (m_PI.m_iLinHeight * 3.5);
	m_PI.m_iTitleHeight = (int) (m_PI.m_iLinHeight * 2);
	m_PI.m_iFootHeight = m_PI.m_iLinHeight;
	m_PI.m_iWidth90 = TM.tmAveCharWidth;
	
	pDC->SelectObject(m_PI.m_pFontNormal);
	pDC->GetTextMetrics(&TM);

	m_PI.m_iWidthNormal = TM.tmAveCharWidth;
	
	long lTimeScale = pProg->GetTimeScale();   
	
	CClientDC screenDC(NULL);
	CSize screenRes(screenDC.GetDeviceCaps(LOGPIXELSX),
						  screenDC.GetDeviceCaps(LOGPIXELSY));
	CSize printRes(pDC->GetDeviceCaps(LOGPIXELSX),
						 pDC->GetDeviceCaps(LOGPIXELSY));
	m_PI.m_lConvFactor = MulDiv(lTimeScale, screenRes.cy, printRes.cy);
 	
	// Calculamos ahora cu�ntos d�a entran en cada p�gina

	double dPixDia = (double)TK_SEGS_DIA / m_PI.m_lConvFactor;
	double dDiaPag = (double) (m_PI.m_iVres - m_PI.m_iCabHeight) / dPixDia;
	int iDaysPerPage = (dDiaPag > 1) ? (int) dDiaPag : 1;
	m_PI.m_iDaysPerPage = iDaysPerPage;

	// Y ahora cu�ntas p�ginas necesitamos
	int iNumDias = (int) ((m_PI.m_Abs.GetFecFin() - 
							m_PI.m_Abs.GetFecIni()).GetDays());
	int iMaxPg = (int) (iNumDias / iDaysPerPage) + ((iNumDias % iDaysPerPage) ? 1 : 0); 
	if (iMaxPg < 1) iMaxPg = 1;
	// Actualizamos el n�mero de p�ginas

	 pInfo->SetMaxPage(iMaxPg);
  
}




void CCpwView::EndPrintingGrafico(CDC* pDC, CPrintInfo* pInfo)
{
	
}

// Listado de M�quinas

void CCpwView::EndPrintingProgMaq(CDC* pDC, CPrintInfo* pInfo)
{
	
}

void CCpwView::PrintProgMaq(CDC* pDC, CPrintInfo* pInfo) 
{
	// TODO: Actualizamos los par�metros de la p�gina 

	if (!m_PI.m_pPM) return;
	
	CCpwDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CProg* pProg = pDoc->GetpProg();
	ASSERT_VALID(pProg);

	m_PI.m_iNumOM = (pInfo->m_nCurPage - 1) * m_PI.m_iLinsPerPage;
   


	CString sLin;
	int iLinH = m_PI.m_iLinHeight;
	// Sacamos cabeceras
	pDC->SelectObject(m_PI.m_pFont90b);
	sLin.Format("                     P R O G R A M A      D E     I N Y E C C I O N");
	pDC->TextOut( 80, iLinH, sLin );
	pDC->SelectObject(m_PI.m_pFont90);

//	sLin.Format( "MAQUINA : %s", m_PI.m_pPM->GetsDescripcion());
//	pDC->TextOut( 80, 3*iLinH, sLin );
	BOOL BNuevo = FALSE;
	sLin.Format( "MAQ. OFERTA   MEZCLA  PIEZAS     P/H   TIEMPO    FEC.INICIO");
	pDC->TextOut( 80, 6*iLinH, sLin );
	sLin.Format( "--- -------- -------- ------- -------- ------  --------------");
	pDC->TextOut( 80, 7*iLinH, sLin );
	int iLin = 1;		// L�nea que vamos imprimiendo
	BOOL BPrimera = TRUE;
	// Imprimimos las l�neas de detalle
	while ( GetLinProgMaq( sLin, BPrimera, BNuevo ))
	{
		BPrimera = FALSE;
		// Si es nuevo lo sacamos en negrita
		if (BNuevo)	
			pDC->SelectObject(m_PI.m_pFont90b);
		else 
			pDC->SelectObject(m_PI.m_pFont90);
	
		pDC->TextOut( 80, (iLin+7)*iLinH, sLin);
			
		// Si ya no tenemos sitio para m�s l�neas en la p�gina, hacemos otra
		iLin++;
		if (iLin > m_PI.m_iLinsPerPage) break;
		
	}

	// Pie
	CTime FecHoy = CTime::GetCurrentTime();
	int iYear = FecHoy.GetYear();
	int iSiglo = (iYear / 100) * 100;

	sLin.Format( "          FECHA: %2d-%2d-%2d  %2d:%2d    SUSTITUYE A:                 FIRMA:"
				,FecHoy.GetDay(), FecHoy.GetMonth(), iYear % iSiglo, 
				 FecHoy.GetHour(), FecHoy.GetMinute() );
	//pDC->TextOut( 10, ( m_PI.m_iLinsPerPage+1)*iLinH, sLin );
	pDC->TextOut(10, m_PI.m_iVres - m_PI.m_iFootHeight , sLin);
  
  
}



void CCpwView::BeginPrintingProgMaq(CDC* pDC, CPrintInfo* pInfo)
{
	CCpwDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CProg* pProg = pDoc->GetpProg();
	ASSERT_VALID(pProg);

	pProg->GetArrMaqOM(m_PI.m_ArrOMs);
	int iLim = pProg->GetArrMaqOM(m_PI.m_ArrOMs);
	// Vamos a filtrarlo para quedarnos s�lo con m�quinas y fechas seleccionadas
	for (int i=0; i < iLim; i++)
	{
		COrdMaq* pOM = (COrdMaq*) m_PI.m_ArrOMs.GetAt(i);
		BOOL bRepMaq = FALSE;
		if (pOM->GetFecIni() > m_PI.m_Abs.GetFecFin() || 
		 (pOM->GetFecFin() < m_PI.m_Abs.GetFecIni()) ||
		 (pOM->GetsMaquina() < m_PI.m_sDesdeMaq) ||
		 (pOM->GetsMaquina() > m_PI.m_sHastaMaq) )
		{
			m_PI.m_ArrOMs.RemoveAt(i);
			i--;
			iLim--;
		}
	}

	m_PI.m_FecPrev = CTime(1900,1,1);

	m_PI.m_iHres = pDC->GetDeviceCaps(HORZRES); 
	m_PI.m_iVres = pDC->GetDeviceCaps(VERTRES); 

	double dRatio = 1.67;
	if (m_PI.m_pFont90) 
	{
		m_PI.m_pFont90->DeleteObject();
		delete m_PI.m_pFont90;
	}
	
	if (m_PI.m_pFont90b) 
	{
		m_PI.m_pFont90b->DeleteObject();
		delete m_PI.m_pFont90b;
	}
	
	m_PI.m_pFont90 = new CFont;
	m_PI.m_pFont90->CreateFont((int) (m_PI.m_iHres/100*dRatio+1), m_PI.m_iHres/100, 0, 0, FW_NORMAL, 0, 0, 0, ANSI_CHARSET, 
		OUT_CHARACTER_PRECIS, CLIP_CHARACTER_PRECIS, DEFAULT_QUALITY, FIXED_PITCH, NULL); 
	m_PI.m_pFont90b = new CFont;
	m_PI.m_pFont90b->CreateFont((int) (m_PI.m_iHres/100*dRatio+1), m_PI.m_iHres/100, 0, 0, FW_BOLD, 0, 0, 0, ANSI_CHARSET, 
		OUT_CHARACTER_PRECIS, CLIP_CHARACTER_PRECIS, DEFAULT_QUALITY, FIXED_PITCH, NULL); 

	
	pDC->SelectObject(m_PI.m_pFont90);
	TEXTMETRIC TM;
	pDC->GetTextMetrics(&TM);

	m_PI.m_iLinHeight = TM.tmHeight + TM.tmExternalLeading;

	m_PI.m_iCabHeight = (int) (m_PI.m_iLinHeight * 4);
	m_PI.m_iTitleHeight = (int) (m_PI.m_iLinHeight * 2);
	m_PI.m_iFootHeight = (int) (m_PI.m_iLinHeight * 5);

	m_PI.m_iWidth90 = TM.tmAveCharWidth;
	
	
	// Calculamos ahora cu�ntas l�neas entran en cada p�gina

	m_PI.m_iLinsPerPage = (m_PI.m_iVres / m_PI.m_iLinHeight) - 15;

	// Y ahora cu�ntas p�ginas necesitamos
	int iMaxPg = (m_PI.m_ArrOMs.GetSize() / m_PI.m_iLinsPerPage) + 1;
	if (iMaxPg < 1) iMaxPg = 1;
	// Actualizamos el n�mero de p�ginas

	 pInfo->SetMaxPage(iMaxPg);
	m_PI.m_iNumOM = 0;

}

BOOL 
CCpwView::GetLinProgMaq(CString& p_sLin, BOOL p_BPrimera, BOOL& pr_BNuevo)
{
	static CString s_sMaqPrev = "";
	if (m_PI.m_iNumOM >= m_PI.m_ArrOMs.GetSize()) return FALSE;
	// Obtenemos la Orden indicada por m_PI.m_iNumOM, que es el contador

	COrdMaq* pOM = (COrdMaq*) m_PI.m_ArrOMs.GetAt(m_PI.m_iNumOM);
	// Sumamos uno al contador para la siguiente vez
	m_PI.m_iNumOM++;

	CTime FecIni = pOM->GetFecIni();
	CTime FecFin = pOM->GetFecFin();
	CTimeSpan tsTiempo = pOM->GetTimeSpan();
	
	long lCant = pOM->GetlCantidad();
	double dCadencia = pOM->GetdCadencia();
	
	
	// Pasamos la cantidad a una cadena para ponerle puntos de millar
	CString sCant;
	FormatLong(lCant, sCant, 6);
	CString sMaq;
	if (p_BPrimera || s_sMaqPrev != pOM->GetsMaquina()) 
	{
		sMaq = pOM->GetsMaquina();
		s_sMaqPrev = sMaq;
	}
	else
	{
		sMaq = "";
	}
	double dTiempo = (double) (tsTiempo.GetTotalSeconds() / (double) TK_SEGS_HORA);
	
		p_sLin.Format( "%-4.4s%-8.8s  %-8.8s  %s    %s  %s %14.14s",
					sMaq,
					pOM->GetsID(),
					pOM->GetsMezcla(),
					(const char*) sCant,
					FormatLong((long) pOM->GetdCadencia(),5) ,
					FormatLong((pOM->GetTimeSpan().GetTotalHours()),5),
					FormatFec(pOM->GetFecIni(), FecHora));
			
	return TRUE;
}


// Listado de M�quinas

void CCpwView::EndPrintingMoldes(CDC* pDC, CPrintInfo* pInfo)
{
	
}

void CCpwView::PrintMoldes(CDC* pDC, CPrintInfo* pInfo) 
{
	// TODO: Actualizamos los par�metros de la p�gina 

	if (!m_PI.m_pPM) return;
	
	CCpwDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CProg* pProg = pDoc->GetpProg();
	ASSERT_VALID(pProg);

	m_PI.m_iNumOM = (pInfo->m_nCurPage - 1) * m_PI.m_iLinsPerPage;
   


	CString sLin;
	int iLinH = m_PI.m_iLinHeight;
	// Sacamos cabeceras
	pDC->SelectObject(m_PI.m_pFont90b);
	sLin.Format("                     C A M B I O S      D E     M O L D E S");
	pDC->TextOut( 80, iLinH, sLin );
	pDC->SelectObject(m_PI.m_pFont90);

	BOOL BNuevo = FALSE;
	sLin.Format( "MAQ. ENTRANTE SALIENTE  HORA       CAUSA        MEZCLA ");
	pDC->TextOut( 80, 6*iLinH, sLin );
	sLin.Format( "--- --------- -------- ------- ---------------  ------ ");
	pDC->TextOut( 80, 7*iLinH, sLin );
	int iLin = 1;		// L�nea que vamos imprimiendo
	BOOL BPrimera = TRUE;
	// Imprimimos las l�neas de detalle
	while ( GetLinMoldes( sLin, BPrimera, BNuevo ))
	{
		BPrimera = FALSE;
		// Si es nuevo lo sacamos en negrita
		pDC->SelectObject(m_PI.m_pFont90);
	
		pDC->TextOut( 80, (iLin+7)*iLinH, sLin);
			
		// Si ya no tenemos sitio para m�s l�neas en la p�gina, hacemos otra
		iLin++;
		if (iLin > m_PI.m_iLinsPerPage) break;
		
	}

	// Pie
	CTime FecHoy = CTime::GetCurrentTime();
	int iYear = FecHoy.GetYear();
	int iSiglo = (iYear / 100) * 100;

	sLin.Format( "          FECHA: %2d-%2d-%2d  %2d:%2d    SUSTITUYE A:                 FIRMA:"
				,FecHoy.GetDay(), FecHoy.GetMonth(), iYear % iSiglo, 
				 FecHoy.GetHour(), FecHoy.GetMinute() );
	//pDC->TextOut( 10, ( m_PI.m_iLinsPerPage+1)*iLinH, sLin );
	pDC->TextOut(10, m_PI.m_iVres - m_PI.m_iFootHeight , sLin);
  
  
}



void CCpwView::BeginPrintingMoldes(CDC* pDC, CPrintInfo* pInfo)
{
	CCpwDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CProg* pProg = pDoc->GetpProg();
	ASSERT_VALID(pProg);

	int iLim = pProg->GetArrMaqOM(m_PI.m_ArrOMs);
	// Vamos a filtrarlo para quedarnos s�lo con m�quinas y fechas seleccionadas
	for (int i=0; i < iLim; i++)
	{
		COrdMaq* pOM = (COrdMaq*) m_PI.m_ArrOMs.GetAt(i);
		BOOL bRepMaq = FALSE;
		if (pOM->GetFecIni() > m_PI.m_Abs.GetFecFin() || 
		 (pOM->GetFecFin() < m_PI.m_Abs.GetFecIni()) ||
		 (pOM->GetsMaquina() < m_PI.m_sDesdeMaq) ||
		 (pOM->GetsMaquina() > m_PI.m_sHastaMaq) )
		{
			m_PI.m_ArrOMs.RemoveAt(i);
			i--;
			iLim--;
		}
	}
	iLim = m_PI.m_ArrOMs.GetSize();
	// Vamos a filtrarlo para quedarnos s�lo con los cambios de moldes
	for ( i=0; i < iLim; i++)
	{
		COrdMaq* pOM = (COrdMaq*) m_PI.m_ArrOMs.GetAt(i);
		COrdMaq* pOMPrev = NULL;
		COrdMaq* pOMNext = NULL;
		if ( (i+1) < iLim)
		{
			pOMNext = (COrdMaq*) m_PI.m_ArrOMs.GetAt(i+1);
			if ( pOM->GetsMolde() == pOMNext->GetsMolde() && 
				pOM->GetsMaquina() == pOMNext->GetsMaquina())  
			{
				m_PI.m_ArrOMs.RemoveAt(i);
				i--;
				iLim--;
			}
		}
	}	

	m_PI.m_FecPrev = CTime(1900,1,1);

	m_PI.m_iHres = pDC->GetDeviceCaps(HORZRES); 
	m_PI.m_iVres = pDC->GetDeviceCaps(VERTRES); 

	double dRatio = 1.67;
	if (m_PI.m_pFont90) 
	{
		m_PI.m_pFont90->DeleteObject();
		delete m_PI.m_pFont90;
	}
	
	if (m_PI.m_pFont90b) 
	{
		m_PI.m_pFont90b->DeleteObject();
		delete m_PI.m_pFont90b;
	}
	
	m_PI.m_pFont90 = new CFont;
	m_PI.m_pFont90->CreateFont((int) (m_PI.m_iHres/100*dRatio+1), m_PI.m_iHres/100, 0, 0, FW_NORMAL, 0, 0, 0, ANSI_CHARSET, 
		OUT_CHARACTER_PRECIS, CLIP_CHARACTER_PRECIS, DEFAULT_QUALITY, FIXED_PITCH, NULL); 
	m_PI.m_pFont90b = new CFont;
	m_PI.m_pFont90b->CreateFont((int) (m_PI.m_iHres/100*dRatio+1), m_PI.m_iHres/100, 0, 0, FW_BOLD, 0, 0, 0, ANSI_CHARSET, 
		OUT_CHARACTER_PRECIS, CLIP_CHARACTER_PRECIS, DEFAULT_QUALITY, FIXED_PITCH, NULL); 

	
	pDC->SelectObject(m_PI.m_pFont90);
	TEXTMETRIC TM;
	pDC->GetTextMetrics(&TM);

	m_PI.m_iLinHeight = TM.tmHeight + TM.tmExternalLeading;

	m_PI.m_iCabHeight = (int) (m_PI.m_iLinHeight * 4);
	m_PI.m_iTitleHeight = (int) (m_PI.m_iLinHeight * 2);
	m_PI.m_iFootHeight = (int) (m_PI.m_iLinHeight * 5);

	m_PI.m_iWidth90 = TM.tmAveCharWidth;
	
	
	// Calculamos ahora cu�ntas l�neas entran en cada p�gina

	m_PI.m_iLinsPerPage = (m_PI.m_iVres / m_PI.m_iLinHeight) - 15;

	// Y ahora cu�ntas p�ginas necesitamos
	int iMaxPg = (m_PI.m_ArrOMs.GetSize() / m_PI.m_iLinsPerPage) + 1;
	if (iMaxPg < 1) iMaxPg = 1;
	// Actualizamos el n�mero de p�ginas

	 pInfo->SetMaxPage(iMaxPg);
	m_PI.m_iNumOM = 0;

}

BOOL 
CCpwView::GetLinMoldes(CString& p_sLin, BOOL p_BPrimera, BOOL& pr_BNuevo)
{
	static CString s_sMaqPrev = "";
	if (m_PI.m_iNumOM >= m_PI.m_ArrOMs.GetSize()) return FALSE;
	// Obtenemos la Orden indicada por m_PI.m_iNumOM, que es el contador

	COrdMaq* pOM = (COrdMaq*) m_PI.m_ArrOMs.GetAt(m_PI.m_iNumOM);
	COrdMaq* pOMPrev = NULL;
	if (m_PI.m_iNumOM-1 >= 0)
	{
		pOMPrev = (COrdMaq*) m_PI.m_ArrOMs.GetAt(m_PI.m_iNumOM-1);
		if (pOMPrev->GetsMaquina() != pOM->GetsMaquina())
			pOMPrev = NULL;
	}
	// Sumamos uno al contador para la siguiente vez
	m_PI.m_iNumOM++;

	CTime FecIni = pOM->GetFecIni();
	CTime FecFin = pOM->GetFecFin();
	CTimeSpan tsTiempo = pOM->GetTimeSpan();
	
	long lCant = pOM->GetlCantidad();
	double dCadencia = pOM->GetdCadencia();
	
	
	// Pasamos la cantidad a una cadena para ponerle puntos de millar
	CString sCant;
	FormatLong(lCant, sCant, 6);
	CString sMaq;
	if (p_BPrimera || s_sMaqPrev != pOM->GetsMaquina()) 
	{
		sMaq = pOM->GetsMaquina();
		s_sMaqPrev = sMaq;
	}
	else
	{
		sMaq = "";
	}
	double dTiempo = (double) (tsTiempo.GetTotalSeconds() / (double) TK_SEGS_HORA);
	
		p_sLin.Format( "%-4.4s%-8.8s  %-8.8s  %5.5s  %15.15s  %s",
					sMaq,
					pOM->GetsID(),
					(pOMPrev != NULL) ? pOMPrev->GetsID() : "",
					FormatFec(pOM->GetFecFin(),Hora),
					"",
					pOM->GetsMezcla());
	return TRUE;
}

