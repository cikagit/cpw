// DlgOpciones.cpp : implementation file
//

#include "stdafx.h"
#include "cpw.h"
#include "cpwDefs.h"
#include "ObArrOrd.h"
#include "AbSpan.h"
#include "prog.h"
#include "cpwDb.h"
#include "cpwExt.h"
#include "cache.h"            
#include "ProgMaq.h"
#include "ChildFrm.h"
#include "cpwDoc.h"
#include "cpwView.h"

#include "DlgOpciones.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgOpciones dialog


CDlgOpciones::CDlgOpciones(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgOpciones::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgOpciones)
	//}}AFX_DATA_INIT
}


void CDlgOpciones::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgOpciones)
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgOpciones, CDialog)
	//{{AFX_MSG_MAP(CDlgOpciones)
	ON_BN_CLICKED(IDC_COLOR_0, OnColor0)
	ON_BN_CLICKED(IDC_COLOR_1, OnColor1)
	ON_BN_CLICKED(IDC_COLOR_2, OnColor2)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgOpciones message handlers

void CDlgOpciones::OnColor0() 
{
	CCpwApp* pApp = (CCpwApp*) AfxGetApp();
 
	CColorDialog ColorDialog;
	ColorDialog.m_cc.Flags |= CC_FULLOPEN | CC_RGBINIT;
	ColorDialog.m_cc.rgbResult = pApp->GetProfileInt("Valores Iniciales", "Color Peligro 0", TK_COLOR_0);
	
	
	if (ColorDialog.DoModal() == IDOK)
	{
		pApp->WriteProfileInt("Valores Iniciales", "Color Peligro 0", ColorDialog.m_cc.rgbResult);
		pApp->SetBrushes();
	
	}
}

void CDlgOpciones::OnColor1() 
{
	CCpwApp* pApp = (CCpwApp*) AfxGetApp();
 
	CColorDialog ColorDialog;
	ColorDialog.m_cc.Flags |= CC_FULLOPEN | CC_RGBINIT;
	ColorDialog.m_cc.rgbResult = pApp->GetProfileInt("Valores Iniciales", "Color Peligro 1", TK_COLOR_1);
	
	
	if (ColorDialog.DoModal() == IDOK)
	{
		pApp->WriteProfileInt("Valores Iniciales", "Color Peligro 1", ColorDialog.m_cc.rgbResult);
		pApp->SetBrushes();
	
	}
	
}

void CDlgOpciones::OnColor2() 
{
	CCpwApp* pApp = (CCpwApp*) AfxGetApp();
 
	CColorDialog ColorDialog;
	ColorDialog.m_cc.Flags |= CC_FULLOPEN | CC_RGBINIT;
	ColorDialog.m_cc.rgbResult = pApp->GetProfileInt("Valores Iniciales", "Color Peligro 2", TK_COLOR_2);
	
	
	if (ColorDialog.DoModal() == IDOK)
	{
		pApp->WriteProfileInt("Valores Iniciales", "Color Peligro 2", ColorDialog.m_cc.rgbResult);
		pApp->SetBrushes();
	}
	
}

