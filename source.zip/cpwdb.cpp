// xcpdb.cpp : implementation file
//

#include "stdafx.h"
#include "cpw.h"
#include "AbSpan.h"
#include "cpwDb.h"
#include "strstrea.h"
#include "cpwExt.h"
#include "cache.h"  
#include "cpwDefs.h"

#include "ProgMaq.h"
#include "OrdMaq.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CRsArticulo

IMPLEMENT_DYNAMIC(CRsArticulo, CRecordset)

CRsArticulo::CRsArticulo(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CRsArticulo)
	m_CantAlmacen = 0;
	m_CantFabric = 0;
	m_CantPauta = 0;
	m_CentroReb = 0;
	m_ID = _T("");
	m_MaduracionMax = 0;
	m_MaduracionMed = 0;
	m_MaduracionMin = 0;
	m_Mezcla = _T("");
	m_P_H_iny = 0;
	m_PCAct = 0.0;
	m_PCBase = 0.0;
	m_PCHist = 0.0;
	m_PCUlt = 0.0;
	m_Peso = 0;
	m_PHAct = 0.0;
	m_PHBase = 0.0;
	m_PHHist = 0.0;
	m_PHUlt = 0.0;
	m_PiezasHoraReb = 0.0;
	m_PorcChatarras = 0;
	m_nFields = 21;
	//}}AFX_FIELD_INIT
	m_nDefaultType = snapshot;
}


CString CRsArticulo::GetDefaultConnect()
{
	return _T("ODBC;DSN=MS Access 97 Database");
}

CString CRsArticulo::GetDefaultSQL()
{
	return _T("[Articulos]");
}

void CRsArticulo::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CRsArticulo)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Long(pFX, _T("[CantAlmacen]"), m_CantAlmacen);
	RFX_Long(pFX, _T("[CantFabric]"), m_CantFabric);
	RFX_Long(pFX, _T("[CantPauta]"), m_CantPauta);
	RFX_Long(pFX, _T("[CentroReb]"), m_CentroReb);
	RFX_Text(pFX, _T("[ID]"), m_ID);
	RFX_Long(pFX, _T("[MaduracionMax]"), m_MaduracionMax);
	RFX_Long(pFX, _T("[MaduracionMed]"), m_MaduracionMed);
	RFX_Long(pFX, _T("[MaduracionMin]"), m_MaduracionMin);
	RFX_Text(pFX, _T("[Mezcla]"), m_Mezcla);
	RFX_Long(pFX, _T("[P/H iny]"), m_P_H_iny);
	RFX_Double(pFX, _T("[PCAct]"), m_PCAct);
	RFX_Double(pFX, _T("[PCBase]"), m_PCBase);
	RFX_Double(pFX, _T("[PCHist]"), m_PCHist);
	RFX_Double(pFX, _T("[PCUlt]"), m_PCUlt);
	RFX_Long(pFX, _T("[Peso]"), m_Peso);
	RFX_Double(pFX, _T("[PHAct]"), m_PHAct);
	RFX_Double(pFX, _T("[PHBase]"), m_PHBase);
	RFX_Double(pFX, _T("[PHHist]"), m_PHHist);
	RFX_Double(pFX, _T("[PHUlt]"), m_PHUlt);
	RFX_Double(pFX, _T("[PiezasHoraReb]"), m_PiezasHoraReb);
	RFX_Int(pFX, _T("[PorcChatarras]"), m_PorcChatarras);
	//}}AFX_FIELD_MAP
	m_ID.TrimRight();
	m_Mezcla.TrimRight();
}

/////////////////////////////////////////////////////////////////////////////
// CRsArticulo diagnostics

#ifdef _DEBUG
void CRsArticulo::AssertValid() const
{
	CRecordset::AssertValid();
}

void CRsArticulo::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CBufArticulo

IMPLEMENT_DYNAMIC(CBufArticulo, CObject)

CBufArticulo::CBufArticulo(CRsArticulo& p_RsArticulos)
	: CObject()
{
	AssignData(p_RsArticulos);

	m_pArrArtMol = new CObArray();
}
                               
CBufArticulo::AssignData(CRsArticulo& p_RsArticulos)
{
	// TODO
	// Pensar en los posibles problemas de los valores nulos
	m_lCantAlmacen = p_RsArticulos.m_CantAlmacen;
	m_lCantFabric = p_RsArticulos.m_CantFabric;
	m_lCantPauta = p_RsArticulos.m_CantPauta;
	m_lCentroReb = p_RsArticulos.m_CentroReb;
	m_sID = p_RsArticulos.m_ID;
	m_lMaduracionMax = p_RsArticulos.m_MaduracionMax;
	m_lMaduracionMed = p_RsArticulos.m_MaduracionMed;
	m_lMaduracionMin = p_RsArticulos.m_MaduracionMin;
	m_sMezcla = p_RsArticulos.m_Mezcla;
	m_lP_H_iny = p_RsArticulos.m_P_H_iny;
	
	if (p_RsArticulos.IsFieldNull(&p_RsArticulos.m_PCAct )) m_dPCAct =0;
	else m_dPCAct = p_RsArticulos.m_PCAct;
	if (p_RsArticulos.IsFieldNull(&p_RsArticulos.m_PCBase )) m_dPCBase =0;
	else m_dPCBase = p_RsArticulos.m_PCBase;
	if (p_RsArticulos.IsFieldNull(&p_RsArticulos.m_PCHist )) m_dPCHist =0;
	else m_dPCHist = p_RsArticulos.m_PCHist;
	if (p_RsArticulos.IsFieldNull(&p_RsArticulos.m_PCUlt )) m_dPCUlt =0;
	else m_dPCUlt = p_RsArticulos.m_PCUlt;
	if (p_RsArticulos.IsFieldNull(&p_RsArticulos.m_Peso )) m_lPeso =0;
	else m_lPeso = p_RsArticulos.m_Peso;
	if (p_RsArticulos.IsFieldNull(&p_RsArticulos.m_PHAct )) m_dPHAct =0;
	else m_dPHAct = p_RsArticulos.m_PHAct;
	if (p_RsArticulos.IsFieldNull(&p_RsArticulos.m_PHBase )) m_dPHBase =0;
	else m_dPHBase = p_RsArticulos.m_PHBase;
	if (p_RsArticulos.IsFieldNull(&p_RsArticulos.m_PHHist )) m_dPHHist =0;
	else m_dPHHist = p_RsArticulos.m_PHHist;
	if (p_RsArticulos.IsFieldNull(&p_RsArticulos.m_PHUlt )) m_dPHUlt =0;
	else m_dPHUlt = p_RsArticulos.m_PHUlt;
	if (p_RsArticulos.IsFieldNull(&p_RsArticulos.m_PiezasHoraReb )) m_dPiezasHoraReb =0;
	else m_dPiezasHoraReb = p_RsArticulos.m_PiezasHoraReb;
	if (p_RsArticulos.IsFieldNull(&p_RsArticulos.m_PorcChatarras )) m_iPorcChatarras =0;
	else m_iPorcChatarras = p_RsArticulos.m_PorcChatarras;
	
	m_LV_sCliente = "";
	m_LV_dP_H_real = 0;
	m_LV_dRechazos = 0;
	m_LV_lCantidad_Fabricada = 0;
	m_LV_lCantidad_Rechazada = 0;
	m_LV_lTotal_Horas = 0;

}

CBufArticulo::CBufArticulo()
	: CObject()
{
	m_pArrArtMol = new CObArray();
	m_pBufMezcla = NULL;
	
	m_lCantAlmacen = 0;
	m_lCantFabric = 0;
	m_lCantPauta = 0;
	m_lCentroReb = 0;
	m_sID = "";
	m_lMaduracionMax = 0;
	m_lMaduracionMed = 0;
	m_lMaduracionMin = 0;
	m_sMezcla = "";
	m_lP_H_iny = 0;
	
	m_dPCAct = 0;
	m_dPCBase = 0;
	m_dPCHist = 0;
	m_dPCUlt = 0;
	m_lPeso = 0;
	m_dPHAct = 0;
	m_dPHBase = 0;
	m_dPHHist = 0;
	m_dPHUlt = 0;
	m_dPiezasHoraReb = 0;
	m_iPorcChatarras = 0;
	
	m_LV_sCliente = "";
	m_LV_dP_H_real = 0;
	m_LV_dRechazos = 0;
	m_LV_lCantidad_Fabricada = 0;
	m_LV_lCantidad_Rechazada = 0;
	m_LV_lTotal_Horas = 0;


}

CBufArticulo::~CBufArticulo()
{
//	ASSERT_VALID (m_pArrArtMol);
	for (int i=0; i< m_pArrArtMol->GetSize(); i++)
	{                                  
		CBufArtMol* pBufArtMol = (CBufArtMol *) m_pArrArtMol->GetAt(i);
//		ASSERT( pBufArtMol->IsKindOf( RUNTIME_CLASS( CBufArtMol ) ) );
		delete pBufArtMol;
	}
	delete m_pArrArtMol;	
}                              

double 
CBufArticulo::GetdChatarras()
{
	if (m_dPCAct) return m_dPCAct;
	if (m_dPCUlt) return m_dPCUlt;
	if (m_dPCHist) return m_dPCHist;
	if (m_dPCBase) return m_dPCBase;
	
	return m_iPorcChatarras;

}

double 
CBufArticulo::GetdCadencia()
{
	if (m_dPHAct) return m_dPHAct;
	if (m_dPHUlt) return m_dPHUlt;
	if (m_dPHHist) return m_dPHHist;
	if (m_dPHBase) return m_dPHBase;

	return m_lP_H_iny;
}	

long 
CBufArticulo::GetlCantMezcla()
{
	long lExist = 0;
	if ( m_pBufMezcla )
	{
		if ( m_pBufMezcla->m_lCantidad > 0 ) lExist +=  m_pBufMezcla->m_lCantidad ; 
		if ( m_pBufMezcla->m_lCantPlanta > 0 )	lExist +=  m_pBufMezcla->m_lCantPlanta ; 
	}

	return lExist;

}

/////////////////////////////////////////////////////////////////////////////
// CRsArtMol

IMPLEMENT_DYNAMIC(CRsArtMol, CRecordset)

CRsArtMol::CRsArtMol(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CRsArtMol)
	m_Cantidad = 0;
	m_IDArticulo = _T("");
	m_IDMolde = _T("");
	m_Orden = 0;
	m_Postizo = _T("");
	m_nFields = 5;
	//}}AFX_FIELD_INIT
	m_nDefaultType = snapshot;
}


CString CRsArtMol::GetDefaultConnect()
{
	return _T("ODBC;DSN=MS Access 97 Database");
}

CString CRsArtMol::GetDefaultSQL()
{
	return _T("[ArtMol]");
}

void CRsArtMol::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CRsArtMol)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Long(pFX, _T("[Cantidad]"), m_Cantidad);
	RFX_Text(pFX, _T("[IDArticulo]"), m_IDArticulo);
	RFX_Text(pFX, _T("[IDMolde]"), m_IDMolde);
	RFX_Long(pFX, _T("[Orden]"), m_Orden);
	RFX_Text(pFX, _T("[Postizo]"), m_Postizo);
	//}}AFX_FIELD_MAP
	m_IDArticulo.TrimRight();
	m_Postizo.TrimRight();
}

/////////////////////////////////////////////////////////////////////////////
// CRsArtMol diagnostics

#ifdef _DEBUG
void CRsArtMol::AssertValid() const
{
	CRecordset::AssertValid();
}

void CRsArtMol::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG


/////////////////////////////////////////////////////////////////////////////
// CBufArtMol

IMPLEMENT_DYNAMIC(CBufArtMol, CObject)

CBufArtMol::CBufArtMol(CRsArtMol& p_RsArtMol)
	: CObject()
{


	m_sIDArticulo = p_RsArtMol.m_IDArticulo;
	m_sIDArticulo.TrimRight();
	m_sIDMolde = p_RsArtMol.m_IDMolde;
	m_sIDMolde.TrimRight();
	if (p_RsArtMol.IsFieldNull(&p_RsArtMol.m_Cantidad)) m_lCantidad = 0;
	else m_lCantidad = p_RsArtMol.m_Cantidad;
	m_lOrden = p_RsArtMol.m_Orden;
	if (p_RsArtMol.IsFieldNull(&p_RsArtMol.m_Postizo)) m_sPostizo = "";
	else m_sPostizo = p_RsArtMol.m_Postizo;

	m_pBufArticulo = NULL;
	m_pBufMolde = NULL;
}


/////////////////////////////////////////////////////////////////////////////
// CRsCliente

IMPLEMENT_DYNAMIC(CRsCliente, CRecordset)

CRsCliente::CRsCliente(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CRsCliente)
	m_ID = _T("");
	m_Nombre = _T("");
	m_nFields = 2;
	//}}AFX_FIELD_INIT
	m_nDefaultType = snapshot;
}


CString CRsCliente::GetDefaultConnect()
{
	return _T("ODBC;DSN=MS Access 97 Database");
}

CString CRsCliente::GetDefaultSQL()
{
	return _T("[Clientes]");
}

void CRsCliente::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CRsCliente)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Text(pFX, _T("[ID]"), m_ID);
	RFX_Text(pFX, _T("[Nombre]"), m_Nombre);
	//}}AFX_FIELD_MAP
	m_ID.TrimRight();
	m_Nombre.TrimRight();
}

/////////////////////////////////////////////////////////////////////////////
// CRsCliente diagnostics

#ifdef _DEBUG
void CRsCliente::AssertValid() const
{
	CRecordset::AssertValid();
}

void CRsCliente::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
/////////////////////////////////////////////////////////////////////////////
// CRsEntregas

IMPLEMENT_DYNAMIC(CRsEntregas, CRecordset)

CRsEntregas::CRsEntregas(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CRsEntregas)
	m_IDMezcla = _T("");
	m_Orden = 0;
	m_Cantidad = 0;
	m_nFields = 4;
	//}}AFX_FIELD_INIT
	m_nDefaultType = snapshot;
}


CString CRsEntregas::GetDefaultConnect()
{
	return _T("ODBC;DSN=MS Access 97 Database");
}

CString CRsEntregas::GetDefaultSQL()
{
	return _T("[Entregas]");
}

void CRsEntregas::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CRsEntregas)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Text(pFX, _T("[IDMezcla]"), m_IDMezcla);
	RFX_Date(pFX, _T("[Fecha]"), m_Fecha);
	RFX_Long(pFX, _T("[Orden]"), m_Orden);
	RFX_Long(pFX, _T("[Cantidad]"), m_Cantidad);
	//}}AFX_FIELD_MAP
	m_IDMezcla.TrimRight();
}

/////////////////////////////////////////////////////////////////////////////
// CRsEntregas diagnostics

#ifdef _DEBUG
void CRsEntregas::AssertValid() const
{
	CRecordset::AssertValid();
}

void CRsEntregas::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG



/////////////////////////////////////////////////////////////////////////////
// CBufEntregas

IMPLEMENT_DYNAMIC(CBufEntregas, CObject)

CBufEntregas::CBufEntregas(CRsEntregas& p_RsEntregas)
	: CObject()
{

	m_sIDMezcla = p_RsEntregas.m_IDMezcla;
	m_lOrden = p_RsEntregas.m_Orden;
	m_Fecha = p_RsEntregas.m_Fecha;
	m_lCantidad = p_RsEntregas.m_Cantidad;
	
}





/////////////////////////////////////////////////////////////////////////////
// CRsHistorico

IMPLEMENT_DYNAMIC(CRsHistorico, CRecordset)

CRsHistorico::CRsHistorico(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CRsHistorico)
	m_IDMolde = _T("");
	m_IDMaquina = _T("");
	m_Cantidad = 0;
	m_IDArticulo = _T("");
	m_Cadencia = 0.0;
	m_Rechazos = 0.0;
	m_nFields = 8;
	//}}AFX_FIELD_INIT
	m_nDefaultType = snapshot;
}


CString CRsHistorico::GetDefaultConnect()
{
	return _T("ODBC;DSN=MS Access 97 Database");
}

CString CRsHistorico::GetDefaultSQL()
{
	return _T("[Historico]");
}

void CRsHistorico::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CRsHistorico)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Text(pFX, _T("[IDMolde]"), m_IDMolde);
	RFX_Text(pFX, _T("[IDMaquina]"), m_IDMaquina);
	RFX_Date(pFX, _T("[FecIni]"), m_FecIni);
	RFX_Date(pFX, _T("[FecFin]"), m_FecFin);
	RFX_Long(pFX, _T("[Cantidad]"), m_Cantidad);
	RFX_Text(pFX, _T("[IDArticulo]"), m_IDArticulo);
	RFX_Double(pFX, _T("[Cadencia]"), m_Cadencia);
	RFX_Double(pFX, _T("[Rechazos]"), m_Rechazos);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CRsHistorico diagnostics

#ifdef _DEBUG
void CRsHistorico::AssertValid() const
{
	CRecordset::AssertValid();
}

void CRsHistorico::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
/////////////////////////////////////////////////////////////////////////////
// CRsLocales

IMPLEMENT_DYNAMIC(CRsLocales, CRecordset)

CRsLocales::CRsLocales(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CRsLocales)
	m_ID = _T("");
	m_Nombre = _T("");
	m_nFields = 2;
	//}}AFX_FIELD_INIT
	m_nDefaultType = snapshot;
}


CString CRsLocales::GetDefaultConnect()
{
	return _T("ODBC;DSN=MS Access 97 Database");
}

CString CRsLocales::GetDefaultSQL()
{
	return _T("[Locales]");
}

void CRsLocales::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CRsLocales)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Text(pFX, _T("[ID]"), m_ID);
	RFX_Text(pFX, _T("[Nombre]"), m_Nombre);
	//}}AFX_FIELD_MAP
	m_ID.TrimRight();
	m_Nombre.TrimRight();
}

/////////////////////////////////////////////////////////////////////////////
// CRsLocales diagnostics

#ifdef _DEBUG
void CRsLocales::AssertValid() const
{
	CRecordset::AssertValid();
}

void CRsLocales::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
/////////////////////////////////////////////////////////////////////////////
// CRsMaquinas

IMPLEMENT_DYNAMIC(CRsMaquinas, CRecordset)

CRsMaquinas::CRsMaquinas(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CRsMaquinas)
	m_ID = _T("");
	m_Tipo = _T("");
	m_Nombre = _T("");
	m_IDLocal = _T("");
	m_Inact = 0;
	m_nFields = 5;
	//}}AFX_FIELD_INIT
	m_nDefaultType = snapshot;
}


CString CRsMaquinas::GetDefaultConnect()
{
	return _T("ODBC;DSN=MS Access 97 Database");
}

CString CRsMaquinas::GetDefaultSQL()
{
	return _T("[Maquinas]");
}

void CRsMaquinas::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CRsMaquinas)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Text(pFX, _T("[ID]"), m_ID);
	RFX_Text(pFX, _T("[Tipo]"), m_Tipo);
	RFX_Text(pFX, _T("[Nombre]"), m_Nombre);
	RFX_Text(pFX, _T("[IDLocal]"), m_IDLocal);
	RFX_Long(pFX, _T("[Inact]"), m_Inact);
	//}}AFX_FIELD_MAP
	m_ID.TrimRight();
	m_Tipo.TrimRight();
	m_Nombre.TrimRight();
	m_IDLocal.TrimRight();
}

/////////////////////////////////////////////////////////////////////////////
// CRsMaquinas diagnostics

#ifdef _DEBUG
void CRsMaquinas::AssertValid() const
{
	CRecordset::AssertValid();
}

void CRsMaquinas::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG


/////////////////////////////////////////////////////////////////////////////
// CBufMaquina

IMPLEMENT_DYNAMIC(CBufMaquina, CObject)

CBufMaquina::CBufMaquina(CRsMaquinas& p_RsMaquinas)
	: CObject()
{
	AssignData(p_RsMaquinas);

}
                               
CBufMaquina::AssignData(CRsMaquinas& p_RsMaquinas)
{
	// TODO
	// Pensar en los posibles problemas de los valores nulos
	m_sID = p_RsMaquinas.m_ID;
	m_sID.TrimRight();
	m_sTipo = p_RsMaquinas.m_Tipo;
	m_sTipo.TrimRight();
	m_sNombre = p_RsMaquinas.m_Nombre;
	m_sNombre.TrimRight();
	m_sIDLocal = p_RsMaquinas.m_IDLocal;
	m_sIDLocal.TrimRight();
	m_lInact = p_RsMaquinas.m_Inact;
	
}

CBufMaquina::CBufMaquina()
	: CObject()
{
	m_sID = "";
	m_sTipo = "";
	m_sNombre = "";
	m_sIDLocal = "";
	m_lInact = 0;
}

CBufMaquina::~CBufMaquina()
{
}                              

/////////////////////////////////////////////////////////////////////////////
// CRsMezclas

IMPLEMENT_DYNAMIC(CRsMezclas, CRecordset)

CRsMezclas::CRsMezclas(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CRsMezclas)
	m_ID = _T("");
	m_Color = _T("");
	m_Cantidad = 0;
	m_Lote = 0;
	m_nFields = 4;
	//}}AFX_FIELD_INIT
	m_nDefaultType = snapshot;
}


CString CRsMezclas::GetDefaultConnect()
{
	return _T("ODBC;DSN=MS Access 97 Database");
}

CString CRsMezclas::GetDefaultSQL()
{
	return _T("[Mezclas]");
}

void CRsMezclas::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CRsMezclas)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Text(pFX, _T("[ID]"), m_ID);
	RFX_Text(pFX, _T("[Color]"), m_Color);
	RFX_Long(pFX, _T("[Cantidad]"), m_Cantidad);
	RFX_Long(pFX, _T("[Lote]"), m_Lote);
	//}}AFX_FIELD_MAP
	m_ID.TrimRight();
	m_Color.TrimRight();
}

/////////////////////////////////////////////////////////////////////////////
// CRsMezclas diagnostics

#ifdef _DEBUG
void CRsMezclas::AssertValid() const
{
	CRecordset::AssertValid();
}

void CRsMezclas::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG


/////////////////////////////////////////////////////////////////////////////
// CBufMezcla

IMPLEMENT_DYNAMIC(CBufMezcla, CObject)

CBufMezcla::CBufMezcla(CRsMezclas& p_RsMezclas)
	: CObject()
{
	AssignData(p_RsMezclas);

	m_pArrEntregas = new CObArray();
}
                               
CBufMezcla::AssignData(CRsMezclas& p_RsMezclas)
{
	// TODO
	// Pensar en los posibles problemas de los valores nulos
	m_sID = p_RsMezclas.m_ID ;
	m_sColor = p_RsMezclas.m_Color ;
	m_lCantidad = p_RsMezclas.m_Cantidad ;
	m_lCantPlanta = 0;
	m_lLote = p_RsMezclas.m_Lote;
}

CBufMezcla::CBufMezcla()
	: CObject()
{
	m_pArrEntregas = new CObArray();
}

CBufMezcla::~CBufMezcla()
{
	ASSERT_VALID (m_pArrEntregas);
	for (int i=0; i< m_pArrEntregas->GetSize(); i++)
	{                                  
		CBufEntregas* pBufEntregas = (CBufEntregas *) m_pArrEntregas->GetAt(i);
		ASSERT( pBufEntregas->IsKindOf( RUNTIME_CLASS( CBufEntregas ) ) );
		delete pBufEntregas;
	}
	delete m_pArrEntregas;	
}                              



/////////////////////////////////////////////////////////////////////////////
// CRsMoldes

IMPLEMENT_DYNAMIC(CRsMoldes, CRecordset)

CRsMoldes::CRsMoldes(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CRsMoldes)
	m_ID = _T("");
	m_Alternancia = _T("");
	m_Tipo = _T("");
	m_Tiradas = 0;
	m_Estado = _T("");
	m_nFields = 6;
	//}}AFX_FIELD_INIT
	m_nDefaultType = snapshot;
}


CString CRsMoldes::GetDefaultConnect()
{
	return _T("ODBC;DSN=MS Access 97 Database");
}

CString CRsMoldes::GetDefaultSQL()
{
	return _T("[Moldes]");
}

void CRsMoldes::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CRsMoldes)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Text(pFX, _T("[ID]"), m_ID);
	RFX_Text(pFX, _T("[Alternancia]"), m_Alternancia);
	RFX_Text(pFX, _T("[Tipo]"), m_Tipo);
	RFX_Long(pFX, _T("[Tiradas]"), m_Tiradas);
	RFX_Text(pFX, _T("[Estado]"), m_Estado);
	RFX_Date(pFX, _T("[Disponibilidad]"), m_Disponibilidad);
	//}}AFX_FIELD_MAP
	m_ID.TrimRight();
	m_Alternancia.TrimRight();
	m_Tipo.TrimRight();
	m_Estado.TrimRight();
}

/////////////////////////////////////////////////////////////////////////////
// CRsMoldes diagnostics

#ifdef _DEBUG
void CRsMoldes::AssertValid() const
{
	CRecordset::AssertValid();
}

void CRsMoldes::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CBufMolde

IMPLEMENT_DYNAMIC(CBufMolde, CObject)

CBufMolde::CBufMolde(CRsMoldes& p_RsMoldes)
	: CObject()
{
	AssignData(p_RsMoldes);

	m_pArrMolArt = new CObArray();
	m_pArrMolMaq = new CObArray();
}
                               
CBufMolde::AssignData(CRsMoldes& p_RsMoldes)
{
	// TODO
	// Pensar en los posibles problemas de los valores nulos
	m_sID = p_RsMoldes.m_ID;
	m_sID.TrimRight();
	m_sAlternancia = p_RsMoldes.m_Alternancia;
	m_sAlternancia.TrimRight();
	m_sTipo = p_RsMoldes.m_Tipo;
	m_sTipo.TrimRight();
	m_lTiradas = p_RsMoldes.m_Tiradas;
	m_sEstado = p_RsMoldes.m_Estado;
	m_sEstado.TrimRight();
	m_FecDisponibilidad = p_RsMoldes.m_Disponibilidad;
	
}

CBufMolde::CBufMolde()
	: CObject()
{
	m_pArrMolArt = new CObArray();
	m_pArrMolMaq = new CObArray();
}

CBufMolde::~CBufMolde()
{
	ASSERT_VALID (m_pArrMolArt);
	int i;
	for ( i=0; i< m_pArrMolArt->GetSize(); i++)
	{                                  
		CBufArtMol* pBufArtMol = (CBufArtMol *) m_pArrMolArt->GetAt(i);
		ASSERT( pBufArtMol->IsKindOf( RUNTIME_CLASS( CBufArtMol ) ) );
		delete pBufArtMol;
	}
	delete m_pArrMolArt;	

	ASSERT_VALID (m_pArrMolMaq);
	for ( i=0; i< m_pArrMolMaq->GetSize(); i++)
	{                                  
		CBufMolMaq* pBufMolMaq = (CBufMolMaq *) m_pArrMolMaq->GetAt(i);
		ASSERT( pBufMolMaq->IsKindOf( RUNTIME_CLASS( CBufMolMaq ) ) );
		delete pBufMolMaq;
	}
	delete m_pArrMolMaq;	
}                              


/////////////////////////////////////////////////////////////////////////////
// CRsMolMaq

IMPLEMENT_DYNAMIC(CRsMolMaq, CRecordset)

CRsMolMaq::CRsMolMaq(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CRsMolMaq)
	m_IDMolde = _T("");
	m_Prioridad = 0;
	m_IDMaquina = _T("");
	m_nFields = 3;
	//}}AFX_FIELD_INIT
	m_nDefaultType = snapshot;
}


CString CRsMolMaq::GetDefaultConnect()
{
	return _T("ODBC;DSN=MS Access 97 Database");
}

CString CRsMolMaq::GetDefaultSQL()
{
	return _T("[MolMaq]");
}

void CRsMolMaq::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CRsMolMaq)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Text(pFX, _T("[IDMolde]"), m_IDMolde);
	RFX_Long(pFX, _T("[Prioridad]"), m_Prioridad);
	RFX_Text(pFX, _T("[IDMaquina]"), m_IDMaquina);
	//}}AFX_FIELD_MAP
	m_IDMolde.TrimRight();
	m_IDMaquina.TrimRight();
}

/////////////////////////////////////////////////////////////////////////////
// CRsMolMaq diagnostics

#ifdef _DEBUG
void CRsMolMaq::AssertValid() const
{
	CRecordset::AssertValid();
}

void CRsMolMaq::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG


/////////////////////////////////////////////////////////////////////////////
// CBufArtMol

IMPLEMENT_DYNAMIC(CBufMolMaq, CObject)

CBufMolMaq::CBufMolMaq(CRsMolMaq& p_RsMolMaq)
	: CObject()
{
	m_sIDMolde = p_RsMolMaq.m_IDMolde;
	m_sIDMolde.TrimRight();
	m_lPrioridad = p_RsMolMaq.m_Prioridad;
	m_sIDMaquina = p_RsMolMaq.m_IDMaquina;
	m_sIDMaquina.TrimRight();
}


/////////////////////////////////////////////////////////////////////////////
// CRsPedidos

IMPLEMENT_DYNAMIC(CRsPedidos, CRecordset)

CRsPedidos::CRsPedidos(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CRsPedidos)
	m_CantAlmac = 0.0;
	m_CantCurso = 0.0;
	m_CantOrig = 0.0;
	m_CantPauta = 0.0;
	m_CantPend = 0.0;
	m_IDArticulo = _T("");
	m_IDCliente = 0;
	m_Necesidad = _T("");
	m_Nomcli = _T("");
	m_Seccion = 0;
	m_CantObsoletos = 0.0;
	m_CantStockSeguridad = 0.0;
	m_nFields = 13;
	//}}AFX_FIELD_INIT
	m_nDefaultType = snapshot;
}


CString CRsPedidos::GetDefaultConnect()
{
	return _T("ODBC;DSN=MS Access 97 Database");
}

CString CRsPedidos::GetDefaultSQL()
{
	return _T("[Pedidos]");
}

void CRsPedidos::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CRsPedidos)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Double(pFX, _T("[CantAlmac]"), m_CantAlmac);
	RFX_Double(pFX, _T("[CantCurso]"), m_CantCurso);
	RFX_Double(pFX, _T("[CantOrig]"), m_CantOrig);
	RFX_Double(pFX, _T("[CantPauta]"), m_CantPauta);
	RFX_Double(pFX, _T("[CantPend]"), m_CantPend);
	RFX_Date(pFX, _T("[FecNec]"), m_FecNec);
	RFX_Text(pFX, _T("[IDArticulo]"), m_IDArticulo);
	RFX_Long(pFX, _T("[IDCliente]"), m_IDCliente);
	RFX_Text(pFX, _T("[Necesidad]"), m_Necesidad);
	RFX_Text(pFX, _T("[Nomcli]"), m_Nomcli);
	RFX_Long(pFX, _T("[Seccion]"), m_Seccion);
	RFX_Double(pFX, _T("[CantObsoletos]"), m_CantObsoletos);
	RFX_Double(pFX, _T("[CantStockSeguridad]"), m_CantStockSeguridad);
	//}}AFX_FIELD_MAP
	m_IDArticulo.TrimRight();
	m_Necesidad.TrimRight();
	m_Nomcli.TrimRight();

}

/////////////////////////////////////////////////////////////////////////////
// CRsPedidos diagnostics

#ifdef _DEBUG
void CRsPedidos::AssertValid() const
{
	CRecordset::AssertValid();
}

void CRsPedidos::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CBufOF

IMPLEMENT_DYNAMIC(CBufOF, CObject)

CBufOF::CBufOF(CRsPedidos& p_RsPedidos)
	: CObject()
{
	AssignData(p_RsPedidos);

}
                               
CBufOF::AssignData(CRsPedidos& p_RsPedidos)
{
	// TODO
	// Pensar en los posibles problemas de los valores nulos

	if (p_RsPedidos.IsFieldNull(&p_RsPedidos.m_CantAlmac)) m_dCantAlmac = 0;
	else m_dCantAlmac = p_RsPedidos.m_CantAlmac;
	if (p_RsPedidos.IsFieldNull(&p_RsPedidos.m_CantCurso)) m_dCantCurso = 0;
	else m_dCantCurso = p_RsPedidos.m_CantCurso;
	if (p_RsPedidos.IsFieldNull(&p_RsPedidos.m_CantOrig)) m_dCantOrig = 0;
	else m_dCantOrig = p_RsPedidos.m_CantOrig;
	if (p_RsPedidos.IsFieldNull(&p_RsPedidos.m_CantPauta)) m_dCantPauta = 0;
	else m_dCantPauta = p_RsPedidos.m_CantPauta;
	if (p_RsPedidos.IsFieldNull(&p_RsPedidos.m_CantPend)) m_dCantPend = 0;
	else m_dCantPend = p_RsPedidos.m_CantPend;
	if (p_RsPedidos.IsFieldNull(&p_RsPedidos.m_CantObsoletos)) m_dCantObsoletos = 0;
	else m_dCantObsoletos = p_RsPedidos.m_CantObsoletos;
	if (p_RsPedidos.IsFieldNull(&p_RsPedidos.m_CantStockSeguridad)) m_dCantStockSeguridad = 0;
	else m_dCantStockSeguridad = p_RsPedidos.m_CantStockSeguridad;
	m_FecNec = p_RsPedidos.m_FecNec;
	m_sIDArticulo = p_RsPedidos.m_IDArticulo;
	m_sIDArticulo.TrimRight();
	m_lIDCliente = p_RsPedidos.m_IDCliente;
	m_sNecesidad = p_RsPedidos.m_Necesidad;
	m_sNecesidad.TrimRight();
	m_sNomcli = p_RsPedidos.m_Nomcli;
	m_sNomcli.TrimRight();
	m_bSelected = FALSE;
	m_bComprimido = FALSE;
	m_lSeccion = p_RsPedidos.m_Seccion;
	m_lMargenMed = m_lMargenMin = m_lMargenMax = 0;
	m_FecFab = m_FecNec;
}

CBufOF::CBufOF(CRsPedidosAyer& p_RsPedidosAyer)
	: CObject()
{
	if (p_RsPedidosAyer.IsFieldNull(&p_RsPedidosAyer.m_CantAlmac)) m_dCantAlmac = 0;
	else m_dCantAlmac = p_RsPedidosAyer.m_CantAlmac;
	if (p_RsPedidosAyer.IsFieldNull(&p_RsPedidosAyer.m_CantCurso)) m_dCantCurso = 0;
	else m_dCantCurso = p_RsPedidosAyer.m_CantCurso;
	if (p_RsPedidosAyer.IsFieldNull(&p_RsPedidosAyer.m_CantOrig)) m_dCantOrig = 0;
	else m_dCantOrig = p_RsPedidosAyer.m_CantOrig;
	if (p_RsPedidosAyer.IsFieldNull(&p_RsPedidosAyer.m_CantPauta)) m_dCantPauta = 0;
	else m_dCantPauta = p_RsPedidosAyer.m_CantPauta;
	if (p_RsPedidosAyer.IsFieldNull(&p_RsPedidosAyer.m_CantPend)) m_dCantPend = 0;
	else m_dCantPend = p_RsPedidosAyer.m_CantPend;
	if (p_RsPedidosAyer.IsFieldNull(&p_RsPedidosAyer.m_CantObsoletos)) m_dCantObsoletos = 0;
	else m_dCantObsoletos = p_RsPedidosAyer.m_CantObsoletos;
	if (p_RsPedidosAyer.IsFieldNull(&p_RsPedidosAyer.m_CantStockSeguridad)) m_dCantStockSeguridad = 0;
	else m_dCantStockSeguridad = p_RsPedidosAyer.m_CantStockSeguridad;
	m_FecNec = p_RsPedidosAyer.m_FecNec;
	m_sIDArticulo = p_RsPedidosAyer.m_IDArticulo;
	m_sIDArticulo.TrimRight();
	m_lIDCliente = p_RsPedidosAyer.m_IDCliente;
	m_sNecesidad = p_RsPedidosAyer.m_Necesidad;
	m_sNecesidad.TrimRight();
	m_sNomcli = p_RsPedidosAyer.m_Nomcli;
	m_sNomcli.TrimRight();
	m_bComprimido = FALSE;
	m_bSelected = FALSE;
	m_lSeccion = p_RsPedidosAyer.m_Seccion;

}

CBufOF::CBufOF()
	: CObject()
{
}


// Definiciones de estructuras

IMPLEMENT_DYNAMIC(COMComb, CObject)

COMComb::COMComb( COrdMaq* p_OM)
	: CObject()
{
	if (p_OM == NULL) return;
	m_AbSpan.SetFecIni(p_OM->GetFecIni());
	m_AbSpan.SetFecFin(p_OM->GetFecFin());
	m_dCadencia = p_OM->GetdCadencia();
}

COMComb& 
COMComb::operator =(const COMComb& p_OMC)
{
	m_AbSpan.SetFecIni(p_OMC.m_AbSpan.GetFecIni());
	m_AbSpan.SetFecFin(p_OMC.m_AbSpan.GetFecFin());
	m_dCadencia = p_OMC.m_dCadencia;
	return *this;
}

long
COMComb::GetlCantFab()
{
	long lSecs =  (long) (m_AbSpan.GetSecs() / ( 1.0 + ( TK_INACT_DEF / 100.0 )));
	return (long) (lSecs * m_dCadencia / (double) TK_SEGS_HORA ) + 1;
}


COMComb::COMComb( COMComb& p_OMC)
	: CObject()
{
	m_AbSpan.SetFecIni(p_OMC.m_AbSpan.GetFecIni());
	m_AbSpan.SetFecFin(p_OMC.m_AbSpan.GetFecFin());
	m_dCadencia = p_OMC.m_dCadencia ;
}				


// Definiciones de estructuras

IMPLEMENT_DYNAMIC(CInfoMolArt, CObject)

CInfoMolArt::CInfoMolArt()
	: CObject()
{
	m_lPrioridad = 0;
	m_sIDArticulo = "";
	m_lPorcHist = 0;

}


/////////////////////////////////////////////////////////////////////////////
// CRsListadoValorado

IMPLEMENT_DYNAMIC(CRsListadoValorado, CRecordset)

CRsListadoValorado::CRsListadoValorado(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CRsListadoValorado)
	m_Articulo = _T("");
	m_Cliente = _T("");
	m_P_H_real = 0.0;
	m__Rechazos = 0.0;
	m_Cantidad_Fabricada = 0;
	m_Cantidad_Rechazada = 0;
	m_Total_Horas = 0;
	m_nFields = 7;
	//}}AFX_FIELD_INIT
	m_nDefaultType = snapshot;
}


CString CRsListadoValorado::GetDefaultConnect()
{
	return _T("ODBC;DSN=MS Access 97 Database");
}

CString CRsListadoValorado::GetDefaultSQL()
{
	return _T("[ListadoValorado]");
}

void CRsListadoValorado::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CRsListadoValorado)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Text(pFX, _T("[Articulo]"), m_Articulo);
	RFX_Text(pFX, _T("[Cliente]"), m_Cliente);
	RFX_Double(pFX, _T("[P/H real]"), m_P_H_real);
	RFX_Double(pFX, _T("[%Rechazos]"), m__Rechazos);
	RFX_Long(pFX, _T("[Cantidad Fabricada]"), m_Cantidad_Fabricada);
	RFX_Long(pFX, _T("[Cantidad Rechazada]"), m_Cantidad_Rechazada);
	RFX_Long(pFX, _T("[Total Horas]"), m_Total_Horas);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CRsListadoValorado diagnostics

#ifdef _DEBUG
void CRsListadoValorado::AssertValid() const
{
	CRecordset::AssertValid();
}

void CRsListadoValorado::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
/////////////////////////////////////////////////////////////////////////////
// CRsPedidosAyer

IMPLEMENT_DYNAMIC(CRsPedidosAyer, CRecordset)

CRsPedidosAyer::CRsPedidosAyer(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CRsPedidosAyer)
	m_IDArticulo = _T("");
	m_IDCliente = 0;
	m_Nomcli = _T("");
	m_Necesidad = _T("");
	m_CantOrig = 0.0;
	m_CantPend = 0.0;
	m_CantAlmac = 0.0;
	m_CantCurso = 0.0;
	m_CantPauta = 0.0;
	m_Seccion = 0;
	m_CantObsoletos = 0.0;
	m_CantStockSeguridad = 0.0;
	m_nFields = 13;
	//}}AFX_FIELD_INIT
	m_nDefaultType = snapshot;
}


CString CRsPedidosAyer::GetDefaultConnect()
{
	return _T("ODBC;DSN=MS Access 97 Database");
}

CString CRsPedidosAyer::GetDefaultSQL()
{
	return _T("[Pedidos_Ayer]");
}

void CRsPedidosAyer::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CRsPedidosAyer)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Text(pFX, _T("[IDArticulo]"), m_IDArticulo);
	RFX_Long(pFX, _T("[IDCliente]"), m_IDCliente);
	RFX_Text(pFX, _T("[Nomcli]"), m_Nomcli);
	RFX_Text(pFX, _T("[Necesidad]"), m_Necesidad);
	RFX_Double(pFX, _T("[CantOrig]"), m_CantOrig);
	RFX_Double(pFX, _T("[CantPend]"), m_CantPend);
	RFX_Date(pFX, _T("[FecNec]"), m_FecNec);
	RFX_Double(pFX, _T("[CantAlmac]"), m_CantAlmac);
	RFX_Double(pFX, _T("[CantCurso]"), m_CantCurso);
	RFX_Double(pFX, _T("[CantPauta]"), m_CantPauta);
	RFX_Long(pFX, _T("[Seccion]"), m_Seccion);
	RFX_Double(pFX, _T("[CantObsoletos]"), m_CantObsoletos);
	RFX_Double(pFX, _T("[CantStockSeguridad]"), m_CantStockSeguridad);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CRsPedidosAyer diagnostics

#ifdef _DEBUG
void CRsPedidosAyer::AssertValid() const
{
	CRecordset::AssertValid();
}

void CRsPedidosAyer::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
/////////////////////////////////////////////////////////////////////////////
// CRsCambiosMoldes

IMPLEMENT_DYNAMIC(CRsCambiosMoldes, CRecordset)

CRsCambiosMoldes::CRsCambiosMoldes(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CRsCambiosMoldes)
	m_Contador = 0;
	m_IDMaquina = _T("");
	m_IDMoldeEnt = _T("");
	m_IDMoldeSal = _T("");
	m_nFields = 4;
	//}}AFX_FIELD_INIT
	m_nDefaultType = snapshot;
}


CString CRsCambiosMoldes::GetDefaultConnect()
{
	return _T("ODBC;DSN=MS Access 97 Database");
}

CString CRsCambiosMoldes::GetDefaultSQL()
{
	return _T("[CambiosMoldes]");
}

void CRsCambiosMoldes::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CRsCambiosMoldes)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Long(pFX, _T("[Contador]"), m_Contador);
	RFX_Text(pFX, _T("[IDMaquina]"), m_IDMaquina);
	RFX_Text(pFX, _T("[IDMoldeEnt]"), m_IDMoldeEnt);
	RFX_Text(pFX, _T("[IDMoldeSal]"), m_IDMoldeSal);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CRsCambiosMoldes diagnostics

#ifdef _DEBUG
void CRsCambiosMoldes::AssertValid() const
{
	CRecordset::AssertValid();
}

void CRsCambiosMoldes::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG

IMPLEMENT_DYNAMIC(CBufCambiosMoldes, CObject)

CBufCambiosMoldes::CBufCambiosMoldes(CRsCambiosMoldes& p_RsCambiosMoldes)
	: CObject()
{
//	m_Fecha = p_RsCambiosMoldes.m_Fecha;
	m_sIDMaquina = p_RsCambiosMoldes.m_IDMaquina;
	m_sIDMaquina.TrimRight();
	m_sIDMoldeEnt = p_RsCambiosMoldes.m_IDMoldeEnt;
	m_sIDMoldeEnt.TrimRight();
	m_sIDMoldeSal = p_RsCambiosMoldes.m_IDMoldeSal;
	m_sIDMoldeSal.TrimRight();
	
}

CBufCambiosMoldes::CBufCambiosMoldes()
	: CObject()
{
}

/////////////////////////////////////////////////////////////////////////////
// CRsMezclasPlanta

IMPLEMENT_DYNAMIC(CRsMezclasPlanta, CRecordset)

CRsMezclasPlanta::CRsMezclasPlanta(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CRsMezclasPlanta)
	m_ID = _T("");
	m_Cantidad = 0;
	m_nFields = 2;
	//}}AFX_FIELD_INIT
	m_nDefaultType = snapshot;
}


CString CRsMezclasPlanta::GetDefaultConnect()
{
	return _T("ODBC;DSN=MS Access 97 Database");
}

CString CRsMezclasPlanta::GetDefaultSQL()
{
	return _T("[Mezclas_Planta]");
}

void CRsMezclasPlanta::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CRsMezclasPlanta)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Text(pFX, _T("[ID]"), m_ID);
	RFX_Long(pFX, _T("[Cantidad]"), m_Cantidad);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CRsMezclasPlanta diagnostics

#ifdef _DEBUG
void CRsMezclasPlanta::AssertValid() const
{
	CRecordset::AssertValid();
}

void CRsMezclasPlanta::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
/////////////////////////////////////////////////////////////////////////////
// CRsLisMezclas

IMPLEMENT_DYNAMIC(CRsLisMezclas, CRecordset)

CRsLisMezclas::CRsLisMezclas(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CRsLisMezclas)
	m_Cant = 0;
	m_IDArticulo = _T("");
	m_IDCliente = _T("");
	m_IDLocal = _T("");
	m_Mezcla = 0;
	m_nFields = 6;
	//}}AFX_FIELD_INIT
	m_nDefaultType = snapshot;
}


CString CRsLisMezclas::GetDefaultConnect()
{
	return _T("ODBC;DSN=MS Access 97 Database");
}

CString CRsLisMezclas::GetDefaultSQL()
{
	return _T("[Lis_Mezclas]");
}

void CRsLisMezclas::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CRsLisMezclas)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Long(pFX, _T("[Cant]"), m_Cant);
	RFX_Date(pFX, _T("[FecIni]"), m_FecIni);
	RFX_Text(pFX, _T("[IDArticulo]"), m_IDArticulo);
	RFX_Text(pFX, _T("[IDCliente]"), m_IDCliente);
	RFX_Text(pFX, _T("[IDLocal]"), m_IDLocal);
	RFX_Long(pFX, _T("[Mezcla]"), m_Mezcla);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CRsLisMezclas diagnostics

#ifdef _DEBUG
void CRsLisMezclas::AssertValid() const
{
	CRecordset::AssertValid();
}

void CRsLisMezclas::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG


IMPLEMENT_DYNAMIC(CBufLisMezclas, CObject)

CBufLisMezclas::CBufLisMezclas(CRsLisMezclas& p_RsLisMezclas)
	: CObject()
{
	m_sIDLocal = p_RsLisMezclas.m_IDLocal ;
	m_sIDCliente = p_RsLisMezclas.m_IDCliente ;
	m_sIDArticulo = p_RsLisMezclas.m_IDArticulo ;
	m_lMezcla = p_RsLisMezclas.m_Mezcla ;
	m_lCant = p_RsLisMezclas.m_Cant ;
	m_FecIni = p_RsLisMezclas.m_FecIni;
	
}

CBufLisMezclas::CBufLisMezclas()
	: CObject()
{
}
/////////////////////////////////////////////////////////////////////////////
// CRsCalendario

IMPLEMENT_DYNAMIC(CRsCalendario, CRecordset)

CRsCalendario::CRsCalendario(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CRsCalendario)
	m_ID = _T("");
	m_Turno1 = FALSE;
	m_Turno2 = FALSE;
	m_Turno3 = FALSE;
	m_nFields = 5;
	//}}AFX_FIELD_INIT
	m_nDefaultType = snapshot;
}


CString CRsCalendario::GetDefaultConnect()
{
	return _T("ODBC;DSN=MS Access 97 Database");
}

CString CRsCalendario::GetDefaultSQL()
{
	return _T("[Calendario]");
}

void CRsCalendario::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CRsCalendario)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Text(pFX, _T("[ID]"), m_ID);
	RFX_Date(pFX, _T("[Fecha]"), m_Fecha);
	RFX_Bool(pFX, _T("[Turno1]"), m_Turno1);
	RFX_Bool(pFX, _T("[Turno2]"), m_Turno2);
	RFX_Bool(pFX, _T("[Turno3]"), m_Turno3);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CRsCalendario diagnostics

#ifdef _DEBUG
void CRsCalendario::AssertValid() const
{
	CRecordset::AssertValid();
}

void CRsCalendario::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
