#if !defined(AFX_DLGOPCIONES_H__C8416428_BD48_11D3_8997_EA7DAEEB0A33__INCLUDED_)
#define AFX_DLGOPCIONES_H__C8416428_BD48_11D3_8997_EA7DAEEB0A33__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgOpciones.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgOpciones dialog

class CDlgOpciones : public CDialog
{
// Construction
public:
	CDlgOpciones(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlgOpciones)
	enum { IDD = IDD_OPCIONES };
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgOpciones)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgOpciones)
	afx_msg void OnColor0();
	afx_msg void OnColor1();
	afx_msg void OnColor2();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGOPCIONES_H__C8416428_BD48_11D3_8997_EA7DAEEB0A33__INCLUDED_)
