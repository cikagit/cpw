// cpwCarDes.cpp : part of implementation of the CCpwView class, Carga y Descarga
// de los formatos antiguos.
//

#include "stdafx.h"
#include "afxdtctl.h"
#include "cpw.h"
#include "cpwDefs.h"

#include "AbSpan.h"
#include "prog.h"

#include "cpwDoc.h"

#include "cpwView.h"

#include "cpwDb.h"
#include "cache.h"            
#include "ProgMaq.h"
#include "OrdMaq.h"
#include "Dialogs.h" 
#include "OrdenDlg.h"  

#include "strstrea.h"
#include "fstream.h"
#include "cpwExt.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

void CCpwDoc::CargarPrograma(const char* p_sPathName) 
{
// Esta funcion carga un programa del formato antiguo
// Funciona sobre un programa vac�o, as� que primero comprobamos que lo est�.
	CProg* pProg = GetpProg();
	ASSERT_VALID(pProg);

	ifstream ifs;
	char buffer[1024];
	CString sItem;
	CTime Fec;
	long lNum;
	int iNum;

	ifs.open( p_sPathName, ios::in | ios::nocreate );
	if (ifs.fail())
	{
		CString sMsg = STRID( IDS_ERR_NOOPENFILE );
		sMsg +=(CString) p_sPathName;
		AfxMessageBox(sMsg);
	}
	
	// Leemos la fecha de comienzo y de fin de la programacion

	ifs >> buffer;
	sItem = buffer;
	ifs >> buffer;
	
	Fec = FecBCWConvert(sItem, buffer);
	pProg->SetFecIni(Fec);

	ifs >> buffer;
	sItem = buffer;
	ifs >> buffer;
	
	Fec = FecBCWConvert(sItem, buffer);
	pProg->SetFecFin(Fec);

	ifs >> buffer;
	iNum = atoi(buffer);
	if (iNum > 0) pProg->SetTimeScale(iNum);

	// Leemos las OFs
	ifs >> buffer;
	int iNumOFs = atoi(buffer);
	for ( int i = 0; i < iNumOFs; i++)
	{
		//CBufOF* pBufOF = new CBufOF;
		ifs >> buffer;
		//pBufOF->m_IDBloque = atoi(buffer);
		ifs >> buffer;
		//pBufOF->m_ID = atoi(buffer);
		ifs >> buffer;		
		//pBufOF->m_IDArticulo = buffer;
		
		ifs >> buffer;
		//pBufOF->m_OrdFab = atoi(buffer);
		ifs >> buffer;
		//pBufOF->m_Cantidad = atoi(buffer);
		
		ifs >> buffer;
		sItem = buffer;
		ifs >> buffer;
	
		//pBufOF->m_FecEnt = FecBCWConvert(sItem, buffer);
		
		ifs >> buffer;
		//pBufOF->m_MaxPerson = atof(buffer);
		// g_pCache->AddOF( pBufOF );
	
	}
	// Ahora comenzamos con el ciclo de m�quinas/ordenes
	// Borramos las m�quinas
	pProg->ClearPMs();
	//Vemos cu�ntas tenemos
	ifs >> buffer;
	int iNumPM = atoi(buffer);
	for ( i = 0; i < iNumPM; i++)
	{
		ifs >> buffer;
		CProgMaq* pPM = new CProgMaq(buffer);
	
		pPM->SetpBufMaq( g_pCache->AddMaquina( buffer ) );  
	
		pProg->AddPM (pPM);
		
		ifs >> buffer;
		int iNumOMs = atoi(buffer);

		ifs >> buffer;	// Despreciamos este valor, es siempre 0
		ifs >> buffer;	// Este valor es una posici�n de la forma "(x,y)"
		CPoint Point = StringToPoint(buffer);
		
		ifs >> buffer;	// Este valor es el del GFH, lo despreciamos
		ifs >> buffer;	// Despreciamos este valor, es siempre 0
		ifs >> buffer;	// Despreciamos este valor, es siempre 0
		
		long lCantFab;
			
		// Hacemos un ciclo por �rdenes
		for (int j = 0; j < iNumOMs; j++)
		{ 
			lCantFab = 0;

			ifs >> buffer;
			lNum = atol(buffer);
			CBufOF* pBufOF = g_pCache->AddOF( lNum );
			COrdMaq* pOM = new COrdMaq(pBufOF);

			ifs >> buffer;

			pOM->SetpBufArt( g_pCache->AddArticulo( buffer ) );

			ifs >> buffer;	// Despreciamos este valor, es siempre 0
			ifs >> buffer;	// Cantidad, ahora guardamos no la cantidad que
							// queda, sino la ya fabricada, asi que la
							// calculamos
			lNum = atol(buffer);
			if (lNum != pBufOF->m_Cantidad ) 
			{
				lCantFab = pBufOF->m_Cantidad - lNum;
			}
			ifs >> buffer;  // Despreciamos el Maximo Personas, que viene en la OF
			
			ifs >> buffer;
			sItem = buffer;
			ifs >> buffer;
			CTime FecIni = FecBCWConvert(sItem, buffer) ;
			pOM->SetFecIni( FecIni );
			
			ifs >> buffer;
			sItem = buffer;
			ifs >> buffer;

			CTime FecFin =  FecBCWConvert(sItem, buffer);
			pOM->SetFecFin( FecFin );
			
			if (lCantFab)
			{
				CTime FecFab = FecIni;
	 			pOM->SetFab(lCantFab, FecIni);
			}
		
			ifs >> buffer;	// Despreciamos la fecha de Limite
			ifs >> buffer;  // que se puede calcular
			ifs >> buffer;	// Despreciamos la fecha de Ultima Entrada
			ifs >> buffer;  // que se puede calcular
			ifs >> buffer;  // Tiempo
			lNum = atol(buffer);
			pOM->SetTs(lNum);
			ifs >> buffer;  // Despreciamos el TiempoCal, que se puede calcular
			ifs >> buffer;  // Despreciamos el Cambio, que se puede calcular
			ifs >> buffer;  // Despreciamos el Margen, que se puede calcular
			ifs >> buffer;  // Despreciamos el Tipo, que se puede calcular
			ifs >> buffer;  //  TipoFija, que se puede calcular
			lNum = atol(buffer);
			if (lNum)
			{
				if (lNum == 1 || lNum == 5) pOM->SetBFija(TRUE);
				if (lNum == 4 || lNum == 5) pOM->SetBTiempoFijo(TRUE);	
			}
			ifs >> buffer;  // Despreciamos el Movilidad, que se puede calcular
			ifs >> buffer;  // Despreciamos el Selec, que se puede calcular
			ifs >> buffer;  // Despreciamos el 0
			ifs >> buffer;  // Despreciamos el Rect.top, que se puede calcular
			ifs >> buffer;  // Despreciamos el Rect.left, que se puede calcular
			ifs >> buffer;  // Despreciamos el Rect.right, que se puede calcular
			ifs >> buffer;  // Despreciamos el Rect.bottom, que se puede calcular
			ifs >> buffer;  // Despreciamos el 0
			
			pPM->Add(pOM);
		}

		ifs >> buffer;
		int iNumInacts = atoi(buffer);
		for (j = 0; j < iNumInacts; j++)
		{
			ifs >> buffer;	// Despreciamos la fecha de Inicio
			ifs >> buffer;  // que se puede calcular
			ifs >> buffer;	// Despreciamos la fecha de Fin
			ifs >> buffer;  // que se puede calcular
		}
	}

	ifs.close();
	
	// pProg->Recalc();
	
}


void CCpwDoc::DescargarPrograma() 
{
// Esta funcion descarga un programa al formato antiguo
	CProg* pProg = GetpProg();
	ASSERT_VALID(pProg);

	// Pedimos el fichero
	CString sExtDef = STRID(IDS_DEF_EXT);
	CString sExt = AfxGetApp()->GetProfileString("Valores Iniciales", "Extension", sExtDef);
	CString sDlgDef = STRID(IDS_DEF_OPENDLG);
	CString sDlg = AfxGetApp()->GetProfileString("Valores Iniciales", "Open File", sDlgDef);

	CFileDialog DlgFile( TRUE, 
						sExt, 
						NULL, 
						OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
						sDlg);

	if (DlgFile.DoModal() == IDCANCEL) return;
	
	ofstream ofs;
	CString sItem;
	CTime Fec;

	ofs.open(DlgFile.GetPathName(), ios::out );
	if (ofs.fail())
	{
		CString sMsg = STRID( IDS_ERR_NOOPENFILE );
		sMsg += DlgFile.GetPathName();
		AfxMessageBox(sMsg);
	}
	
	// Excribimos la fecha de comienzo y de fin de la programacion

	CString sFec = FecToBCWConvert(pProg->GetFecIni());
	ofs << sFec;

	sFec = FecToBCWConvert(pProg->GetFecFin());
	ofs << sFec;

	ofs << pProg->GetTimeScale() << '\n';


	// Escribimos las OFs. Primero el numero de ellas.

	ofs << g_pCache->GetNumOF() << '\n';

	CBufOF* pBufOF;
	for (int i = 0; i < g_pCache->GetNumOF(); i++)
	{
		pBufOF = g_pCache->GetpOFAt(i);
		ASSERT_VALID(pBufOF);

		ofs << pBufOF->m_IDBloque << ' ';
		ofs << pBufOF->m_ID << ' ';
		ofs << pBufOF->m_IDArticulo << ' ';
		ofs << pBufOF->m_Cantidad << ' ';
		ofs << FecToBCWConvert(pBufOF->m_FecEnt);
		ofs << pBufOF->m_IDBloque << ' ';
		ofs << pBufOF->m_MaxPerson << '\n';
	}

	// Ahora las maquinas. Primero el numero de ellas.
	ofs << pProg->GetNumPM() << ' ';
/*
	for ( i = 0; i < pProg->GetNumPM(); i++)
	{
		CProgMaq* pPM = pProg->GetpPM(i);
	
		ofs << pPM->GetNumOM() << ' ';
		
		ofs << 0 << ' ';	
		//ofs << pPM->GetPosition() << ' ';	
		ofs << pPM->GetsGFH() << ' ';
		ofs << 0 << ' ';	
		ofs << 0 << '\n';	
		
		// Hacemos un ciclo por �rdenes
		for (int j = 0; j < pPM->GetNumOM(); j++)
		{
			COrdMaq* pOM = pPM->GetpOM(j);
			
			ofs << pOM->GetlOF() << ' ';

			ofs << pOM->GetsID() << ' ';
			ofs << 0 << ' ';
			ofs << pOM->GetlCantidad() << ' ';
			ofs << pOM->GetlCantidad() << ' ';
			ofs << pOM->GetdMaxPerson() << ' ';
			ofs << FecToBCWConvert(pOM->GetFecIni());
			ofs << FecToBCWConvert(pOM->GetFecFin());
			ofs << pOM->GetlCantidad() << ' ';

			ofs >> buffer;	// Despreciamos la fecha de Limite
			ofs >> buffer;  // que se puede calcular
			ofs >> buffer;	// Despreciamos la fecha de Ultima Entrada
			ofs >> buffer;  // que se puede calcular
			ofs >> buffer;  // Despreciamos el Tiempo, que se puede calcular
			ofs >> buffer;  // Despreciamos el TiempoCal, que se puede calcular
			ofs >> buffer;  // Despreciamos el Cambio, que se puede calcular
			ofs >> buffer;  // Despreciamos el Margen, que se puede calcular
			ofs >> buffer;  // Despreciamos el Tipo, que se puede calcular
			ofs >> buffer;  // Despreciamos el TipoFija, que se puede calcular
			ofs >> buffer;  // Despreciamos el Movilidad, que se puede calcular
			ofs >> buffer;  // Despreciamos el Selec, que se puede calcular
			ofs >> buffer;  // Despreciamos el 0
			ofs >> buffer;  // Despreciamos el Rect.top, que se puede calcular
			ofs >> buffer;  // Despreciamos el Rect.left, que se puede calcular
			ofs >> buffer;  // Despreciamos el Rect.right, que se puede calcular
			ofs >> buffer;  // Despreciamos el Rect.bottom, que se puede calcular
			ofs >> buffer;  // Despreciamos el 0
			
			pPM->Add(pOM);
			
		}

		ofs >> buffer;
		int iNumInacts = atoi(buffer);
		for (j = 0; j < iNumInacts; j++)
		{
			ofs >> buffer;	// Despreciamos la fecha de Inicio
			ofs >> buffer;  // que se puede calcular
			ofs >> buffer;	// Despreciamos la fecha de Fin
			ofs >> buffer;  // que se puede calcular
		}
	}
*/
	ofs.close();
	

	
}
