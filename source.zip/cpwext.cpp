#include "stdafx.h"
#include "cpw.h"
#include "cpwDefs.h"

#include "AbSpan.h"
#include "prog.h"
#include "cpwDoc.h"
#include "cpwDefs.h"
#include "cpwView.h"
#include "cpwDb.h"
#include "cpwExt.h"
#include "cache.h"            
#include "progMaq.h"
#include "OrdMaq.h"


// Devuelve la misma fecha:Hora con 0 en los segundos
CTime
ZeroSec(CTime p_Fec)
{
	return CTime ( p_Fec.GetYear(),	p_Fec.GetMonth(), p_Fec.GetDay(),
					p_Fec.GetHour(), p_Fec.GetMinute(), 0 );

}

COLORREF
SelecColorRef(COLORREF p_crRaw)
{
	// Dado un COLORREF, nos devuelve uno similar pero m�s oscuro. Si Es muy oscuro,
	// lo pasa a claro.
	const int iShade = 50;
	int iBlue = p_crRaw & 0XFF;
	int iGreen = (p_crRaw >> 8) & 0xFF;
	int iRed = (p_crRaw >> 16) & 0xFF;

	if (iBlue < iShade) iBlue /= (iShade/10);
	else iBlue -= iShade;
	if (iGreen < iShade) iGreen /= (iShade/10);
	else iGreen -= iShade;
	if (iRed < iShade) iRed /= (iShade/10);
	else iRed -= iShade;
	

	return 256*256*iRed+256*iGreen+iBlue;
}

CTimeSpan
StringToTs(const CString& p_sTimeSpan)
{
	CString sHoras = "";
	CString sMin = "";
	int iHoras = 0;
	int iMin = 0;
	BOOL bMin = FALSE;
	// Convierte una cadena con formato "12:20" a un TimeSpan representando la misma cantidad
	int iLim = p_sTimeSpan.GetLength();
	for (int i = 0; i < iLim; i++)
	{
		char c = p_sTimeSpan[i];
		if (c == ':')
		{
			bMin = TRUE;
			continue;
		}
		if (!bMin)
		{
			sHoras += c;
		} else
		{
			sMin += c;
		}
	}
	iHoras = atoi(sHoras);
	iMin = atoi(sMin);
	CTimeSpan tsRes =  CTimeSpan(0, iHoras, iMin, 0);
	return tsRes;
}
// Toma una CString y nos devuelve una linea de la misma. bNext indica si hay que empezar
// desde el principio (FALSE).
CString
GetsLinea(const CString& sFile, BOOL bNext, const char cSeparator)
{
	static int i;
	if (!bNext) i = 0;
	CString sRetVal;
	sRetVal = "";
	// Buscamos el LF, no CR-LF
	int iLim = sFile.GetLength();
	// Partimos del valor anterior de i;
	for ( ;  i < iLim; i++)
	{
		sRetVal += sFile[i];
		if (sFile[i] == cSeparator)
		{
			i++;
			return sRetVal;
		}
	}
	return sRetVal;
}

CString
GetsFec(const CTime& p_FecIni, const CTime& p_FecAnt, BOOL p_BPrimera)
{
// Convierte una fecha (p_FecIni) a una cadena, compar�ndola con una fecha anterior
// para no sacar los datos que coincidan, y quede m�s bonito en el listado.
// La fecha sale en formato AA/MM/DD HH:MM
	CString sFec;
	CString sTemp;
	if (p_FecIni.GetYear() == p_FecAnt.GetYear() && !p_BPrimera)
		sFec.Format("   ");
	else
	{
		int iYear = p_FecIni.GetYear();
		int iSiglo = (iYear / 100) * 100;
		sTemp.Format("%2.2d/", iYear % iSiglo );
		sFec += sTemp;
	}
	if (p_FecIni.GetMonth() == p_FecAnt.GetMonth() && !p_BPrimera)
		sFec += "   ";
	else
	{
		sTemp.Format("%2.2d/",p_FecIni.GetMonth());
		sFec += sTemp;
	}
	if (p_FecIni.GetDay() == p_FecAnt.GetDay() && !p_BPrimera)
		sFec += "  ";
	else
	{
		sTemp.Format("%2.2d",p_FecIni.GetDay());
		sFec += sTemp;
	}
	sTemp.Format(" %2.2d:%2.2d",  p_FecIni.GetHour(),	p_FecIni.GetMinute() );
	sFec += sTemp;
	return sFec;
}                                           

BOOL
IsSameDay( CTime p_FecA, CTime p_FecB)
{
	return ( p_FecA.GetDay() == p_FecB.GetDay() &&
			 p_FecA.GetMonth() == p_FecB.GetMonth() &&
			 p_FecA.GetYear() == p_FecB.GetYear() );
}

BOOL
IsLaterDay( CTime p_FecA, CTime p_FecB)
{
	if (p_FecA.GetYear() > p_FecB.GetYear() ) return TRUE;
	if (p_FecA.GetYear() < p_FecB.GetYear() ) return FALSE;
	if (p_FecA.GetMonth() > p_FecB.GetMonth() ) return TRUE;
	if (p_FecA.GetMonth() < p_FecB.GetMonth() ) return FALSE;
	return ( p_FecA.GetDay() > p_FecB.GetDay() );
}

CTime
AddDays( CTime p_rFecA , int p_iNumDays)
{
	// Hacemos un ciclo para evitar overflows
	
	BOOL BNeg = (p_iNumDays < 0) ? TRUE : FALSE;
	int iNumDays = (BNeg) ? ( -p_iNumDays ) : p_iNumDays;
	
	for (int i = 0; i < iNumDays; i++)
	{
		if (BNeg)
			p_rFecA -= (CTimeSpan) TK_SEGS_DIA ;
		else
			p_rFecA += (CTimeSpan) TK_SEGS_DIA;
	}

	return p_rFecA;
}


CString
STRID( UINT nid )
{
	CString s = _T("");
	if (! s.LoadString( nid ))
	{
		CString sMsg;
		sMsg.Format("Error loading string. StringID = %d", nid );
		AfxMessageBox(sMsg);
		return "";
	} else
	{
		return s;
	}
}

CString 
FormatFec( CTime p_Fec, enum eFormatFec p_FF)
{                
	int iYear = p_Fec.GetYear();
	int iSiglo = (iYear / 100) * 100;
	CString sTemp, sAdd;
	if (p_FF == FechaDB)
	{
		sTemp.Format("%d/%d/%d", p_Fec.GetMonth(), p_Fec.GetDay(), iYear % iSiglo );
	}
	if (p_FF == Fecha || p_FF == FecHora || p_FF == FecHoraSec)
	{
		sTemp.Format("%2.2d/%2.2d/%2.2d", p_Fec.GetDay(), p_Fec.GetMonth(), iYear % iSiglo );
	}
	if ( p_FF == FecHoraInvert)
	{
		sTemp.Format("%2.2d/%2.2d/%2.2d", iYear % iSiglo , p_Fec.GetMonth(), p_Fec.GetDay());
	}
	if ( p_FF == FecHora || p_FF == FecHoraSec || p_FF == FecHoraInvert)
        sTemp += " ";
	if (p_FF == Hora || p_FF == FecHora || p_FF == FecHoraSec || p_FF == FecHoraInvert)
	{
		sAdd.Format("%d:%2.2d", p_Fec.GetHour(), p_Fec.GetMinute());
		sTemp += sAdd;
	}
	if ( p_FF == HoraSec || p_FF == FecHoraSec)
	{
		sAdd.Format(":%2.2d", p_Fec.GetSecond());
		sTemp += sAdd;
	}            
	return sTemp;
} 

CString
FormatFec( CTimeSpan p_ts, enum eFormatFec p_FF)
{                         
	CString sTemp, sAdd;
	sTemp.Format("%d:%d", p_ts.GetTotalHours(), p_ts.GetMinutes());
	if ( p_FF == HoraSec || p_FF == FecHoraSec)
	{
		sAdd.Format(":%d", p_ts.GetSeconds);
		sTemp += sAdd;
	}
	return sTemp;
}

CString
FormatLong(long p_lCant, int p_iMaxLen, enum eFLTipo p_eFLTipo)
{
	CString sTemp;
	FormatLong(p_lCant, sTemp, p_iMaxLen, p_eFLTipo);
	return sTemp;
}

void
FormatLong(long p_lCant, CString& p_sCant, int p_iMaxLen, enum eFLTipo p_eFLTipo)
{
	// Esta funcion convierte un entero largo en una cadena con puntos de separacion
	// de millares. Tiene un m�ximo de longitud.
	BOOL bNeg = (p_lCant < 0);
	if (bNeg) p_lCant = labs(p_lCant);
	const int iSep = 4;
	// Primero nos hacemos con el buffer de la String, porque vamos a modificarlo a pelo
	
	char*	pChar = p_sCant.GetBuffer(p_iMaxLen);
	int iFact = 10;
	int iDigit = 0;
	int iPosicion = 0;
	pChar[p_iMaxLen] = '\0';
	// Si es Real, hacemos los decimales primero.
	int iCompPos = 0;
	if (p_eFLTipo != Long && p_eFLTipo != NoPoint)
	{
		if (p_eFLTipo == Real2Dec)
		{
			iDigit = (int) (p_lCant % iFact);
			pChar[p_iMaxLen - 1 - iPosicion] = '0' + iDigit;
			iPosicion++;
			iCompPos++;
			p_lCant /= iFact;
		}
		if (iPosicion <= p_iMaxLen)
		{
			iDigit = (int) (p_lCant % iFact);
			pChar[p_iMaxLen - 1 - iPosicion] = '0' + iDigit;
			iPosicion++;
			iCompPos++;
			p_lCant /= iFact;
		}
		if (iPosicion <= p_iMaxLen)
		{
			pChar[p_iMaxLen - 1 - iPosicion] = ',';
			iPosicion++;			
			iCompPos++;
		
		}
	}
	
	if (iPosicion <= p_iMaxLen)
	{
		do
		{
			// Empezamos de atras hacia delante calculando digitos
			iDigit = (int) (p_lCant % iFact);
			pChar[p_iMaxLen - 1 - iPosicion] = '0' + iDigit;
			iPosicion++;
			if (iPosicion > p_iMaxLen) break;
			// Determinamos si es una posicion para poner un punto
			if (((iPosicion+1-iCompPos) % iSep) == 0 && p_eFLTipo != NoPoint)
			{
				pChar[p_iMaxLen - 1 - iPosicion] = '.';
				iPosicion++;			
				if (iPosicion > p_iMaxLen) break;
			}
			p_lCant /= iFact;
		}  while ( p_lCant);
	}
	// Comprobamos no vaya a ser que nos haya quedado un punto al final 
	if (((iPosicion+1-iCompPos) % iSep) == 1 && iPosicion > 1 && p_eFLTipo != NoPoint) 	pChar[p_iMaxLen - iPosicion] = ' ';
	// Eliminamos los 0�s del final y la coma si s�lo quedan 0�s
	if (p_eFLTipo != Long && p_eFLTipo != NoPoint)
	{
		BOOL bSignif = FALSE;
		for (int i = 0; i< (p_eFLTipo == Real2Dec ? 2 : 1); i++)
		{
			int j = p_iMaxLen -1 - i;
			if (!bSignif && pChar[j] == '0') pChar[j] = ' ';
			else bSignif = TRUE;
		}
		if (!bSignif) pChar[p_iMaxLen -1 - i] = ' ';
	}

	// Si es negativo metemos el menos
	if (bNeg)
	{
		pChar[p_iMaxLen - 1 - iPosicion] = '-';
		iPosicion++;
	}
	// Y rellenamos con blancos lo que queda
	for ( ; iPosicion < p_iMaxLen; iPosicion++)
		pChar[p_iMaxLen - 1 - iPosicion] = ' ';
	// Soltamos el buffer de la CString
	p_sCant.ReleaseBuffer(p_iMaxLen);
	
}


CString 
GetNomLlen(const COrdMaq* p_pOM)
{
	
	COrdMaq* pOM = NULL;
	CProgMaq* pPM = NULL;
	
	CProg* pProg = p_pOM->GetpProg();
	ASSERT_VALID(pProg);
	
	
	CString sNomLlen;
	COrdMaq* pOMprev = pProg->GetPrevOM(p_pOM);
	if (pOMprev->GetsGFH() != TK_GFH_LLENADORAS) return sNomLlen;
	else return pOMprev->GetsMaqNom();
}

int
GetDefaultTurnos(CFecTur p_FecTur, BOOL p_pBTurnos[]) 
{
	// Obtenemos los turnos por defecto para una fecha
	// Por ahora se trabaja a todas horas

	int iNumTur = 3;
	if (!p_pBTurnos) return iNumTur;
	
	p_pBTurnos[0] = p_pBTurnos[1] = p_pBTurnos[2] = TRUE;
	return iNumTur;
	
	/*
	if (!p_pBTurnos) return 2;
	CTime Fec = p_FecTur.GetFec();
	int iNumTur = 0;
	p_pBTurnos[0] = p_pBTurnos[1] = p_pBTurnos[2] = FALSE;

	if (Fec.GetMonth() == 8 || Fec.GetDayOfWeek() == 1 || Fec.GetDayOfWeek() == 7 ) 
		return iNumTur; // si es Agosto, domingo o s�bado, no se trabaja.
	else
	{
		p_pBTurnos[0] = p_pBTurnos[1] = TRUE;
		iNumTur = 2;
		return iNumTur;
	}
	*/
}

CTime
FecBCWConvert(const char* sDate, const char* sTime)
{
	CTime FecResult;
	// La constante es consecuencia del modo de almacenamiento de BCW
	DATE Date = atof(sDate) - (float) TK_CONV_DATE;
	COleDateTime ODTDate(Date);
	FecResult = ConvDateToCTime(ODTDate);
	if (sTime) FecResult += (CTimeSpan) atol(sTime);
	
	return FecResult;
}

CString
FecToBCWConvert(CTime p_Fec)
{
	CString sResult;
	// La constante es consecuencia del modo de almacenamiento de BCW

	COleDateTime ODTDate(	p_Fec.GetYear(), 
							p_Fec.GetMonth(),
							p_Fec.GetDay(),
							0,0,0 );
	DATE Date = DATE(ODTDate);
	long lDate = (long) Date + TK_CONV_DATE;
	CTimeSpan tsTemp(0, p_Fec.GetHour(), p_Fec.GetMinute(), p_Fec.GetSecond());
	long lNumSecs = tsTemp.GetTotalSeconds();
	sResult.Format("%ld %ld ", lDate, lNumSecs);
	
	return sResult;
}


CPoint
StringToPoint(const char* p_sPoint)
{
	CString sPoint = p_sPoint;
	CString sX;
	CString sY;
	for (int i = 1; i < sPoint.GetLength() && sPoint[i] != ','; i++)
	{
		sX += sPoint[i];
	}
	if (i < sPoint.GetLength())
	{
		i++;

		for ( ; i < sPoint.GetLength() && sPoint[i] != ')'; i++)
		{
			sY += sPoint[i];
		}
	}
	return CPoint( atoi(sX), atoi(sY) );
}

void 
AddOMOrd( CObArray& p_OMArr, COrdMaq* p_pOM, enum eTipoOrden p_eTipoOrden)
{
	for (int i = 0; i < p_OMArr.GetSize(); i++)
	{
		COrdMaq* pOM = (COrdMaq*) p_OMArr.GetAt(i);
		ASSERT( pOM->IsKindOf( RUNTIME_CLASS( COrdMaq ) ) );
		if (p_eTipoOrden == Creciente)
		{
			if (p_pOM->m_FecOrd  < pOM->m_FecOrd )
			{
				p_OMArr.InsertAt(i, p_pOM);
				return;
			}
		} else
		{
			if (p_pOM->m_FecOrd  > pOM->m_FecOrd )
			{
				p_OMArr.InsertAt(i, p_pOM);
				return;
			}
		}
		
	}
	// Si no, se inserta al final
	p_OMArr.Add(p_pOM);
}

void 
AddPMOrd( CObArray& p_PMArr, CProgMaq* p_pPM, enum eTipoOrden p_eTipoOrden)
{
	for (int i = 0; i < p_PMArr.GetSize(); i++)
	{
		CProgMaq* pPM = (CProgMaq*) p_PMArr.GetAt(i);
		ASSERT( pPM->IsKindOf( RUNTIME_CLASS( CProgMaq ) ) );
		if (p_eTipoOrden == Creciente)
		{
			if (p_pPM->m_FecOrd  < pPM->m_FecOrd )
			{
				p_PMArr.InsertAt(i, p_pPM);
				return;
			}
		} else
		{
			if (p_pPM->m_FecOrd  > pPM->m_FecOrd )
			{
				p_PMArr.InsertAt(i, p_pPM);
				return;
			}
		}
		
	}
	// Si no, se inserta al final
	p_PMArr.Add(p_pPM);
}

void
Triangle( CDC* pDC, CPoint p_Point1, CPoint p_Point2, CPoint p_Point3)
{
	CPoint pArr[3];
	pArr[0] = p_Point1;
	pArr[1] = p_Point2;
	pArr[2] = p_Point3;
	CRgn RgnTriangle;
	RgnTriangle.CreatePolygonRgn(pArr, 3, WINDING);
	CBrush Brush;
	Brush.CreateSolidBrush(RGB(110,110,110));
	pDC->FillRgn(&RgnTriangle, &Brush);
}

CString
GetsDlgText(UINT p_uID, CDialog* p_pDial)
{
	const int BufLen = 1024;

	char Buffer[BufLen];
	p_pDial->GetDlgItemText(p_uID, Buffer, BufLen);
	return (CString) Buffer;
}

