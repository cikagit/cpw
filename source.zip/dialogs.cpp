// Dialogs.cpp : implementation file
//

#include "stdafx.h"
#include "cpw.h"
#include "afxdtctl.h"
#include "AbSpan.h"
#include "cpwdb.h"
#include "cpwDefs.h"
#include "cpwExt.h"
#include "cache.h"
#include "ProgMaq.h"
#include "ObArrOrd.h" 
#include "OrdMaq.h"
#include "prog.h"
#include "cpwDoc.h"
#include "CpwView.h"

#include "Dialogs.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// DlgEscala dialog



BOOL DlgEscala::OnInitDialog()
{
	(void) CDialog::OnInitDialog();

	m_SpinEscala.SetRange(0,9999);
	m_SpinEscala.SetAccel(1, &m_AccelArr);
	
	m_EditEscala.SetFocus();
	return FALSE;
}	

DlgEscala::DlgEscala(CWnd* pParent /*=NULL*/)
	: CDialog(DlgEscala::IDD, pParent)
{
	//{{AFX_DATA_INIT(DlgEscala)
	m_Escala = 0;
	//}}AFX_DATA_INIT

	m_AccelArr.nSec = 1;
	m_AccelArr.nInc = 10;
}


void DlgEscala::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(DlgEscala)
	DDX_Control(pDX, IDC_ESCALA, m_EditEscala);
	DDX_Control(pDX, IDC_SPIN_ESCALA, m_SpinEscala);
	DDX_Text(pDX, IDC_ESCALA, m_Escala);
	DDV_MinMaxInt(pDX, m_Escala, 0, 99999);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(DlgEscala, CDialog)
	//{{AFX_MSG_MAP(DlgEscala)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// DlgEscala message handlers
/////////////////////////////////////////////////////////////////////////////
// DlgCargaInicial dialog


DlgCargaInicial::DlgCargaInicial(CWnd* pParent /*=NULL*/)
	: CDialog(DlgCargaInicial::IDD, pParent)
{
	//{{AFX_DATA_INIT(DlgCargaInicial)
	m_Bloque = 0;
	m_DesdeOrden = 0;
	m_HastaOrden = 0;
	//}}AFX_DATA_INIT
}


void DlgCargaInicial::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(DlgCargaInicial)
	DDX_Control(pDX, IDC_HASTA_ORDEN, m_EditHastaOrden);
	DDX_Control(pDX, IDC_DESDE_ORDEN, m_EditDesdeOrden);
	DDX_Control(pDX, IDC_BLOQUE, m_ComboBloque);
	DDX_Text(pDX, IDC_BLOQUE, m_Bloque);
	DDV_MinMaxInt(pDX, m_Bloque, 0, 999999);
	DDX_Text(pDX, IDC_DESDE_ORDEN, m_DesdeOrden);
	DDV_MinMaxInt(pDX, m_DesdeOrden, 0, 9999);
	DDX_Text(pDX, IDC_HASTA_ORDEN, m_HastaOrden);
	DDV_MinMaxInt(pDX, m_HastaOrden, 0, 9999);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(DlgCargaInicial, CDialog)
	//{{AFX_MSG_MAP(DlgCargaInicial)
	ON_CBN_SELCHANGE(IDC_BLOQUE, OnSelchangeBloque)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// DlgCargaInicial message handlers
/////////////////////////////////////////////////////////////////////////////
// CDlgValidarCambio dialog


CDlgValidarCambio::CDlgValidarCambio(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgValidarCambio::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgValidarCambio)
	m_sCampo = _T("");
	m_sValAnt = _T("");
	m_sValNue = _T("");
	//}}AFX_DATA_INIT
}


void CDlgValidarCambio::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgValidarCambio)
	DDX_Text(pDX, IDC_CAMPO, m_sCampo);
	DDX_Text(pDX, IDC_VALOR_ANTIGUO, m_sValAnt);
	DDX_Text(pDX, IDC_VALOR_NUEVO, m_sValNue);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgValidarCambio, CDialog)
	//{{AFX_MSG_MAP(CDlgValidarCambio)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgValidarCambio message handlers
/////////////////////////////////////////////////////////////////////////////
// CIntrLong dialog


CIntrLong::CIntrLong(CWnd* pParent /*=NULL*/)
	: CDialog(CIntrLong::IDD, pParent)
{
	//{{AFX_DATA_INIT(CIntrLong)
	m_lValue = 0;
	m_sText = _T("");
	//}}AFX_DATA_INIT

	m_sCaption = _T("");
}


void CIntrLong::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CIntrLong)
	DDX_Control(pDX, IDC_LONG_VALUE, m_EditLong);
	DDX_Control(pDX, IDC_CAPTION, m_EditLongValue);
	DDX_Text(pDX, IDC_LONG_VALUE, m_lValue);
	DDX_Text(pDX, IDC_CAPTION, m_sText);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CIntrLong, CDialog)
	//{{AFX_MSG_MAP(CIntrLong)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CIntrLong message handlers

BOOL CIntrLong::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	SetWindowText(m_sCaption);

	m_EditLong.SetFocus();
		
	return FALSE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
/////////////////////////////////////////////////////////////////////////////
// CIntrDbl dialog


CIntrDbl::CIntrDbl(CWnd* pParent /*=NULL*/)
	: CDialog(CIntrDbl::IDD, pParent)
{
	//{{AFX_DATA_INIT(CIntrDbl)
	m_sText = _T("");
	m_dValue = 0.0;
	//}}AFX_DATA_INIT
}


void CIntrDbl::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CIntrDbl)
	DDX_Control(pDX, IDC_DBL_VALUE, m_EditDblValue);
	DDX_Text(pDX, IDC_CAPTION, m_sText);
	DDX_Text(pDX, IDC_DBL_VALUE, m_dValue);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CIntrDbl, CDialog)
	//{{AFX_MSG_MAP(CIntrDbl)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CIntrDbl message handlers

BOOL CIntrDbl::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	SetWindowText(m_sCaption);

	m_EditDblValue.SetFocus();
	
	return FALSE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
/////////////////////////////////////////////////////////////////////////////
// CDlgPrint dialog


CDlgPrint::CDlgPrint(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgPrint::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgPrint)
	m_FecDesde = 0;
	m_sDesdeGFH = _T("");
	m_sDesdeMaq = _T("");
	m_FecHasta = 0;
	m_sHastaGFH = _T("");
	m_sHastaMaq = _T("");
	m_sTipoListado = _T("");
	//}}AFX_DATA_INIT
	m_iTipoListado = 0;
}


void CDlgPrint::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgPrint)
	DDX_Control(pDX, IDC_HASTA_FECHA, m_DTctrlHastaFecha);
	DDX_Control(pDX, IDC_DESDE_FECHA, m_DTctrlDesdeFecha);
	DDX_Control(pDX, IDC_TIPO_LISTADO, m_ComboTipoListado);
	DDX_Control(pDX, IDC_HASTA_MAQ, m_ComboHastaMaq);
	DDX_Control(pDX, IDC_HASTA_GFH, m_ComboHastaGFH);
	DDX_Control(pDX, IDC_DESDE_MAQ, m_ComboDesdeMaq);
	DDX_Control(pDX, IDC_DESDE_GFH, m_ComboDesdeGFH);
	DDX_DateTimeCtrl(pDX, IDC_DESDE_FECHA, m_FecDesde);
	DDX_CBString(pDX, IDC_DESDE_GFH, m_sDesdeGFH);
	DDX_CBString(pDX, IDC_DESDE_MAQ, m_sDesdeMaq);
	DDX_DateTimeCtrl(pDX, IDC_HASTA_FECHA, m_FecHasta);
	DDX_CBString(pDX, IDC_HASTA_GFH, m_sHastaGFH);
	DDX_CBString(pDX, IDC_HASTA_MAQ, m_sHastaMaq);
	DDX_CBString(pDX, IDC_TIPO_LISTADO, m_sTipoListado);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgPrint, CDialog)
	//{{AFX_MSG_MAP(CDlgPrint)
	ON_CBN_SELCHANGE(IDC_TIPO_LISTADO, OnSelchangeTipoListado)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgPrint message handlers

BOOL CDlgPrint::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	CStringArray ArrMaquinas;
	CStringArray ArrGFHs;

	if (g_pCache->GetArrMaquinas(ArrMaquinas))
	{                                
		for (int i=0; i< ArrMaquinas.GetSize(); i++)
		{                                  
			m_ComboDesdeMaq.AddString(ArrMaquinas[i]);
			m_ComboHastaMaq.AddString(ArrMaquinas[i]);
		}
	}

	if (g_pCache->GetArrGFHs(ArrGFHs))
	{                                
		for (int i=0; i< ArrGFHs.GetSize(); i++)
		{                                  
			m_ComboDesdeGFH.AddString(ArrGFHs[i]);
			m_ComboHastaGFH.AddString(ArrGFHs[i]);
		}
	}

	// Ponemos los valores almacenados en el registry o bien valores por defecto
	CString sTemp;
	int iSel;
	CWinApp* pApp = AfxGetApp();
   
	iSel = pApp->GetProfileInt("Dialogo de Impresion", "TipoListado", 0);
	m_ComboTipoListado.SetCurSel(iSel);

	if ( iSel == 0)
	{
		m_ComboDesdeMaq.EnableWindow(FALSE);
		m_ComboHastaMaq.EnableWindow(FALSE);
	} else
	{
		m_ComboDesdeGFH.EnableWindow(FALSE);
		m_ComboHastaGFH.EnableWindow(FALSE);
	}

		

	
	sTemp = pApp->GetProfileString("Dialogo de Impresion", "DesdeGFH", "");
	m_ComboDesdeGFH.SetWindowText(sTemp);

	sTemp = pApp->GetProfileString("Dialogo de Impresion", "HastaGFH", "");
	m_ComboHastaGFH.SetWindowText(sTemp);

	sTemp = pApp->GetProfileString("Dialogo de Impresion", "DesdeMaq", "");
	m_ComboDesdeMaq.SetWindowText(sTemp);

	sTemp = pApp->GetProfileString("Dialogo de Impresion", "HastaMaq", "");
	m_ComboHastaMaq.SetWindowText(sTemp);

	CTime FecTemp = CTime::GetCurrentTime();
	FecTemp = CTime( pApp->GetProfileInt("Dialogo de Impresion", "DesdeFecYY", FecTemp.GetYear()),
					 pApp->GetProfileInt("Dialogo de Impresion", "DesdeFecMM", FecTemp.GetMonth()),
					 pApp->GetProfileInt("Dialogo de Impresion", "DesdeFecDD", FecTemp.GetDay()) , 0, 0, 0);

	m_DTctrlDesdeFecha.SetTime(&FecTemp);
	
	FecTemp = CTime::GetCurrentTime();
	FecTemp = CTime( pApp->GetProfileInt("Dialogo de Impresion", "HastaFecYY", FecTemp.GetYear()),
					 pApp->GetProfileInt("Dialogo de Impresion", "HastaFecMM", FecTemp.GetMonth()),
					 pApp->GetProfileInt("Dialogo de Impresion", "HastaFecDD", FecTemp.GetDay()) , 0, 0, 0);

	m_DTctrlHastaFecha.SetTime(&FecTemp);

	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgPrint::OnOK() 
{
	m_iTipoListado = m_ComboTipoListado.GetCurSel() + 1;

	// Guardamos los valores en el registry para la pr�xima vez que se abra el
	// di�logo. Estos valores se resetean al comenzar la aplicaci�n.
	CString sTemp;
	CWinApp* pApp = AfxGetApp();
   
	pApp->WriteProfileInt("Dialogo de Impresion", "TipoListado", m_ComboTipoListado.GetCurSel());
   	
	m_ComboDesdeGFH.GetWindowText(sTemp);
	pApp->WriteProfileString("Dialogo de Impresion", "DesdeGFH", sTemp);
	m_ComboHastaGFH.GetWindowText(sTemp);
	pApp->WriteProfileString("Dialogo de Impresion", "HastaGFH", sTemp);
	m_ComboDesdeMaq.GetWindowText(sTemp);
	pApp->WriteProfileString("Dialogo de Impresion", "DesdeMaq", sTemp);
	m_ComboHastaMaq.GetWindowText(sTemp);
	pApp->WriteProfileString("Dialogo de Impresion", "HastaMaq", sTemp);
	
	CTime FecTemp;
	DWORD dwStatus;
	dwStatus = m_DTctrlDesdeFecha.GetTime(FecTemp);
	pApp->WriteProfileInt("Dialogo de Impresion", "DesdeFecYY", FecTemp.GetYear());
	pApp->WriteProfileInt("Dialogo de Impresion", "DesdeFecMM", FecTemp.GetMonth());
	pApp->WriteProfileInt("Dialogo de Impresion", "DesdeFecDD", FecTemp.GetDay());

	dwStatus = m_DTctrlHastaFecha.GetTime(FecTemp);
	pApp->WriteProfileInt("Dialogo de Impresion", "HastaFecYY", FecTemp.GetYear());
	pApp->WriteProfileInt("Dialogo de Impresion", "HastaFecMM", FecTemp.GetMonth());
	pApp->WriteProfileInt("Dialogo de Impresion", "HastaFecDD", FecTemp.GetDay());

	CDialog::OnOK();
}

void CDlgPrint::OnSelchangeTipoListado() 
{
	if (m_ComboTipoListado.GetCurSel() == 0)
	{
		m_ComboDesdeMaq.EnableWindow(FALSE);
		m_ComboHastaMaq.EnableWindow(FALSE);
		m_ComboDesdeGFH.EnableWindow();
		m_ComboHastaGFH.EnableWindow();
	} else 
	{
		m_ComboDesdeGFH.EnableWindow(FALSE);
		m_ComboHastaGFH.EnableWindow(FALSE);
		m_ComboDesdeMaq.EnableWindow();
		m_ComboHastaMaq.EnableWindow();
	}
}

BOOL DlgCargaInicial::OnInitDialog() 
{
	CDialog::OnInitDialog();
	

	CUIntArray ArrBloques;
	
	g_pCache->GetArrBloques(ArrBloques);

	for (int i = 0; i < ArrBloques.GetSize(); i++)
	{
		CString sTemp;
		sTemp.Format("%u" , (unsigned) ArrBloques[i]);
		m_ComboBloque.AddString(sTemp);
	}
	if (i > 0) 
	{
		m_ComboBloque.SetCurSel(0);
		OnSelchangeBloque();
	}
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void DlgCargaInicial::OnSelchangeBloque() 
{
	int iMinBlq, iMaxBlq, iBloque;
	CString sTemp;

	m_ComboBloque.GetLBText(m_ComboBloque.GetCurSel(), sTemp);
	iBloque = atoi(sTemp);

	g_pCache->GetMaxMinBlq(iBloque, iMinBlq, iMaxBlq);
	sTemp.Format("%d", iMinBlq);
	m_EditDesdeOrden.SetWindowText(sTemp);
	sTemp.Format("%d", iMaxBlq);
	m_EditHastaOrden.SetWindowText(sTemp);
	
}

/////////////////////////////////////////////////////////////////////////////
// CDlgBuscarOrden dialog


CDlgBuscarOrden::CDlgBuscarOrden(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgBuscarOrden::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgBuscarOrden)
	m_sOrden = _T("");
	//}}AFX_DATA_INIT
}


void CDlgBuscarOrden::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgBuscarOrden)
	DDX_Control(pDX, IDC_ORDEN, m_ComboOrden);
	DDX_CBString(pDX, IDC_ORDEN, m_sOrden);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgBuscarOrden, CDialog)
	//{{AFX_MSG_MAP(CDlgBuscarOrden)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgBuscarOrden message handlers

BOOL CDlgBuscarOrden::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	CObArray ArrOFs;

	g_pCache->GetArrOFs( ArrOFs );
	for (int i = 0; i < ArrOFs.GetSize(); i++)
	{
		CBufOF* pOF = (CBufOF*) ArrOFs.GetAt(i);
		ASSERT( pOF->IsKindOf( RUNTIME_CLASS( CBufOF ) ) );		

		CString sOFData;
//		sOFData.Format("%ld", pOF->m_OrdFab);
//		m_ComboOrden.AddString( sOFData );
	}
	m_ComboOrden.SetFocus();

	return FALSE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
/////////////////////////////////////////////////////////////////////////////
// CDlgIntrDate dialog


CDlgIntrDate::CDlgIntrDate(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgIntrDate::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgIntrDate)
	m_sCaption = _T("");
	m_Fec = 0;
	//}}AFX_DATA_INIT
}


void CDlgIntrDate::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgIntrDate)
	DDX_Control(pDX, IDC_FECHA, m_DTctrlFecha);
	DDX_Text(pDX, IDC_CAPTION, m_sCaption);
	DDX_DateTimeCtrl(pDX, IDC_FECHA, m_Fec);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgIntrDate, CDialog)
	//{{AFX_MSG_MAP(CDlgIntrDate)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgIntrDate message handlers

BOOL CDlgIntrDate::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	SetWindowText(m_sCaption);

	m_DTctrlFecha.SetFocus();
	
	return FALSE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
/////////////////////////////////////////////////////////////////////////////
// CDlgInsMaq dialog


CDlgInsMaq::CDlgInsMaq(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgInsMaq::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgInsMaq)
	m_sInsMaq = _T("");
	m_iAntes = -1;
	//}}AFX_DATA_INIT
}


void CDlgInsMaq::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgInsMaq)
	DDX_Control(pDX, IDC_INSMAQ_ANTES, m_ButtonAntes);
	DDX_Control(pDX, IDC_INSMAQ_MAQ, m_ComboInsMaq);
	DDX_CBString(pDX, IDC_INSMAQ_MAQ, m_sInsMaq);
	DDX_Radio(pDX, IDC_INSMAQ_ANTES, m_iAntes);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgInsMaq, CDialog)
	//{{AFX_MSG_MAP(CDlgInsMaq)
	ON_CBN_EDITCHANGE(IDC_INSMAQ_MAQ, OnEditchangeInsmaqMaq)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgInsMaq message handlers

void CDlgInsMaq::OnEditchangeInsmaqMaq() 
{
	// TODO: Add your control notification handler code here
	
}

BOOL CDlgInsMaq::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	CStringArray ArrMaquinas;

	if (g_pCache->GetArrMaquinas(ArrMaquinas))
	{                                
		for (int i=0; i< ArrMaquinas.GetSize(); i++)
		{                                  
			m_ComboInsMaq.AddString(ArrMaquinas[i]);
		}
	}

	m_ButtonAntes.SetCheck(1);
	m_ComboInsMaq.SetFocus();
	
	return FALSE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
/////////////////////////////////////////////////////////////////////////////
// CDlgMaqOrd dialog


CDlgMaqOrd::CDlgMaqOrd(CCpwDoc* p_pDoc, CWnd* pParent /*=NULL*/)
	: CDialog(CDlgMaqOrd::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgMaqOrd)
	m_FecDesde = 0;
	m_FecHasta = 0;
	//}}AFX_DATA_INIT
	m_pDoc = p_pDoc;
}


void CDlgMaqOrd::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgMaqOrd)
	DDX_Control(pDX, IDC_FEC_HASTA, m_DTctrlFecHasta);
	DDX_Control(pDX, IDC_FEC_DESDE, m_DTctrlDesde);
	DDX_Control(pDX, IDC_LSC_MAQORD, m_ListCtrl);
	DDX_DateTimeCtrl(pDX, IDC_FEC_DESDE, m_FecDesde);
	DDX_DateTimeCtrl(pDX, IDC_FEC_HASTA, m_FecHasta);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgMaqOrd, CDialog)
	//{{AFX_MSG_MAP(CDlgMaqOrd)
	ON_NOTIFY(DTN_DATETIMECHANGE, IDC_FEC_DESDE, OnDatetimechangeFecDesde)
	ON_NOTIFY(DTN_DATETIMECHANGE, IDC_FEC_HASTA, OnDatetimechangeFecHasta)
	ON_BN_CLICKED(IDC_PRINT_MAQORD, OnPrintMaqord)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


BOOL CDlgMaqOrd::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	UpdateList();
	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgMaqOrd::IniMaqOrd()
{
	
	LV_COLUMN lvc;
	LV_ITEM lvi;
	const int iNumCol = 6;
	char* ArrsCols[] = { "M�q.", "Oferta", "Mezcla", "Piezas", "Horas", "P/H" };
	int ArriWidths[] = { 30, 100, 100, 60, 40, 40 };
	int ArriFmts[] = { LVCFMT_RIGHT, LVCFMT_LEFT, LVCFMT_LEFT, LVCFMT_RIGHT, LVCFMT_RIGHT, LVCFMT_RIGHT };
	int iLim = m_ArrOM.GetSize();
	
	CTime FecDesde, FecHasta;
	m_DTctrlDesde.GetTime(FecDesde);
	m_DTctrlFecHasta.GetTime(FecHasta);
	
	lvc.mask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM;
	
	for(int i = 0; i < iNumCol; i++)
	{
		lvc.iSubItem = i;
		lvc.pszText = ArrsCols[i];
		lvc.cx = ArriWidths[i];
		lvc.fmt = ArriFmts[i];
		m_ListCtrl.InsertColumn(i,&lvc);
	}
	
	
	int iLin = 0;
	CString sMaqAnt = "";
	for ( i=0; i < iLim; i++)
	{
		const int TK_SIZE_MAQ = 10;
		char sMaq[TK_SIZE_MAQ+1];
		COrdMaq* pOM = (COrdMaq*) m_ArrOM.GetAt(i);
			
		COrdMaq* pOMNext = NULL;
		BOOL bRepMaq = FALSE;
		
		if (pOM->GetFecFin() < FecDesde || pOM->GetFecIni() > FecHasta) continue;
		if (sMaqAnt == pOM->GetsMaquina())
		{
			bRepMaq = TRUE;
		}
		sMaqAnt = pOM->GetsMaquina();
		if (bRepMaq)
			strncpy(sMaq,"", TK_SIZE_MAQ);
		else
			strncpy(sMaq,pOM->GetsMaquina(), TK_SIZE_MAQ);
		lvi.mask = LVIF_TEXT;
		lvi.iItem = iLin;
		lvi.iSubItem = 0;
		lvi.pszText =  sMaq;
		lvi.iImage = 0;
		
		m_ListCtrl.InsertItem(&lvi);
		
		m_ListCtrl.SetItemText(iLin,1,pOM->GetsID());
		m_ListCtrl.SetItemText(iLin,2,pOM->GetsMezcla());
		m_ListCtrl.SetItemText(iLin,3,FormatLong(pOM->GetlCantidad(),7));
		m_ListCtrl.SetItemText(iLin,4,FormatLong((pOM->GetTimeSpan().GetTotalHours()),5));
		m_ListCtrl.SetItemText(iLin,5,FormatLong((long) pOM->GetdCadencia(),5));
		iLin++;
	}
}

void CDlgMaqOrd::IniOF()
{
	
	LV_COLUMN lvc;
	LV_ITEM lvi;
	const int iNumCol = 9;
	char* ArrsCols[] = { "Oferta", "Fecha","Ayer", "Hoy", "Dif.", "Horas", "Cliente", "Seccion", "Planif."};
	int ArriWidths[] = { 80, 80, 60, 60, 60 , 60, 100, 50, 30};
	int ArriFmts[] = { LVCFMT_LEFT, LVCFMT_LEFT, LVCFMT_RIGHT, LVCFMT_RIGHT, LVCFMT_RIGHT, LVCFMT_RIGHT, LVCFMT_LEFT, LVCFMT_RIGHT, LVCFMT_RIGHT};
	int iLim = m_ArrOF.GetSize();
	
	CTime FecDesde, FecHasta;
	m_DTctrlDesde.GetTime(FecDesde);
	m_DTctrlFecHasta.GetTime(FecHasta);
	
	lvc.mask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM;
	
	for(int i = 0; i < iNumCol; i++)
	{
		lvc.iSubItem = i;
		lvc.pszText = ArrsCols[i];
		lvc.cx = ArriWidths[i];
		lvc.fmt = ArriFmts[i];
		m_ListCtrl.InsertColumn(i,&lvc);
	}
	
	CString sIDAnt = "";
	int iLin = 0;
	for ( i=0; i < iLim; i ++)
	{
		const int TK_SIZE_MAQ = 10;
		char sMaq[TK_SIZE_MAQ+1];
		long lCantAnt = -1;
		CString sArtAnt = "";
		CComp* pComp = (CComp*) m_ArrOF.GetAt(i);
			
		//if (pOF->m_FecNec < FecDesde || pOF->m_FecNec > FecHasta) continue;
		// Estas lineas evitan que campos con la misma diferencia salgan en la consulta,
		// es decir que una diferencia no se perpetue en los d�as siguientes
		long lCant = (long) (pComp->m_dCantHoy - pComp->m_dCantAyer);
		if (pComp->m_sIDArticulo == sArtAnt && lCant == lCantAnt) continue;
		sArtAnt = pComp->m_sIDArticulo;
		lCantAnt = lCant;

		lvi.mask = LVIF_TEXT;
		lvi.iItem = iLin;
		lvi.iSubItem = 0;
		lvi.pszText =  sMaq;
		lvi.iImage = 0;
		
		m_ListCtrl.InsertItem(&lvi);
		if (pComp->m_sIDArticulo == sIDAnt)
		{
			m_ListCtrl.SetItemText(iLin,0, "" );
		} else
		{
			m_ListCtrl.SetItemText(iLin,0, pComp->m_sIDArticulo );
			sIDAnt = pComp->m_sIDArticulo;
		}
		CBufArticulo* pBufArt = g_pCache->FindpArticulo(pComp->m_sIDArticulo);
		m_ListCtrl.SetItemText(iLin,1, FormatFec( pComp->m_FecNec, Fecha) );
		m_ListCtrl.SetItemText(iLin,2, FormatLong((long) pComp->m_dCantAyer,7) );
		m_ListCtrl.SetItemText(iLin,3, FormatLong((long) pComp->m_dCantHoy,7) );
		m_ListCtrl.SetItemText(iLin,4, FormatLong( lCant,7) );
		if (pBufArt)
			m_ListCtrl.SetItemText(iLin,5, FormatLong((long) ((lCant / pBufArt->GetdCadencia()) + 1) ,7) );
		else
			m_ListCtrl.SetItemText(iLin,5, "-");

		m_ListCtrl.SetItemText(iLin,6, pComp->m_sIDCliente);
		m_ListCtrl.SetItemText(iLin,7, FormatLong(pComp->m_lSeccion ,7) );
		CProg* pProg = m_pDoc->GetpProg();
		CString sPlanif = "";
		
		COMC* pOMC = pProg->GetpOMC(pComp->m_sIDArticulo);
		if (pOMC) sPlanif = "P";
		m_ListCtrl.SetItemText(iLin,8, sPlanif );
		iLin++;
	}
}


void CDlgMaqOrd::IniMezExt()
{
	
	LV_COLUMN lvc;
	LV_ITEM lvi;
	const int iNumCol = 5;
	char* ArrsCols[] = { "Local", "Oferta","Cliente", "Mezcla","Fecha Ini."};
	int ArriWidths[] = { 80, 80, 180, 80, 100};
	int ArriFmts[] = { LVCFMT_LEFT, LVCFMT_LEFT, LVCFMT_LEFT, LVCFMT_RIGHT, LVCFMT_LEFT};
	int iLim = m_ArrMezExt.GetSize();
	
	CTime FecDesde, FecHasta;
	m_DTctrlDesde.GetTime(FecDesde);
	m_DTctrlFecHasta.GetTime(FecHasta);
	
	lvc.mask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM;
	
	for(int i = 0; i < iNumCol; i++)
	{
		lvc.iSubItem = i;
		lvc.pszText = ArrsCols[i];
		lvc.cx = ArriWidths[i];
		lvc.fmt = ArriFmts[i];
		m_ListCtrl.InsertColumn(i,&lvc);
	}
	
	CString sIDAnt = "";
	int iLin = 0;
	for ( i=0; i < iLim; i ++)
	{
		const int TK_SIZE_MAQ = 10;
		char sMaq[TK_SIZE_MAQ+1];
		CBufLisMezclas* pBufLisMezclas = (CBufLisMezclas*) m_ArrMezExt.GetAt(i);
			
		//if (pOF->m_FecNec < FecDesde || pOF->m_FecNec > FecHasta) continue;
		lvi.mask = LVIF_TEXT;
		lvi.iItem = iLin;
		lvi.iSubItem = 0;
		lvi.pszText =  sMaq;
		lvi.iImage = 0;
		
		m_ListCtrl.InsertItem(&lvi);
		if (pBufLisMezclas->m_sIDLocal == sIDAnt)
		{
			m_ListCtrl.SetItemText(iLin,0, "" );
		} else
		{
			m_ListCtrl.SetItemText(iLin,0, pBufLisMezclas->m_sIDLocal );
			sIDAnt = pBufLisMezclas->m_sIDLocal;
		}
		long lCant = (long) (pBufLisMezclas->m_lMezcla);
		CBufArticulo* pBufArt = g_pCache->FindpArticulo(pBufLisMezclas->m_sIDArticulo);
		m_ListCtrl.SetItemText(iLin,1, pBufLisMezclas->m_sIDArticulo );
		m_ListCtrl.SetItemText(iLin,2, pBufLisMezclas->m_sIDCliente );
		m_ListCtrl.SetItemText(iLin,3, FormatLong(lCant, 7));
		m_ListCtrl.SetItemText(iLin,4, FormatFec( pBufLisMezclas->m_FecIni, FecHora) );
		
		iLin++;
	}
}

void 
CDlgMaqOrd::IniCambioMolde()
{

	LV_COLUMN lvc;
	LV_ITEM lvi;
	const int iNumCol = 6;
	static char* ArrsCols[] = { "M�q.", "Entrante", "Saliente", "Horas", "Causa", "Mezcla" };
	int ArriWidths[] = { 30, 70, 70, 50, 120, 50 };
	int ArriFmts[] = { LVCFMT_RIGHT, LVCFMT_LEFT, LVCFMT_LEFT, LVCFMT_RIGHT, LVCFMT_LEFT, LVCFMT_RIGHT };
	int iLim = m_ArrOM.GetSize();
	
	
	CTime FecDesde, FecHasta;
	m_DTctrlDesde.GetTime(FecDesde);
	m_DTctrlFecHasta.GetTime(FecHasta);
		
	lvc.mask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM;
	
	CString sMaqAnt = "";
		for(int i = 0; i < iNumCol; i++)
	{
		lvc.iSubItem = i;
		lvc.pszText = ArrsCols[i];
		lvc.cx = ArriWidths[i];
		lvc.fmt = ArriFmts[i];
		m_ListCtrl.InsertColumn(i,&lvc);
	}
	
	
	int iLin = 0;
	for ( i=0; i < iLim; i++)
	{
		const int TK_SIZE_MAQ = 10;
		char sMaq[TK_SIZE_MAQ+1];
		COrdMaq* pOM = (COrdMaq*) m_ArrOM.GetAt(i);
		COrdMaq* pOMNext = NULL;
		BOOL bRepMaq = FALSE;
		if (pOM->GetFecFin() < FecDesde || pOM->GetFecFin() > FecHasta) continue;
		if ( (i+1) < iLim)
		{
			pOMNext = (COrdMaq*) m_ArrOM.GetAt(i+1);
		}
		CString sMolde = pOM->GetsMolde();
		CString sMoldeNext = (pOMNext) ? pOMNext->GetsMolde() : "";
		if ( sMolde == sMoldeNext ) continue; 

		if (sMaqAnt == pOM->GetsMaquina())
		{
			bRepMaq = TRUE;
		}
		sMaqAnt = pOM->GetsMaquina();
		if (bRepMaq)
			strncpy(sMaq,"", TK_SIZE_MAQ);
		else
			strncpy(sMaq,pOM->GetsMaquina(), TK_SIZE_MAQ);

		lvi.mask = LVIF_TEXT;
		lvi.iItem = iLin;
		lvi.iSubItem = 0;
		lvi.pszText =  sMaq;
		lvi.iImage = 0;
		
		m_ListCtrl.InsertItem(&lvi);

		m_ListCtrl.SetItemText(iLin,1,sMolde);
		m_ListCtrl.SetItemText(iLin,2,sMoldeNext);
		m_ListCtrl.SetItemText(iLin,3,FormatFec(pOM->GetFecFin(),Hora));
		m_ListCtrl.SetItemText(iLin,4,"");
		m_ListCtrl.SetItemText(iLin,5,pOM->GetsMezcla());
		iLin++;
		
	}
}

void CDlgMaqOrd::OnDatetimechangeFecDesde(NMHDR* pNMHDR, LRESULT* pResult) 
{
	UpdateList();

	*pResult = 0;
}

void CDlgMaqOrd::OnDatetimechangeFecHasta(NMHDR* pNMHDR, LRESULT* pResult) 
{
	UpdateList();
	
	*pResult = 0;
}

void 
CDlgMaqOrd::UpdateList()
{
	m_ListCtrl.DeleteAllItems();
	while (m_ListCtrl.DeleteColumn(0)) ;
	if (m_eTipoCons == ConsMaqOrd)
	{
		SetWindowText("Consulta M�quinas / �rdenes");
		IniMaqOrd();
	}
	else if (m_eTipoCons == ConsCambioMolde) 
	{
		SetWindowText("Consulta Cambios Moldes");
		IniCambioMolde();
	}
	else if (m_eTipoCons == ConsLotes) 
	{
		SetWindowText("Consulta de Lotes");
		IniLotes();
	}
	else if (m_eTipoCons == ConsOF) 
	{
		SetWindowText("Consulta de Diferencias Ayer / Hoy");
		IniOF();
	}
	else if (m_eTipoCons == ConsMezExt) 
	{
		SetWindowText("Consulta de Necesidades de Mezclas Externas");
		IniMezExt();
	}
}

void CDlgMaqOrd::IniLotes()
{
	LV_COLUMN lvc;
	LV_ITEM lvi;
	const int iNumCol = 6;
	static char* ArrsCols[] = { "M�q.", "Oferta", "Mezcla", "Piezas", "Peso Nec.", "Lote" };
	int ArriWidths[] = { 30, 100, 100, 60, 40, 40 };
	int ArriFmts[] = { LVCFMT_RIGHT, LVCFMT_LEFT, LVCFMT_LEFT, LVCFMT_RIGHT, LVCFMT_RIGHT, LVCFMT_RIGHT };
	int iLim = m_ArrOM.GetSize();
	
	CTime FecDesde, FecHasta;
	m_DTctrlDesde.GetTime(FecDesde);
	m_DTctrlFecHasta.GetTime(FecHasta);
	
	lvc.mask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM;
	
	for(int i = 0; i < iNumCol; i++)
	{
		lvc.iSubItem = i;
		lvc.pszText = ArrsCols[i];
		lvc.cx = ArriWidths[i];
		lvc.fmt = ArriFmts[i];
		m_ListCtrl.InsertColumn(i,&lvc);
	}
	
	
	int iLin = 0;
	CString sMaqAnt = "";
	for ( i=0; i < iLim; i++)
	{
		const int TK_SIZE_MAQ = 10;
		char sMaq[TK_SIZE_MAQ+1];
		COrdMaq* pOM = (COrdMaq*) m_ArrOM.GetAt(i);
			
		COrdMaq* pOMNext = NULL;
		BOOL bRepMaq = FALSE;
		
		if (pOM->GetFecFin() < FecDesde || pOM->GetFecIni() > FecHasta) continue;
		if (sMaqAnt == pOM->GetsMaquina())
		{
			bRepMaq = TRUE;
		}
		sMaqAnt = pOM->GetsMaquina();
		if (bRepMaq)
			strncpy(sMaq,"", TK_SIZE_MAQ);
		else
			strncpy(sMaq,pOM->GetsMaquina(), TK_SIZE_MAQ);
		lvi.mask = LVIF_TEXT;
		lvi.iItem = iLin;
		lvi.iSubItem = 0;
		lvi.pszText =  sMaq;
		lvi.iImage = 0;
		
		m_ListCtrl.InsertItem(&lvi);
		
		m_ListCtrl.SetItemText(iLin,1,pOM->GetsID());
		m_ListCtrl.SetItemText(iLin,2,pOM->GetsMezcla());
		m_ListCtrl.SetItemText(iLin,3,FormatLong(pOM->GetlCantidad(),7));
		m_ListCtrl.SetItemText(iLin,4,FormatLong(pOM->GetlCantidad()*pOM->GetlPeso(),7));
		m_ListCtrl.SetItemText(iLin,5,FormatLong((long) pOM->GetlLote(),5));
		iLin++;
	}
}

void CDlgMaqOrd::OnPrintMaqord() 
{
	if (m_eTipoCons == ConsMezExt) PrintMezExt();
	if (m_eTipoCons != ConsMaqOrd) return;
	CWinApp* wApp = AfxGetApp();
	ASSERT_VALID(wApp);
	wApp->WriteProfileInt("Dialogo de Impresion", "TipoListado", 1);
	wApp->WriteProfileString("Dialogo de Impresion", "DesdeMaq", "1");
	wApp->WriteProfileString("Dialogo de Impresion", "HastaMaq", "1");

	POSITION pos = m_pDoc->GetFirstViewPosition();
	while (pos != NULL)
	{
		CView* pView = m_pDoc->GetNextView(pos);
		if ( pView->IsKindOf( RUNTIME_CLASS( CCpwView )))
		{
			CCpwView* pCpwView = (CCpwView*) pView;
			pCpwView->SendMessage(WM_COMMAND, ID_FILE_PRINT);
		}
	}

	
}

// Printing functions

void
CDlgMaqOrd::PrintMezExt()
{
	// Cargamos la base de datos con los datos del listado
	g_pCache->CargaLisMezclas(&m_ArrMezExt);

	// Y ejecutamos Access con la macro adecuada
	STARTUPINFO startup;
	PROCESS_INFORMATION process;
	
	memset( &startup, 0, sizeof( startup ) );
	startup.cb = sizeof( startup );
	
	memset( &process, 0, sizeof( process ) );
	
	CString sAcc = AfxGetApp()->GetProfileString("Listados", "Access", "");
	AfxGetApp()->WriteProfileString("Listados", "Access", sAcc);
	CString sMacro = AfxGetApp()->GetProfileString("Listados", "Mezclas Externas", "");
	AfxGetApp()->WriteProfileString("Listados", "Mezclas Externas", sMacro);

	CString sComm = sAcc + " " + sMacro;
	if (sComm == "") return;

	char* pszCommandLine = sComm.GetBuffer( 0 );
	BOOL tSuccess = CreateProcess( NULL, pszCommandLine, NULL, NULL, FALSE, 0, NULL,   NULL, &startup, &process );
//	WaitForInputIdle(process.hProcess, INFINITE);
	if( tSuccess )
	{
		// Close the handles that CreateProcess returned so we don't leak
		// kernel resources.
		ASSERT( process.hProcess != NULL );
		CloseHandle( process.hProcess );
		ASSERT( process.hThread != NULL );
		CloseHandle( process.hThread );
//		g_pCache->UpdateMezclasPlanta();
	}
	else
	{
		AfxMessageBox( "Error al ejecutar proceso" );
	}

}





/////////////////////////////////////////////////////////////////////////////
// CDlgIntrStr dialog


CDlgIntrStr::CDlgIntrStr(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgIntrStr::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgIntrStr)
	m_sCaption = _T("");
	m_sValue = _T("");
	//}}AFX_DATA_INIT
}


void CDlgIntrStr::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgIntrStr)
	DDX_Control(pDX, IDC_STR_VALUE, m_EditStr);
	DDX_Text(pDX, IDC_CAPTION, m_sCaption);
	DDX_Text(pDX, IDC_STR_VALUE, m_sValue);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgIntrStr, CDialog)
	//{{AFX_MSG_MAP(CDlgIntrStr)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgIntrStr message handlers

BOOL CDlgIntrStr::OnInitDialog() 
{
	CDialog::OnInitDialog();
	

	SetWindowText(m_sCaption);

	m_EditStr.SetFocus();
		
	return FALSE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
/////////////////////////////////////////////////////////////////////////////
// CDlgLista dialog


CDlgLista::CDlgLista(CObArray* p_pArrInfoMolArt, CWnd* pParent /*=NULL*/)
	: CDialog(CDlgLista::IDD, pParent)
{
	m_pArrInfoMolArt = p_pArrInfoMolArt;
	//{{AFX_DATA_INIT(CDlgLista)
	//}}AFX_DATA_INIT
}


void CDlgLista::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgLista)
	DDX_Control(pDX, IDC_LISTA, m_ListCtrl);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgLista, CDialog)
	//{{AFX_MSG_MAP(CDlgLista)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgLista message handlers

BOOL CDlgLista::OnInitDialog() 
{
	CDialog::OnInitDialog();
		
	LV_COLUMN lvc;
	LV_ITEM lvi;
	const int iNumCol = 3;
	char* ArrsCols[] = { "Prioridad", "Oferta", "% Hist" };
	int ArriWidths[] = { 30, 60, 60 };
	int ArriFmts[] = { LVCFMT_RIGHT, LVCFMT_LEFT, LVCFMT_RIGHT };
	int iLim = m_pArrInfoMolArt->GetSize();
	
	CTime FecDesde, FecHasta;
	
	lvc.mask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM;
	
	for(int i = 0; i < iNumCol; i++)
	{
		lvc.iSubItem = i;
		lvc.pszText = ArrsCols[i];
		lvc.cx = ArriWidths[i];
		lvc.fmt = ArriFmts[i];
		m_ListCtrl.InsertColumn(i,&lvc);
	}
	
	int iLin = 0;
	// Ordenamos los valores por Prioridad y art�culo
	CObArray ArrSort;
	BOOL bFind;
	for ( i=0; i < iLim; i++)
	{
		CInfoMolArt* pInfoMolArt = (CInfoMolArt*) m_pArrInfoMolArt->GetAt(i);
		ASSERT( pInfoMolArt->IsKindOf( RUNTIME_CLASS( CInfoMolArt ) ) );
		bFind = FALSE;
		for (int j=0; j < ArrSort.GetSize(); j++)
		{
			CInfoMolArt* pSortMolArt = (CInfoMolArt*) ArrSort.GetAt(j);
			if (pSortMolArt->m_lPrioridad > pInfoMolArt->m_lPrioridad || 
				( (pSortMolArt->m_lPrioridad == pInfoMolArt->m_lPrioridad) &&
				   (pSortMolArt->m_sIDArticulo > pInfoMolArt->m_sIDArticulo ) ) )
			{
				ArrSort.InsertAt(j, pInfoMolArt);
				bFind = TRUE;
				break;
			}
		}
		if (!bFind) ArrSort.Add(pInfoMolArt);
	}
	long lPrioAnt = -1;
	for ( i=0; i < iLim; i++)
	{
		CInfoMolArt* pInfoMolArt = (CInfoMolArt*) ArrSort.GetAt(i);
		ASSERT( pInfoMolArt->IsKindOf( RUNTIME_CLASS( CInfoMolArt ) ) );

		lvi.mask = LVIF_TEXT;
		lvi.iItem = iLin;
		lvi.iSubItem = 0;
		lvi.pszText =  "";
		lvi.iImage = 0;
		
		m_ListCtrl.InsertItem(&lvi);
		m_ListCtrl.SetItemText(iLin,0, (pInfoMolArt->m_lPrioridad != lPrioAnt) ? 
									FormatLong(pInfoMolArt->m_lPrioridad ,3) : "");
		lPrioAnt = pInfoMolArt->m_lPrioridad;
		m_ListCtrl.SetItemText(iLin,1,pInfoMolArt->m_sIDArticulo);
		m_ListCtrl.SetItemText(iLin,2,pInfoMolArt->m_lPorcHist ? 
								FormatLong(pInfoMolArt->m_lPorcHist, 6) : 
								"-");
		delete pInfoMolArt;
		iLin++;
	}
	m_pArrInfoMolArt->RemoveAll();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

