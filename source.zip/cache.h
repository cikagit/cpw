// cache.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CCache class

class CProgMaq;
class CProg;
class CBufArticulo;
class CObArrayOrd;
class CBufMaquina;
class CBufOF;
class CBufCambiosMoldes;

class CComp : public CObject
{
protected:
	DECLARE_SERIAL(CComp)

public:

	CComp(CComp* pComp = NULL);
	CComp(CBufOF* pBufOF);
	BOOL operator ==(const CComp& p_Comp) const;
	BOOL operator <(const CComp& p_Comp) const;


	CTime	m_FecNec;
	CString	m_sIDArticulo;
	CString m_sIDCliente;
	double	m_dCantAyer;
	double	m_dCantHoy;
	long	m_lSeccion;

};

class CCache : public CObject
{
// Field/Param Data

	protected:
	CRsArticulo m_RsArticulo;
	CRsMaquinas m_RsMaquinas;
	CRsCliente m_RsCliente;
	CRsEntregas m_RsEntregas;
	CRsArtMol m_RsArtMol;
	CRsHistorico m_RsHistorico;
	CRsCalendario m_RsCalendario;
	CRsLocales m_RsLocales;
	CRsMezclas m_RsMezclas;
	CRsMoldes m_RsMoldes;
	CRsMolMaq m_RsMolMaq;
	CRsPedidos m_RsPedidos;
	CRsPedidosAyer m_RsPedidosAyer;
	CRsListadoValorado m_RsListadoValorado;
	CRsCambiosMoldes m_RsCambiosMoldes;
	CRsMezclasPlanta m_RsMezclasPlanta;
	CRsLisMezclas m_RsLisMezclas;


	CObArray*	m_pArrArticulos;
	CObArray*	m_pArrMoldes;
	CObArray*	m_pArrMolMaq;
	CObArray*	m_pArrOFs;
	CObArray*	m_pArrMaquinas;
	CObArray*	m_pArrMezclas;
	CObArrayOrd* m_pArrOFComb;			// Array de OFs combinadas
	CObArrayOrd* m_pArrOFSeccion;		// Array de OFs ordenadas por seccion
	CObArray*	m_pArrOFSel;			// Array de OFs seleccionadas
	CObArray*	m_pArrOFAcum;			// Array de OFs Acumuladas (1 por fecha)
	CObArray*	m_pArrOFAyer;			// Array de OFs del d�a anterior
	CObArray*	m_pArrCambMold;			// Array de cambios de moldes
		
	CDatabase* m_pDB;
// Implementation
public:                   
	void AddHistorico(COrdMaq* p_pOM);
	void CargaLisMezclas(CObArray* p_ArrBufLisMezclas);
	CBufCambiosMoldes* GetNextCambioMolde(CTime p_Fec);
	CBufCambiosMoldes* GetFirstCambioMolde(CTime p_Fec);
	void ActLimitMaq(const CString& p_sMolde, const CString& p_sMaq);
	void UpdateMezclasPlanta();
	void SetOrdenOF();
	int GetiOFSec(int p_iOFAct, BOOL p_bNext = TRUE );
	int GetiOFArt(int p_iOFAct, BOOL p_bNext = TRUE );
	void SelecToFec(CTime p_Fec);
	void RecalcOFs(CProg* p_pProg);
	int SearchIndOF(const CString& p_sSearch);
	void UnselectAllBufOF();
	void SelectToBufOF(CBufOF* p_pBufOF );
	CBufMaquina* FindpMaquina(const CString &p_sMaquina);
	CBufMolde* FindpMolde( const CString& p_sMolde );
	CBufMezcla* FindpMezcla(const CString& p_sMezcla );
	void LinkPointer();
	CBufArticulo* FindpArticulo(const CString& p_sArticulo);
	int GetArrMaq( const CString& p_sArticulo, CObArray& p_ArrMaq, CObArray& p_ArrMoldes);
	int GetArrMolMaq(const CString &p_sMaquina, CObArray &p_ArrMolMaq, const CString* p_psIDArt = NULL);
	int GetArrMolArt(const CString &p_sMaquina, CObArray &p_ArrMolArt );
	CCache(CDatabase* miDb);
	~CCache();   
	void ClearOFs();
	
	CBufArticulo* AddArticulo(const char* IDArticulo);
	CBufMaquina* AddMaquina(const char* IDMaquina);
	CBufOF* FindOFID( long p_lOFID );
	CBufOF* FindOFNum( long p_lOFNum );
	CBufOF* FindOFArt( const CString& p_sArticulo );

	void UpdateOF( const CString& p_sIDArt , int p_iCant );
	
	int GetNumOF();
	CBufOF* GetpOFAt( int p_iInd );

	void AssignInacts( CProgMaq& p_PM );

	int GetArrMaquinas( CStringArray& p_ArrMaquinas );     
	void GetArrAcum(CObArray *p_pArrOF, CObArray *p_pArrAcum);
	int GetArrOFs( CObArray& p_ArrOFs );
	int GetArrConsOF( CObArray& p_ArrOFs );
	int GetArrGFHs( CStringArray& p_ArrMaquinas );     
	CObArray* GetArrBufArt();
	int GetArrBloques (CUIntArray& p_ArrBloques);  
	void GetMaxMinBlq( int p_iBloque, int& p_iMinBlq, int& p_iMaxBlq);
	CString GetsGFH( const char* IDMaquina );                 
	int GetiNumTurnos(CFecTur p_FecTur, const CProgMaq& p_PM, BOOL BTurnos[] = NULL);
	void SetTurnos(const CFecTur p_FecTur, const CProgMaq* p_pPM);
	void SerializeOFs(CArchive& ar);
	
	CBufOF* AddOF( long p_ID , BOOL p_bUpdateFec = FALSE );
	void AddOF( CBufOF* p_pOF );
	
	void DeleteBufOF( CBufOF* p_pOF);

	
	void IniFillCache();
	void IniFillArticulos();
	void IniFillMaquinas();
	void IniFillMolMaq();
	void IniFillOFs();
	void IniFillOFsAyer();
	void IniFillMezclas();

	void EmptyArrays();
	
	void Prueba();
};


/////////////////////////////////////////////////////////////////////////////
// OFComb


// Estructura auxiliar

class COMComb : public CObject
{
public:
	CAbSpan		m_AbSpan;			// Espacio de tiempo cubierto por la cadencia homog�nea
	double		m_dCadencia;		// Cadencia acumulada de todas las �rdenes que se simultanean

	COMComb(COrdMaq* p_OM = NULL);
	COMComb( COMComb& p_OMC);
	COMComb& operator =(const COMComb& p_OMC);
	long GetlCantFab();
	
protected:
	DECLARE_DYNAMIC(COMComb)   
	
};

class COFComb : public CObject
{
protected:
	DECLARE_SERIAL(COFComb)


// Attributes
public:
	CString	m_sID;
	int		m_iIni;
	int		m_iFin;

// Operations
public:
	COFComb();
	
	virtual void Serialize(CArchive& ar);   
	
// Implementation
public:
	virtual ~COFComb();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

};


class CInfoMolArt : public CObject
{
public:
	long		m_lPrioridad;
	CString		m_sIDArticulo;
	long		m_lPorcHist;

	CInfoMolArt();
	
protected:
	DECLARE_DYNAMIC(CInfoMolArt)   
	
};


inline BOOL OFComb_Bigger( CObject* p_pA, CObject* p_pB ) { return ((COFComb*)p_pA)->m_sID > ((COFComb*)p_pB)->m_sID; }
inline BOOL OFComb_Equal( CObject* p_pA, CObject* p_pB ) { return ((COFComb*)p_pA)->m_sID == ((COFComb*)p_pB)->m_sID; }

inline BOOL OFSeccion_Bigger( CObject* p_pA, CObject* p_pB );
inline BOOL OFSeccion_Equal( CObject* p_pA, CObject* p_pB ) ;

inline BOOL BufArt_Bigger( CObject* p_pA, CObject* p_pB );
inline BOOL BufArt_Equal( CObject* p_pA, CObject* p_pB );
