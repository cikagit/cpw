
enum eTipoDiv { Interna, Media, Externa };
enum eTipoPrint { Pantalla, Impresora };


class COrdMaq : public CObject
{
	DECLARE_SERIAL(COrdMaq)
	protected:
		CAbSpan				m_Abs;    
		CTimeSpan			m_ts;
		CTimeSpan			m_tsMargen;
		CTimeSpan			m_tsMezcla;		// Tiempo que le queda con esa mezcla
		CTime				m_FecMezcla;	// Fecha hasta la que puede seguir con la mezcla
		COLORREF			m_Color;
		CProgMaq*			m_pPM;
		CBufOF*				m_pBufOF;
		CBufArticulo*		m_pBufArt;
		CBufMolde*			m_pBufMolde;
		CSet				m_SetErr;		// Errores que tiene
		long				m_lCant;
		double				m_dCadencia;

		long				m_lCantFab;		// Cantidad ya fabricada
		CTime				m_FecFab;		// Fecha en la que se ha fabricado
		
		BOOL				m_BSelected;
		BOOL				m_BFija;
		BOOL				m_BTiempoFijo;
		BOOL				m_bConfMolde;
		CString				m_sIDArticulo;
		CString				m_sIDMolde;
	public:     
		BOOL TieneInacts() const;
		int GetArrInacts(CObArray& p_ArrInact) const;
		long				m_lAux;			// Valor 
		double				m_dAux;			// Valor doble auxiliar en c�lculos
		CString				m_sAux;			// Valor String auxiliar en c�lculos

		void Relink();
		long		GetlCantMezcla();
		
		long		GetlNecMezcla(BOOL p_bRoundUp = TRUE, BOOL p_bKilos = TRUE);
		void RecalcFin();
		BOOL Overlaps(COrdMaq* p_pOM);
		int ModifMolde(const char* p_sIDMolde);
		long GetlPeso();
		CString GetsMolde() const;
		CString GetsMaqNom() const;
		CString GetsMezcla() const;
		BOOL GetbConfMolde() const { return m_bConfMolde; };
		double GetdCadAbsPs() const;
		long CalcCantLote();
		double GetdChatarras() const;
		long GetlLote();
		void ModifCant(long p_lCant);
		CTime				m_FecOrd;		// Fecha generica para ordenar

		COrdMaq&	operator =(const COrdMaq& p_OM);
		BOOL operator ==(const COrdMaq& p_OM) const;
		
		COrdMaq(const CString&);
		COrdMaq(CBufOF* pBufOF = NULL, CBufMolde* p_pMolde = NULL);
		~COrdMaq() {};
 		virtual void Serialize(CArchive& ar);
		int			Recalc();
		void		SetValues(const COrdMaq* p_pOM);

//	Get�s inmediatos
		CTime		GetFecIni() const { return m_Abs.GetFecIni(); }; 		
		CTime		GetFecFin() const { return m_Abs.GetFecFin(); }; 
		CTime		GetFecMezcla() const { return m_FecMezcla; }; 
		CTime		GetFecLim() const;
		CProgMaq* 	GetpPM() const { return m_pPM; };
		CTimeSpan	GetTimeSpan() const { return m_ts; };
		CTimeSpan	GetTsMargen() const { return m_tsMargen; };
		CTimeSpan	GetTsMezcla() const { return m_tsMezcla; };
		BOOL		GetBSelected() const { return m_BSelected; };
		BOOL		GetBFija() const { return m_BFija; };
		BOOL		GetBTiempoFijo() const { return m_BTiempoFijo; };
		CBufOF*		GetpOF()	const	// same return type as CBufOF::GetID()
					{ return m_pBufOF; };
		CBufArticulo*		GetpBufArticulo()	const	{ return m_pBufArt; };
		CBufMolde*		GetpBufMolde()	const	{ return m_pBufMolde; };
		CBufArtMol*		GetpBufArtMol();
		CTime		GetFecFab() const { return m_FecFab; };
		long		GetlCantFab() const { return m_lCantFab; };
        
// Get�s indirectos
		CTimeSpan   GetTotalTs() const;
		long		GetlCantidad() const { return m_lCant; };
		long		GetlCantOF() const;
		long		GetlOF() const;
		CString		GetsID() const;
		CString		GetsNombre() const;
		CString		GetsDescripcion() const;
		char		GetcExtInt() const;
		BOOL		GetBNueveYMedio() const;
		BOOL		GetBDoble() const;
		BOOL		GetBTriple() const;
		double		GetdMaxPerson() const;
		double		GetdCadencia() const;
		double		GetdInactividad() const;
		int			GetiMasa() const;
		long		GetlBloque() const;
		long		GetlLongitud() const;
		BOOL		GetBNuevoLlen() const;
		BOOL		GetBNuevoCel() const;
		            
		CString		GetsGFH() const;
		CString		GetsMaquina() const;

					
		BYTE		GetbCelAlt() const;	
		BYTE		GetbCelula() const;	
		CTime		GetFecEnt() const; 		
		CProg*		GetpProg() const 
					{
						if (m_pPM)
							return m_pPM->GetpProg();
						else
							return NULL;
					};
 // Set�s inmediatos
		void		SetFecIni(CTime p_Fec) { m_Abs.SetFecIni(ZeroSec(p_Fec)); }; 		
		void		SetFecFin(CTime p_Fec) ;
		void		SetBSelected(BOOL p_BSelected) { m_BSelected = p_BSelected; }
		void		SetBFija(BOOL p_BFija) { m_BFija = p_BFija; }
		void		SetbConfMolde(BOOL p_bConfMolde);
		void		SetBTiempoFijo(BOOL p_BTiempoFijo) { m_BTiempoFijo = p_BTiempoFijo; }
		void		SetTs(CTimeSpan p_ts) { m_ts = p_ts; };
		void		SetTsMargen(CTimeSpan p_ts) { m_tsMargen = p_ts; };
		void		SetTsMezcla(CTimeSpan p_ts);
		void		SetlCantidad(long p_lCant) { m_lCant = p_lCant; }  ;
		void		SetdCadencia(double p_dCadencia) { m_dCadencia = p_dCadencia; }  ;
		void		SetpBufArt(CBufArticulo* p_pBufArt) 
			{
				m_pBufArt = p_pBufArt; 
				if (p_pBufArt) 
				{
					m_sIDArticulo = p_pBufArt->m_sID;
					m_pBufOF = g_pCache->FindOFArt( p_pBufArt->m_sID ); 
				}
				else 
				{
					m_sIDArticulo = "";
					m_pBufOF = NULL;
				}
			};
		void		SetpBufMolde(CBufMolde* p_pBufMolde) 
			{ 
				m_pBufMolde = p_pBufMolde;
				if (p_pBufMolde) m_sIDMolde = p_pBufMolde->m_sID;
				else m_sIDMolde = "";
			};
		void		SetFab(long p_lCantFab, CTime p_FecFab) 
					{ m_lCantFab = p_lCantFab;
						m_FecFab = p_FecFab;};


// Get�s calculados
		CBrush*		GetpBrush(enum eTipoPrint p_eTipoPrint = Pantalla) const;

		void		SetpPM(CProgMaq* p_pPM, BOOL p_bCheck = FALSE);
		void		SelecTo();
		void		CalcTimeSpan(); 
		void		CalcFecLim();

		void		CalcFecFin();      
		void		CalcTsMargen();
		CTimeSpan	CalcTsMezcla(long lCant);

        
		CString		FormatLimit( const char* p_sGFH ) const; 
		CString		GetsInfo() const;  
		int			PMIndex() const;
		BOOL		LimitMaquina( const char* p_sMaquina ) const;
		BOOL		LimitGFH( const char* p_sGFH ) const;

//	Funciones de modificaci�n de datos
		void		ModifCant( const char* sCant );
		void		ModifMaxPerson( const char* sMaxPerson );
		void		ModifFecEnt( CTime p_FecEnt );
		void		ModifTimeSpan( const char* sTimeSpan );
				
		void		UnselectAll();
		void		CalcFecIni();
		void		SetNewArt(enum eTipoDiv p_eTipoDiv);

// Otras funciones
		
	BOOL		First() const;
	BOOL		Last() const;
	COrdMaq*	Prev() ;
	COrdMaq*	Next() ;
};

