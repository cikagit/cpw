// cpw.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "afxext.h"

#include "cpw.h"
#include "cpwDefs.h"

#include "MainFrm.h"
#include "ObArrOrd.h"
#include "AbSpan.h"
#include "prog.h"
#include "cpwDb.h"
#include "cpwExt.h"
#include "cache.h"            
#include "ProgMaq.h"
#include "ChildFrm.h"
#include "cpwDoc.h"
#include "cpwView.h"
#include "TextView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


CCache* g_pCache = NULL;
CProgMaq* g_pPM = NULL;
COrdMaq* g_pOM = NULL;
BOOL	g_bException = FALSE; // Solo hacer TRUE antes de sacar un mesaje y salir de la app
BOOL	g_bHorizontal = TRUE;

struct SVerOF g_VerOF;

CString g_sError = "\\%%**ERROR";

CBrush	g_BrushParada;
CBrush	g_BrushArr[CPW_N_BRUSHES*2];
CBrush	g_BrushArrImp[CPW_N_BRUSHES*2];


/////////////////////////////////////////////////////////////////////////////
// CCpwApp

BEGIN_MESSAGE_MAP(CCpwApp, CWinApp)
	//{{AFX_MSG_MAP(CCpwApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
	ON_COMMAND(ID_TEST, OnTest)
	ON_COMMAND(ID_RELOAD_DB, OnReloadDb)
	ON_COMMAND(ID_EXEC_DB, OnExecDb)
	ON_COMMAND(ID_EXEC_MEZCLAS, OnExecMezclas)
	ON_COMMAND(ID_EXEC_SEGUNDO, OnExecSegundo)
	ON_COMMAND(ID_EXEC_MOLDES, OnExecMoldes)
	//}}AFX_MSG_MAP
	// Standard file based document commands
	ON_COMMAND(ID_FILE_NEW, CWinApp::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
	// Standard print setup command
	ON_COMMAND(ID_FILE_PRINT_SETUP, CWinApp::OnFilePrintSetup)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCpwApp construction

CCpwApp::CCpwApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CCpwApp object

CCpwApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CCpwApp initialization

BOOL CCpwApp::InitInstance()
{

	AfxEnableControlContainer();

	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	// Change the registry key under which our settings are stored.
	// You should modify this string to be something appropriate
	// such as the name of your company or organization.
	SetRegistryKey(_T("Complex"));

	LoadStdProfileSettings();  // Load standard INI file options (including MRU)


	g_bHorizontal = GetProfileInt("Valores Iniciales", "Vistas Horizontales", TRUE);
	WriteProfileInt("Valores Iniciales", "Vistas Horizontales", g_bHorizontal);

	WriteProfileInt("Dialogo de Impresion", "TipoListado", 0);
	WriteProfileString("Dialogo de Impresion", "DesdeGFH", "5");
	WriteProfileString("Dialogo de Impresion", "HastaGFH", "5");
	WriteProfileString("Dialogo de Impresion", "DesdeMaq", "1");
	WriteProfileString("Dialogo de Impresion", "HastaMaq", "94");
	
	CTime FecTemp = CTime::GetCurrentTime();
	WriteProfileInt("Dialogo de Impresion", "DesdeFecYY", FecTemp.GetYear());
	WriteProfileInt("Dialogo de Impresion", "DesdeFecMM", FecTemp.GetMonth());
	WriteProfileInt("Dialogo de Impresion", "DesdeFecDD", FecTemp.GetDay());

	WriteProfileInt("Dialogo de Impresion", "HastaFecYY", FecTemp.GetYear());
	WriteProfileInt("Dialogo de Impresion", "HastaFecMM", FecTemp.GetMonth());
	WriteProfileInt("Dialogo de Impresion", "HastaFecDD", FecTemp.GetDay());


	// Register the application's document templates.  Document templates
	//  serve as the connection between documents, frame windows and views.

	CMultiDocTemplate* pDocTemplate;
	pDocTemplate = new CMultiDocTemplate(
		IDR_CPWTYPE,
		RUNTIME_CLASS(CCpwDoc),
		RUNTIME_CLASS(CChildFrame), // custom MDI child frame
		RUNTIME_CLASS(CCpwView));
	AddDocTemplate(pDocTemplate);

	CMultiDocTemplate* pDocTemplateTxt;
	pDocTemplateTxt = new CMultiDocTemplate(
		IDR_TEXTTYPE,
		RUNTIME_CLASS(CCpwDoc),
		RUNTIME_CLASS(CChildFrame), // custom MDI child frame
		RUNTIME_CLASS(CTextView));
	AddDocTemplate(pDocTemplateTxt);


	// create main MDI Frame window
	CMainFrame* pMainFrame = new CMainFrame;
	if (!pMainFrame->LoadFrame(IDR_MAINFRAME))
		return FALSE;
	m_pMainWnd = pMainFrame;

	// Parse command line for standard shell commands, DDE, file open
	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);

	// Abrimos la base de datos y inicializamos el objeto "Cache" para usarlo como
	// interface con la base de datos.
	CString sDbDir, sDbName, sDb;
	sDbDir = GetProfileString("Base de Datos Cikautxo", "Directorio", "C:\\cpw\\datos");
	sDbName = GetProfileString("Base de Datos Cikautxo", "Nombre", "cikadat.mdb");
	WriteProfileString("Base de Datos Cikautxo", "Directorio", sDbDir);
	WriteProfileString("Base de Datos Cikautxo", "Nombre", sDbName);
   
	sDb = "ODBC;DSN=MS Access 97 Database;DBQ=" + sDbDir + "\\" +
             sDbName + ";DefaultDir=" + sDbDir + 
			 ";DriverId=25;FIL=MS Access;MaxBufferSize=512;PageTimeout=5;";
    m_MyDb.Open(sDb);  
	
    if (!m_MyDb.IsOpen())
		return FALSE;
	
	// Creamos el cache

    g_pCache = new CCache(&m_MyDb);
    if (!g_pCache)
	{
		CString sMsg = STRID( IDS_ERR_NODB );
		sMsg = sMsg + sDbDir + "\\" + sDbName ;
		pMainFrame->MessageBox(sMsg);
		return FALSE;
	}
	// Dispatch commands specified on the command line
	if (!ProcessShellCommand(cmdInfo))
		return FALSE;

	// The main window has been initialized, so show and update it.
	//pMainFrame->ShowWindow(m_nCmdShow);
	pMainFrame->ShowWindow(SW_SHOWMAXIMIZED);
	pMainFrame->UpdateWindow();

	// Inicializamos los valores globales
	
	InitGlobalValues();


	return TRUE;
}


void
CCpwApp::InitGlobalValues()
{
	// Esta funci�n es llamada al inicial el programa y al cambiar los colores
	COLORREF colTmp;
	colTmp = GetProfileInt("Valores Iniciales", "Color Peligro 0", TK_COLOR_0);
	g_BrushArr[0].CreateSolidBrush(colTmp);		 // Ordenes sin peligro
	g_BrushArr[1].CreateSolidBrush(SelecColorRef(colTmp));			// Sin peligro seleccionadas

	colTmp = GetProfileInt("Valores Iniciales", "Color Peligro 1", TK_COLOR_1);
	g_BrushArr[2].CreateSolidBrush(colTmp);		 // Ordenes peligro 1
	g_BrushArr[3].CreateSolidBrush(SelecColorRef(colTmp));			// peligro 1 seleccionadas
	
	colTmp = GetProfileInt("Valores Iniciales", "Color Peligro 2", TK_COLOR_2);
	g_BrushArr[4].CreateSolidBrush(colTmp);
	g_BrushArr[5].CreateSolidBrush(SelecColorRef(colTmp));

	g_BrushParada.CreateSolidBrush(RGB(255, 255, 255));
	
	g_BrushArrImp[0].CreateSolidBrush(RGB(255, 255, 255));
	g_BrushArrImp[1].CreateSolidBrush(RGB(150, 150, 150));
	g_BrushArrImp[2].CreateSolidBrush(RGB(255, 200, 152));
	g_BrushArrImp[3].CreateSolidBrush(RGB(220, 172, 52));
	g_BrushArrImp[4].CreateSolidBrush(RGB(240, 10, 10));
	g_BrushArrImp[5].CreateSolidBrush(RGB(176, 0, 0));

	g_VerOF.m_bAcumOFs = FALSE;
	g_VerOF.m_bSelecFec = FALSE;
	g_VerOF.m_bSoloNoProg = FALSE;
	g_VerOF.m_FecSelec = CTime::GetCurrentTime();
	g_VerOF.m_OrdenOF = Articulo;
}

void
CCpwApp::SetBrushes()
{
	COLORREF colTmp;
	colTmp = GetProfileInt("Valores Iniciales", "Color Peligro 0", TK_COLOR_0);

	g_BrushArr[0].DeleteObject();
	g_BrushArr[1].DeleteObject();
	g_BrushArr[2].DeleteObject();
	g_BrushArr[3].DeleteObject();
	g_BrushArr[4].DeleteObject();
	g_BrushArr[5].DeleteObject();
	
	g_BrushArr[0].CreateSolidBrush(colTmp);		 // Ordenes sin peligro
	g_BrushArr[1].CreateSolidBrush(SelecColorRef(colTmp));			// Sin peligro seleccionadas

	colTmp = GetProfileInt("Valores Iniciales", "Color Peligro 1", TK_COLOR_1);
	g_BrushArr[2].CreateSolidBrush(colTmp);		 // Ordenes peligro 1
	g_BrushArr[3].CreateSolidBrush(SelecColorRef(colTmp));			// peligro 1 seleccionadas
	
	colTmp = GetProfileInt("Valores Iniciales", "Color Peligro 2", TK_COLOR_2);
	g_BrushArr[4].CreateSolidBrush(colTmp);
	g_BrushArr[5].CreateSolidBrush(SelecColorRef(colTmp));
}

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
		// No message handlers
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

// App command to run the dialog
void CCpwApp::OnAppAbout()
{
	CAboutDlg aboutDlg;
	aboutDlg.DoModal();
}

/////////////////////////////////////////////////////////////////////////////
// CCpwApp commands

int CCpwApp::ExitInstance() 
{
	delete g_pCache;
	
	return CWinApp::ExitInstance();
}

void CCpwApp::OnTest() 
{
}

void CCpwApp::OnReloadDb() 
{
	CWaitCursor WaitCursor;

	g_pCache->EmptyArrays();
	g_pCache->IniFillCache();
	//Ahora tenemos que volver a poner los punteros de las OM's y PM's de
	// todos los documentos abiertos (de tipo Cpw)
    POSITION posTemp = GetFirstDocTemplatePosition(); 
	ASSERT (posTemp);
	CDocTemplate* pDocTemplate = GetNextDocTemplate(posTemp);
	if (pDocTemplate) // Cogemos cualquier Template, todas van a los mismos documentos
	{
		POSITION pos = pDocTemplate->GetFirstDocPosition(); 
		if (pos == NULL) return;		
		CCpwDoc* pDoc = NULL;
		CProg* pProg = NULL;
		do
		{
			pDoc = (CCpwDoc*)pDocTemplate->GetNextDoc(pos);
	
			if (pDoc->IsKindOf( RUNTIME_CLASS(CCpwDoc) ) )
			{
				pProg = pDoc->GetpProg();

				pProg->RelinkAll();
				pDoc->UpdateAllViews(NULL);
				pDoc->UpdateTextView();
			}
		} while (pos != NULL);
	}
}

void CCpwApp::OnExecDb() 
{
	STARTUPINFO startup;
	PROCESS_INFORMATION process;
	
	memset( &startup, 0, sizeof( startup ) );
	startup.cb = sizeof( startup );
	
	memset( &process, 0, sizeof( process ) );
	
	CString sComm = GetProfileString("Comandos", "Diario", "");
	WriteProfileString("Comandos", "Diario", sComm);

	if (sComm == "") return;

	char* pszCommandLine = sComm.GetBuffer( 0 );
	BOOL tSuccess = CreateProcess( NULL, pszCommandLine, NULL, NULL, FALSE, 0, NULL,   NULL, &startup, &process );
//	WaitForInputIdle(process.hProcess, INFINITE);
	if( tSuccess )
	{
		// Close the handles that CreateProcess returned so we don't leak
		// kernel resources.
		ASSERT( process.hProcess != NULL );
		CloseHandle( process.hProcess );
		ASSERT( process.hThread != NULL );
		CloseHandle( process.hThread );
//		OnReloadDb();
	}
	else
	{
		AfxMessageBox( "Error al ejecutar proceso" );
	}
	
}

void CCpwApp::OnExecSegundo() 
{
	STARTUPINFO startup;
	PROCESS_INFORMATION process;
	
	memset( &startup, 0, sizeof( startup ) );
	startup.cb = sizeof( startup );
	
	memset( &process, 0, sizeof( process ) );
	
	CString sComm = GetProfileString("Comandos", "OFs y Articulos", "");
	WriteProfileString("Comandos", "OFs y Articulos", sComm);

	if (sComm == "") return;

	char* pszCommandLine = sComm.GetBuffer( 0 );
	BOOL tSuccess = CreateProcess( NULL, pszCommandLine, NULL, NULL, FALSE, 0, NULL,   NULL, &startup, &process );
//	WaitForInputIdle(process.hProcess, INFINITE);
	if( tSuccess )
	{
		// Close the handles that CreateProcess returned so we don't leak
		// kernel resources.
		ASSERT( process.hProcess != NULL );
		CloseHandle( process.hProcess );
		ASSERT( process.hThread != NULL );
		CloseHandle( process.hThread );
//		OnReloadDb();
	}
	else
	{
		AfxMessageBox( "Error al ejecutar proceso" );
	}
	
}

void CCpwApp::OnExecMezclas() 
{
	STARTUPINFO startup;
	PROCESS_INFORMATION process;
	
	memset( &startup, 0, sizeof( startup ) );
	startup.cb = sizeof( startup );
	
	memset( &process, 0, sizeof( process ) );
	
	CString sComm = GetProfileString("Comandos", "Mezclas", "");
	WriteProfileString("Comandos", "Mezclas", sComm);

	if (sComm == "") return;

	char* pszCommandLine = sComm.GetBuffer( 0 );
	BOOL tSuccess = CreateProcess( NULL, pszCommandLine, NULL, NULL, FALSE, 0, NULL,   NULL, &startup, &process );
//	WaitForInputIdle(process.hProcess, INFINITE);
	if( tSuccess )
	{
		// Close the handles that CreateProcess returned so we don't leak
		// kernel resources.
		ASSERT( process.hProcess != NULL );
		CloseHandle( process.hProcess );
		ASSERT( process.hThread != NULL );
		CloseHandle( process.hThread );
//		g_pCache->UpdateMezclasPlanta();
	}
	else
	{
		AfxMessageBox( "Error al ejecutar proceso" );
	}
	
}


void CCpwApp::OnExecMoldes() 
{
	STARTUPINFO startup;
	PROCESS_INFORMATION process;
	
	memset( &startup, 0, sizeof( startup ) );
	startup.cb = sizeof( startup );
	
	memset( &process, 0, sizeof( process ) );
	
	CString sComm = GetProfileString("Comandos", "Moldes", "");
	WriteProfileString("Comandos", "Moldes", sComm);

	if (sComm == "") return;

	char* pszCommandLine = sComm.GetBuffer( 0 );
	BOOL tSuccess = CreateProcess( NULL, pszCommandLine, NULL, NULL, FALSE, 0, NULL,   NULL, &startup, &process );
//	WaitForInputIdle(process.hProcess, INFINITE);
	if( tSuccess )
	{
		// Close the handles that CreateProcess returned so we don't leak
		// kernel resources.
		ASSERT( process.hProcess != NULL );
		CloseHandle( process.hProcess );
		ASSERT( process.hThread != NULL );
		CloseHandle( process.hThread );
//		g_pCache->UpdateMezclasPlanta();
	}
	else
	{
		AfxMessageBox( "Error al ejecutar proceso" );
	}
		
}
