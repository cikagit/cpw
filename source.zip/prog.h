class CCpwDoc;  
class CProgMaq;   
class CBufOF;
class CObArrayOrd;
class COMC;
class COMComb;
	
enum EDirMove { Left, Right };


class CProg : public CObject
{
	DECLARE_SERIAL(CProg)
	protected:
		CAbSpan			m_Abs;
		CCpwDoc*		m_pDoc;
		long			m_lTimeScale;
		CObArray*		m_pArrPMs;
		long			m_lNumDias;
public:
		CObArrayOrd*	m_pArrOMs;

	public: 
		void DescuentoConSolapes(long& p_rlCant, COMC* p_pOMC, CObArray* p_pArrNoCambio, CTime p_Fec);
		void InformarErrores(CObArray* p_pArrNoCambio, CObArray* p_pArrNoFab, CStringArray* p_pArrNotFound, CObArray* p_pArrBorrar);
		void RelinkAll();
		long CalcCantAFecha(const CString& p_sIDArticulo, CTime p_Fec);
		CTime CalcFecParaCant(const CString& p_sIDArticulo, long p_lCant);

		void DescuentaVal(CTime p_Fec, int p_iLocal);
		void AplicarCambiosMoldes(CTime p_Fec,  CObArray* p_pArrNoCambios, CObArray* p_pArrBorrar, CObArray* p_pArrNoCambio, CStringArray* p_pArrNotFound );
		int GetNumOM();
		void GetArrPM(CObArray& p_PMArr);
		int GetArrOMC(CObArrayOrd& p_pArr);
		int GetArrMaqOM(CObArray& p_pArrOM);
		int GetArrMezExt(CObArray& p_ArrMezExt);


		int DesolaparArrOMC(CObArray* p_pArrOM, CObArray* p_pArrOMComb);
		void AplicarCalendarioOMC(CObArray* p_pArrOM, CObArray* p_pArrOMComb);
		void DesacoplarInact(CAbSpan* p_pAbSpanInact, COrdMaq* p_pOM, CObArray* p_pArrOMComb);


		long GetlCantArt(const CString& m_pIDArt);
		COrdMaq* FindOMArt(const CString& p_sArticulo);

		
		CProg();
		~CProg();
		CProg& operator =(const CProg& p_Prog);
		void AddPM( CProgMaq* p_pPM, int p_iInd = -1);
		void DeleteOM (COrdMaq* p_pOM);
		void DeletePM( int p_iPM );
		BOOL MovePM( CProgMaq* p_pPM, EDirMove p_eDirMove);
		void SwitchPM( int p_iInd, int p_iInd2 );

		void ClearPMs();
 		void ClearOMs();
		int CalcArrOMC();
		void CalcMezclas();

 		virtual void Serialize(CArchive& ar);
 		
		CTime		GetFecIni() const { return m_Abs.GetFecIni(); }; 		
		CTime		GetFecFin() const { return m_Abs.GetFecFin(); }; 		
		CCpwDoc*	GetpDoc() const { return m_pDoc; };
		long	GetTimeScale() const { return m_lTimeScale; };        

		void	SetTimeScale(int p_lTimeScale)	
		{ if (p_lTimeScale > 0) m_lTimeScale = p_lTimeScale; };        
		void	SetpDoc(CCpwDoc* p_pDoc) { m_pDoc = p_pDoc; }; 
		void	RecalcInacts();
		void	Recalc();
		void	SetFecIni(CTime p_Fec) ;
		void	SetFecFin(CTime p_Fec) { if (p_Fec > GetFecIni()) m_Abs.SetFecFin(p_Fec); RecalcInacts();};
		int GetNumPM() const ;
		int GetNumPMsInGFHs(CString p_sDesdeGFH, CString p_sHastaGFH) const ;
		CProgMaq* GetpPM(int p_NumMaq) const;

		int Find(const CProgMaq* p_pPM) const ;
		CProgMaq* FindMaq(const char* p_ID) const;
		CProgMaq* FindMaqByDesc(const char* p_sDesc) const;
		
		int	GetArrOM( CObArray* p_pArrOM, CBufOF* p_pOF );
		int	GetArrOMArt( CObArray* p_pArrOM, const CString p_sIDArt );

		void MoveOrdMaq(CProgMaq* p_pPM, COrdMaq* p_pOM, int pInd);

		COrdMaq*	GetPrevOM(const COrdMaq* p_pOM, const char* p_sGFH = NULL) const;
		
		void UnselectAll();

		void CargaGFH(const char* p_sGFH);
		void ReprogramaGFH(const char* p_sGFH);
		
		void BuscaOptimizar( CObArray& p_ArrOMs, int p_iInd );
		void InsertaEnGFH(CObArray& p_ArrOMs, const char* p_sGFH);
		int BuscarHuecosGFH(const char* p_sGFH, COrdMaq* p_pOM, CObArray& p_ArrPMs) const;
		BOOL VerifStruct();
		BOOL InsertNewOM(COrdMaq* p_pOM, BOOL& p_rbModif );
		COMC* GetpOMC(const CString& p_sIDArt);



};

/////////////////////////////////////////////////////////////////////////////
// OMC

class COMC : public CObject
{
protected:
	DECLARE_SERIAL(COMC)


// Attributes
public:
	CString		m_sID;
	COrdMaq*	m_pOM;
	CObArray*	m_pArrOM;		// Array de OMs ordenadas por FecIni
	CObArray*	m_pArrCOMComb;	// Array de OMs-combinadas para el c�lculo de la fabricaci�n 
								// en un momento determinado.

// Operations
public:
	COMC() { m_pOM = NULL; m_pArrOM = NULL;};
	BOOL HaySolapes();
	void GetArrOMsAfec( COMComb* p_pOMComb, CObArray* p_pArrOMs);
	long ReparteCant(long p_lCant);

	virtual void Serialize(CArchive& ar) {};   
	
// Implementation
public:
	virtual ~COMC() {};

};

inline BOOL OMC_Bigger( CObject* p_pA, CObject* p_pB ) { return ((COMC*)p_pA)->m_sID > ((COMC*)p_pB)->m_sID; }
inline BOOL OMC_Equal( CObject* p_pA, CObject* p_pB ) { return ((COMC*)p_pA)->m_sID == ((COMC*)p_pB)->m_sID; }
