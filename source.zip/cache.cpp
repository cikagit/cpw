// cache.cpp


#include "stdafx.h"

#include "cpw.h"
#include "cpwDefs.h"
#include "AbSpan.h"
#include "cpwdb.h"
#include "prog.h"
#include "cpwExt.h"

#include "cache.h"
#include "ProgMaq.h"
#include "ObArrOrd.h" 
#include "strstrea.h"
#include "OrdMaq.h"
#include "DlgDebug.h"

	
                         
                         
CCache::CCache(CDatabase* miDb)
	: m_RsArticulo(miDb)
	, m_RsMaquinas(miDb)
	, m_RsCliente(miDb)
	, m_RsEntregas(miDb)
	, m_RsArtMol(miDb)
	, m_RsHistorico(miDb)
	, m_RsCalendario(miDb)
	, m_RsLocales(miDb)
	, m_RsMezclas(miDb)
	, m_RsMoldes(miDb)
	, m_RsMolMaq(miDb)
	, m_RsPedidos(miDb)
	, m_RsPedidosAyer(miDb)
	, m_RsListadoValorado(miDb)
	, m_RsCambiosMoldes(miDb)
	, m_RsMezclasPlanta(miDb)
	, m_RsLisMezclas(miDb)
	
{   
	m_pDB = miDb;
	// Abrimos las tablas
	
	m_RsCliente.Open();
	m_RsEntregas.Open();
	m_RsArticulo.Open();
	m_RsMaquinas.Open();
	m_RsArtMol.Open();
	m_RsHistorico.Open();
	m_RsLocales.Open();
	m_RsMezclas.Open();
	m_RsMoldes.Open();
	m_RsMolMaq.Open();
	m_RsPedidos.Open();
	m_RsListadoValorado.Open();
	m_RsCambiosMoldes.Open();
	m_RsMezclasPlanta.Open();

	// Inicializamos los tama�os de los Arrays  
    
    m_pArrArticulos = new CObArray;
	m_pArrArticulos->SetSize(0, TK_CACHE_ARTIC);
    m_pArrMolMaq = new CObArray;
	m_pArrMolMaq->SetSize(0, TK_CACHE_MOLDES*5);
    m_pArrMoldes = new CObArray;
	m_pArrMoldes->SetSize(0, TK_CACHE_MOLDES);
	m_pArrMaquinas = new CObArray;
	m_pArrMaquinas->SetSize(0, TK_CACHE_MAQ);
    m_pArrOFs = new CObArray;
	m_pArrOFs->SetSize(0, TK_CACHE_ORDMAQ);
	m_pArrMezclas = new CObArray;
	m_pArrMezclas->SetSize(0, TK_CACHE_MEZCLAS);
	m_pArrOFComb = new CObArrayOrd(&OFComb_Bigger , &OFComb_Equal);
	m_pArrOFSeccion = new CObArrayOrd(&OFSeccion_Bigger , &OFSeccion_Equal);
	m_pArrOFSeccion->SetSize(0, TK_CACHE_ORDMAQ);
	m_pArrOFSel = new CObArray();
	m_pArrOFSel->SetSize(0, TK_CACHE_ORDMAQ);
	m_pArrOFAcum = new CObArray();
	m_pArrOFAcum->SetSize(0, TK_CACHE_ORDMAQ);
	m_pArrOFAyer = new CObArray();
	m_pArrOFAyer->SetSize(0, TK_CACHE_ORDMAQ);
	m_pArrCambMold = new CObArray();
	m_pArrCambMold->SetSize(0, TK_CACHE_CAMBMOLD);
	

	IniFillCache();

}

void  
CCache::IniFillCache()
{
// Llenamos el cache
	IniFillArticulos();
	IniFillMaquinas();
	IniFillMolMaq();
	IniFillOFs();
	IniFillOFsAyer();
	IniFillMezclas();

	LinkPointer();
}

void
CCache::EmptyArrays()
{
    int i;   
    for( i=0; i < m_pArrArticulos->GetSize() ; i++ )
    {
		CBufArticulo* pBufArt = (CBufArticulo*) m_pArrArticulos->GetAt(i);
		ASSERT( pBufArt->IsKindOf( RUNTIME_CLASS( CBufArticulo ) ) );
		delete pBufArt;    	
    }      
    m_pArrArticulos->RemoveAll();

    for( i=0; i < m_pArrMolMaq->GetSize() ; i++ )
    {
		CBufMolMaq* pBufMol = (CBufMolMaq*) m_pArrMolMaq->GetAt(i);
		ASSERT( pBufMol->IsKindOf( RUNTIME_CLASS( CBufMolMaq ) ) );
		delete pBufMol;    	
    }      
    m_pArrMolMaq->RemoveAll();

	for( i=0; i < m_pArrMoldes->GetSize() ; i++ )
    {
		CBufMolde* pBufMol = (CBufMolde*) m_pArrMoldes->GetAt(i);
		ASSERT( pBufMol->IsKindOf( RUNTIME_CLASS( CBufMolde ) ) );
		delete pBufMol;    	
    }      
    m_pArrMoldes->RemoveAll();

	for( i=0; i < m_pArrMaquinas->GetSize() ; i++ )
    {
		CBufMaquina* pBufMaq = (CBufMaquina*) m_pArrMaquinas->GetAt(i);
		ASSERT( pBufMaq->IsKindOf( RUNTIME_CLASS( CBufMaquina ) ) );
		delete pBufMaq;    	
    }      
    m_pArrMaquinas->RemoveAll();

	for( i=0; i < m_pArrMezclas->GetSize() ; i++ )
    {
		CBufMezcla* pBufMaq = (CBufMezcla*) m_pArrMezclas->GetAt(i);
		ASSERT( pBufMaq->IsKindOf( RUNTIME_CLASS( CBufMezcla ) ) );
		delete pBufMaq;    	
    }      
    m_pArrMezclas->RemoveAll();

	for( i=0; i < m_pArrOFComb->GetSize() ; i++ )
    {
		COFComb* pBufMaq = (COFComb*) m_pArrOFComb->GetAt(i);
		ASSERT( pBufMaq->IsKindOf( RUNTIME_CLASS( COFComb ) ) );
		delete pBufMaq;    	
    }      
    m_pArrOFComb->RemoveAll();

	
	m_pArrOFSeccion->RemoveAll();
	m_pArrOFSel->RemoveAll();
	m_pArrOFAcum->RemoveAll();

	ClearOFs();
    m_pArrOFs->RemoveAll();

    for( i=0; i < m_pArrOFAyer->GetSize() ; i++ )
	{
		CBufOF* pBufOF = (CBufOF*) m_pArrOFAyer->GetAt(i);
		ASSERT( pBufOF->IsKindOf( RUNTIME_CLASS( CBufOF ) ) );
		delete pBufOF;    	
    }      
    m_pArrOFAyer->RemoveAll();
	
    for( i=0; i < m_pArrCambMold->GetSize() ; i++ )
	{
		CBufCambiosMoldes* pBufCambiosMoldes = (CBufCambiosMoldes*) m_pArrCambMold->GetAt(i);
		ASSERT( pBufCambiosMoldes->IsKindOf( RUNTIME_CLASS( CBufCambiosMoldes ) ) );
		delete pBufCambiosMoldes;    	
    }      
    m_pArrCambMold->RemoveAll();
}
	
CCache::~CCache()
{
	m_RsArticulo.Close();
	m_RsMaquinas.Close();
	m_RsCliente.Close();
	m_RsEntregas.Close();
	m_RsArtMol.Close();
	m_RsHistorico.Close();
	m_RsLocales.Close();
	m_RsMezclas.Close();
	m_RsMoldes.Close();
	m_RsMolMaq.Close();
	m_RsPedidos.Close();
	m_RsListadoValorado.Close();
	m_RsCambiosMoldes.Close();
	m_RsMezclasPlanta.Close();
 
	EmptyArrays();

    delete m_pArrArticulos;
	delete m_pArrMoldes;
	delete m_pArrMolMaq;
	delete m_pArrMaquinas;
	delete m_pArrMezclas;
	delete m_pArrOFComb;
	delete m_pArrOFSeccion;	
	delete m_pArrOFSel;		
	delete m_pArrOFAcum;		
    delete m_pArrOFs;
    delete m_pArrOFAyer;
    delete m_pArrCambMold;

}          
               
void
CCache::ClearOFs()
{
    for(int i=0; i < m_pArrOFs->GetSize() ; i++ )
	{
		CBufOF* pBufOF = (CBufOF*) m_pArrOFs->GetAt(i);
		ASSERT( pBufOF->IsKindOf( RUNTIME_CLASS( CBufOF ) ) );
		delete pBufOF;    	
    }      
    m_pArrOFs->RemoveAll();
}

CObArray*
CCache::GetArrBufArt()
{	  
	return m_pArrArticulos;
}

void 
CCache::SerializeOFs(CArchive& ar)
{
	m_pArrOFs->Serialize(ar);
}


int 
CCache::GetNumOF()
{
	if (g_VerOF.m_bAcumOFs)
	{
		return m_pArrOFAcum->GetSize();
	} 
	else if (g_VerOF.Selec())
	{
		return m_pArrOFSel->GetSize();
	}
	else // No importa por qu� est� ordenado, el n�mero ser� el mismo
	{
		return m_pArrOFs->GetSize();
	}
}


CBufOF* 
CCache::GetpOFAt( int p_iInd )
{
	
	if (g_VerOF.m_bAcumOFs)
	{
		return (CBufOF*) m_pArrOFAcum->GetAt(p_iInd);
	} 
	else if (g_VerOF.Selec())
	{
		return (CBufOF*) (m_pArrOFSel->GetAt(p_iInd));
	}
	else if (g_VerOF.m_OrdenOF == Seccion)
	{	
		return (CBufOF*) (m_pArrOFSeccion->GetAt(p_iInd));
	}
	else
	{
		return (CBufOF*) (m_pArrOFs->GetAt(p_iInd));
	}
}



void
CCache::AssignInacts(CProgMaq& p_PM)
{
	// Funci�n para introducir los datos de calendario, en forma de Inactividades

	BOOL BHasRecords = FALSE;
	CString sFilter;
    
	
	sFilter.Format( "Fecha >= #%s# AND Fecha <= #%s# AND ID = '%s'"
					, FormatFec (p_PM.GetFecIni(), FechaDB) 
					, FormatFec (p_PM.GetFecFin(), FechaDB)
					, p_PM.GetsID() );
    m_RsCalendario.m_strFilter = sFilter; 
	m_RsCalendario.m_strSort = "ID,Fecha";
	
	if (m_RsCalendario.IsOpen()) m_RsCalendario.Close();
	if (m_RsCalendario.Open())
		if (m_RsCalendario.GetRecordCount())
		{
			m_RsCalendario.MoveFirst();
			BHasRecords = TRUE;
		}

		 
	// Primero eliminamos las posibles inactividades que ya hubiese
	if (p_PM.m_pArrInacts)
	{

		for ( int i=0; i< p_PM.m_pArrInacts->GetSize(); i++)
		{                                  
			CAbSpan* pAbs = (CAbSpan *) p_PM.m_pArrInacts->GetAt(i);
			ASSERT( pAbs->IsKindOf( RUNTIME_CLASS( CAbSpan ) ) );
			delete pAbs;
		}
		delete p_PM.m_pArrInacts;	
		p_PM.m_pArrInacts = NULL;
	}

	if (!p_PM.m_pArrInacts) // A�adido para evitar dobles definiciones
	{
		p_PM.m_pArrInacts = new CObArray();
		p_PM.m_pArrInacts->SetSize(0, TK_CACHE_INACT);
	}

	BOOL EnInact = FALSE;	// Presuponemos que partimos de situacion de
							// actividad

	CTime FecI = p_PM.GetFecIni();

	CAbSpan* pAbSpan = NULL;

	while ( FecI < p_PM.GetFecFin() || IsSameDay(FecI, p_PM.GetFecFin()) )
	{ 
		BOOL Turnos[3];
		if ( BHasRecords && IsSameDay( FecI, m_RsCalendario.m_Fecha ) )
		{
			Turnos[0] = m_RsCalendario.m_Turno1;
			Turnos[1] = m_RsCalendario.m_Turno2;
			Turnos[2] = m_RsCalendario.m_Turno3;
		} else		// Valor por defecto
		{
			GetDefaultTurnos(FecI, Turnos);
		}
		for (int i = 0; i < TK_NUM_TURNOS; i++)
		{
			if (Turnos[i])	// Si el turno es activo
			{
				if (EnInact)	// Si est�bamos en inactividad
				{
					EnInact = FALSE;		// Cambiamos a actividad
					// Ponemos la fecha de fin dependiendo del turno.
					pAbSpan->SetFecFin(	CTime ( FecI.GetYear(),
												FecI.GetMonth(),
												FecI.GetDay(),
										( i == 0 ) ? TK_TURNO3_FIN : ( i == 1) ? TK_TURNO1_FIN: TK_TURNO2_FIN,
												0,
												0 ));
					// Cerramos la inactividad y la guardamos
					p_PM.m_pArrInacts->Add(pAbSpan);
				}
			}
			else	// Si el turno es inactivo
			{
				if (!EnInact)	// Si no est�bamos en inactividad
				{
					EnInact = TRUE;		//Cambiamos a inactividad
					pAbSpan = new CAbSpan;  // Creamos una nueva inactividad
					pAbSpan->SetFecIni(	CTime(  FecI.GetYear(),
												FecI.GetMonth(),
												FecI.GetDay(),
										( i == 0 ) ? TK_TURNO3_FIN : ( i == 1) ? TK_TURNO1_FIN: TK_TURNO2_FIN,
												0,
												0 ));
				}
			}
		}	// End For
		if ( BHasRecords && IsSameDay( FecI, m_RsCalendario.m_Fecha ) )
		{
			m_RsCalendario.MoveNext();
			if (m_RsCalendario.IsEOF()) BHasRecords = FALSE;
		}
		FecI = AddDays(FecI, 1);
		
	}	// End While
	if (EnInact)		// Si tenemos una inactividad sin cerrar
	{
		// La cerramos con una fecha adecuada
		pAbSpan->SetFecFin(	CTime( FecI.GetYear(),
								FecI.GetMonth(),
								FecI.GetDay(),
								TK_TURNO3_FIN,
								0,
								0 ));
		// Y la guardamos
		p_PM.m_pArrInacts->Add(pAbSpan);
	}

}


// GetArrMaquinas : Nos da un Array de * a Strings, vac�o, y lo llenamos con 
// los id de m�quinas programables en orden de programa. El recordset de m�quinas est�
// preparado para acceso directo, por lo que hay que cerrarlo y abrirlo para
// poder acceder secuencialmente. Esto no est� documentado pero parece que
// funciona. Adem�s se comprueba que los nombres de dos m�quinas cargadas no sean
// iguales, porque a veces se busca por nombre
int 
CCache::GetArrMaquinas( CStringArray& p_ArrMaquinas )
{
    int NumMaq = 0;
	CStringArray ArrNomMaq;
	int bUniqName = FALSE;
	m_RsMaquinas.Close();
	m_RsMaquinas.m_strFilter = "";
	m_RsMaquinas.m_strSort = "ID";		// Ordenamos por ID

	if (m_RsMaquinas.Open())
	{
		m_RsMaquinas.MoveFirst();
 		
		while (!m_RsMaquinas.IsEOF())
		{
			bUniqName = TRUE;	
			for (int i = 0; i< NumMaq; i++)
			{
				CString sDesc = ArrNomMaq.GetAt(i);
				if (sDesc == m_RsMaquinas.m_Nombre)
				{
					bUniqName = FALSE;
					break;
				}
				}
			if (!bUniqName)
			{
					CString sForm = STRID( IDS_ERR_NOMAQNOM );
	
				CString sMsg =  sForm + m_RsMaquinas.m_Nombre + ").";
				AfxMessageBox(sMsg);
			}
			else
			{
				p_ArrMaquinas.Add(m_RsMaquinas.m_ID);
				ArrNomMaq.Add(m_RsMaquinas.m_Nombre);
				NumMaq++;                           
			}
	
			m_RsMaquinas.MoveNext();
		}
	}            
	m_RsMaquinas.Close();
	m_RsMaquinas.m_strFilter = "";
	m_RsMaquinas.Open();       
	return NumMaq;
}

// GetArrOFs : Nos da un Array de punteros a objetos y lo llenamos con las OFs.

int 
CCache::GetArrOFs( CObArray& p_ArrOFs )
{
	for (int i = 0; i < m_pArrOFs->GetSize(); i++)
	{
		p_ArrOFs.Add( m_pArrOFs->GetAt(i));
	}

	return m_pArrOFs->GetSize();
}

IMPLEMENT_SERIAL(CComp, CObject, 1)    

BOOL 
CComp::operator <(const CComp& p_Comp) const
{
	if ( m_sIDArticulo < p_Comp.m_sIDArticulo || 
		 ( m_sIDArticulo == p_Comp.m_sIDArticulo && m_FecNec < p_Comp.m_FecNec ) )
		return TRUE;
			
	return FALSE;					
}

BOOL 
CComp::operator ==(const CComp& p_Comp) const
{
	if ( m_sIDArticulo == p_Comp.m_sIDArticulo && m_FecNec == p_Comp.m_FecNec )
		return TRUE;
			
	return FALSE;					
}

CComp::CComp(CBufOF* pBufOF)
{
	m_sIDArticulo = pBufOF->m_sIDArticulo;
	m_sIDCliente = pBufOF->m_sNomcli;
	m_FecNec = pBufOF->m_FecNec;
	m_dCantAyer = pBufOF->m_dNoProg;
	m_dCantHoy = 0;
	m_lSeccion = pBufOF->m_lSeccion;
}

CComp::CComp(CComp* pComp)
{
	if (pComp)
	{
		m_sIDArticulo = pComp->m_sIDArticulo;
		m_sIDCliente = pComp->m_sIDCliente;
		m_FecNec = pComp->m_FecNec;
		m_dCantAyer = pComp->m_dCantAyer;
		m_dCantHoy = pComp->m_dCantHoy;
		m_lSeccion = pComp->m_lSeccion;
	}
}

void CCache::GetArrAcum(CObArray *p_pArrOF, CObArray *p_pArrAcum)
{
	p_pArrAcum->RemoveAll();
	int iLim = p_pArrOF->GetSize();
	CBufOF* pBufOF = (CBufOF*) p_pArrOF->GetAt(0);
	CString sIDAnt = pBufOF->m_sIDArticulo;
	CTime FecAnt = pBufOF->m_FecNec;
	CComp* pComp = new CComp(pBufOF);
	p_pArrAcum->Add(pComp);
	for(int i=1; i < iLim; i++)
	{
		pBufOF = (CBufOF*) p_pArrOF->GetAt(i);
		if (pBufOF->m_sIDArticulo == sIDAnt && pBufOF->m_FecNec == FecAnt)
		{
			pComp->m_dCantAyer = pBufOF->m_dNoProg;
		} else
		{
			pComp = new CComp(pBufOF);
			sIDAnt = pBufOF->m_sIDArticulo;
			FecAnt = pBufOF->m_FecNec;
			p_pArrAcum->Add(pComp);
		}
	}
}

// GetArrConsOF : Nos da un Array de punteros a objetos y lo llenamos con las OFs
// que resultan de comparar el array de OFs de hoy con el de ayer.

int 
CCache::GetArrConsOF( CObArray& p_ArrComp )
{
	
	p_ArrComp.RemoveAll();
	
	// Hacemos dos nuevos arrays, con los acumulados diarios.
	CObArray ArrHoy;
	CObArray ArrAyer;
	
	GetArrAcum(m_pArrOFs, &ArrHoy);
	GetArrAcum(m_pArrOFAyer, &ArrAyer);
	
	int iLimHoy = ArrHoy.GetSize();
	int iLimAyer = ArrAyer.GetSize();
	int j = 0;
	BOOL bFinHoy = (j >= iLimHoy);
	for (int i=0; i < iLimAyer; i++)
	{
		bFinHoy = (j >= iLimHoy);
		CComp* pCompAyer = (CComp*) ArrAyer.GetAt(i);
		CComp* pCompHoy = (bFinHoy) ? NULL : (CComp*) ArrHoy.GetAt(j);
		if (bFinHoy || (*pCompAyer) < (*pCompHoy))  // Si es menor, es que ese dia no est� hoy
		{
			if (pCompAyer->m_dCantAyer > 0)
			{
				CComp* pComp = new CComp(pCompAyer);
				p_ArrComp.Add(pComp);
			}
		} else if ((*pCompAyer) == (*pCompHoy))
		{
			if (pCompAyer->m_dCantAyer != pCompHoy->m_dCantAyer && 
				( pCompHoy->m_dCantAyer > 0 || pCompAyer->m_dCantAyer > 0) )
			{
				CComp* pComp = new CComp(pCompAyer);
				pComp->m_dCantHoy = pCompHoy->m_dCantAyer;
				p_ArrComp.Add(pComp);
			}
			j++;
		} else // Es que es mayor
		{
			if (pCompHoy->m_dCantAyer > 0)
			{
				CComp* pComp = new CComp(pCompHoy);
				pComp->m_dCantHoy = pCompHoy->m_dCantAyer;
				pComp->m_dCantAyer = 0;
				p_ArrComp.Add(pComp);
			}
			j++;
			i--;
		}
	}
	for ( ; j < iLimHoy; j++)
	{
		CComp* pCompHoy = (bFinHoy) ? NULL : (CComp*) ArrHoy.GetAt(j);
		if (pCompHoy->m_dCantAyer > 0)
		{
			CComp* pComp = new CComp(pCompHoy);
			pComp->m_dCantHoy = pCompHoy->m_dCantAyer;
			pComp->m_dCantAyer = 0;
			p_ArrComp.Add(pComp);
		}
		
	}
    for( i=0; i < ArrAyer.GetSize() ; i++ )
    {
		CComp* pComp = (CComp*) ArrAyer.GetAt(i);
		delete pComp;    	
    }      
	for( i=0; i < ArrHoy.GetSize() ; i++ )
    {
		CComp* pComp = (CComp*) ArrHoy.GetAt(i);
		delete pComp;    	
    }      
	
	
	return p_ArrComp.GetSize();
}

// GetArrGFHs : Nos da un Array de * a Strings, vac�o, y lo llenamos con 
// los GFH programables en orden de programa. El recordset de GFHs est�
// preparado para acceso directo, por lo que hay que cerrarlo y abrirlo para
// poder acceder secuencialmente. Esto no est� documentado pero parece que
// funciona.
/*
int 
CCache::GetArrGFHs( CStringArray& p_ArrGFHs )
{

  int NumGFH = 0;
  m_RsGFH.Close();
  m_RsGFH.m_strFilter = "";
  m_RsGFH.m_strSort = "ID";
  if (m_RsGFH.Open())
  {
		m_RsGFH.MoveFirst();
		
		  while (!m_RsGFH.IsEOF())
		  {
		  p_ArrGFHs.Add(m_RsGFH.m_ID);
		  NumGFH++;                           
		  m_RsGFH.MoveNext();
		  } 
		  }            
		  m_RsGFH.Close();
		  m_RsGFH.m_strFilter = "";
		  m_RsGFH.Open();       
		  return NumGFH;
		  }
*/

// GetArrOrdBloques : Nos da un Array Ordenado de * a Objetos, vac�o, y lo llenamos con 
// el Bloque indicado, desde la serie hasta la serie indicadas. El recordset de Bloques
// est� cerrado normalmente, as� que hay que abrirlo. El objeto utilizado para llenar el
// Array ser� CBufOFs
/*int
CCache::GetArrOrdBlq( CObArrayOrd& p_aoBloques , int p_iBloque, int p_iDesSer, int p_iHasSer)
{
	return 0;
}
*/

void
CCache::IniFillArticulos()
{
	m_RsArticulo.m_strFilter = "";
	m_RsArticulo.m_strSort = "ID";
	
	m_RsListadoValorado.m_strFilter = "";
	m_RsListadoValorado.m_strSort = "Articulo";

	// TODO : Ordenar tambien por campo Orden
	
	m_RsArtMol.m_strFilter = ""; 
	m_RsArtMol.m_strSort = "IDArticulo, Orden";

	m_RsMoldes.m_strFilter = "";
	m_RsMoldes.m_strSort = "ID";
                                
	m_RsMolMaq.m_strFilter = "";
	m_RsMolMaq.m_strSort = "IDMolde";
	
	if (m_RsArticulo.IsOpen()) m_RsArticulo.Close();
	if (m_RsListadoValorado.IsOpen()) m_RsListadoValorado.Close();
	if (m_RsArtMol.IsOpen()) m_RsArtMol.Close();
	if (m_RsMoldes.IsOpen()) m_RsMoldes.Close();
	if (m_RsMolMaq.IsOpen()) m_RsMolMaq.Close();
	if (!m_RsArticulo.Open()) return;
	if (!m_RsListadoValorado.Open()) return;
	if (!m_RsArtMol.Open()) return;
	if (!m_RsMoldes.Open()) return;
	if (!m_RsMolMaq.Open()) return;

//	if (!m_RsArticulo.GetRecordCount()) return;
//	if (!m_RsArtMol.GetRecordCount()) return;
//	if (!m_RsMoldes.GetRecordCount()) return;
//	if (!m_RsMolMaq.GetRecordCount()) return;
	
	if (m_RsArticulo.GetRecordCount()) m_RsArticulo.MoveFirst();
	if (m_RsListadoValorado.GetRecordCount()) m_RsListadoValorado.MoveFirst();
	if (m_RsArtMol.GetRecordCount()) m_RsArtMol.MoveFirst();
	if (m_RsMoldes.GetRecordCount()) m_RsMoldes.MoveFirst();
	if (m_RsMolMaq.GetRecordCount()) m_RsMolMaq.MoveFirst();
		 		
	// A�adimos el art�culo vac�o de Paradas.
	CBufArticulo* pNewArticulo = new CBufArticulo();
	pNewArticulo->m_dPCAct = 0;
	pNewArticulo->m_dPHAct = 1;
	pNewArticulo->m_sID = pNewArticulo->m_sMezcla = "";
	
	m_pArrArticulos->Add(pNewArticulo);
	while (!m_RsArticulo.IsEOF())
	{   
		if (TRUE)
		{
			CBufArticulo* pNewArticulo = new CBufArticulo(m_RsArticulo);
			while (!m_RsArtMol.IsEOF() && m_RsArticulo.m_ID > m_RsArtMol.m_IDArticulo) m_RsArtMol.MoveNext();
			if (m_RsArtMol.IsEOF()) m_RsArtMol.m_IDArticulo = "";
			
			while (!m_RsArtMol.IsEOF() && m_RsArticulo.m_ID == m_RsArtMol.m_IDArticulo)
			{
				CBufArtMol* pNewArtMol = new CBufArtMol(m_RsArtMol);
				ASSERT_VALID(pNewArticulo->m_pArrArtMol);
				pNewArticulo->m_pArrArtMol->Add(pNewArtMol);   
				m_RsArtMol.MoveNext();
			}
			
			while (!m_RsListadoValorado.IsEOF() && m_RsArticulo.m_ID > m_RsListadoValorado.m_Articulo.Left(TK_SIZE_CODART)) 
				m_RsListadoValorado.MoveNext();
			
			if (!m_RsListadoValorado.IsEOF() && m_RsArticulo.m_ID == m_RsListadoValorado.m_Articulo.Left(TK_SIZE_CODART)) 
			{
				
				if (m_RsListadoValorado.IsFieldNull(&m_RsListadoValorado.m_P_H_real ))  pNewArticulo->m_LV_dP_H_real = 0;
				else pNewArticulo->m_LV_dP_H_real = m_RsListadoValorado.m_P_H_real;
				if (m_RsListadoValorado.IsFieldNull(&m_RsListadoValorado.m__Rechazos ))  pNewArticulo->m_LV_dRechazos = 0;
				else pNewArticulo->m_LV_dRechazos = m_RsListadoValorado.m__Rechazos;
				if (m_RsListadoValorado.IsFieldNull(&m_RsListadoValorado.m_Total_Horas ))  pNewArticulo->m_LV_lTotal_Horas = 0;
				else pNewArticulo->m_LV_lTotal_Horas = m_RsListadoValorado.m_Total_Horas;
				if (m_RsListadoValorado.IsFieldNull(&m_RsListadoValorado.m_Cantidad_Fabricada ))  pNewArticulo->m_LV_lCantidad_Fabricada = 0;
				else pNewArticulo->m_LV_lCantidad_Fabricada = m_RsListadoValorado.m_Cantidad_Fabricada;
				if (m_RsListadoValorado.IsFieldNull(&m_RsListadoValorado.m_Cantidad_Rechazada ))  pNewArticulo->m_LV_lCantidad_Rechazada = 0;
				else pNewArticulo->m_LV_lCantidad_Rechazada = m_RsListadoValorado.m_Cantidad_Rechazada;
				if (m_RsListadoValorado.IsFieldNull(&m_RsListadoValorado.m_Cliente ))  pNewArticulo->m_LV_sCliente = "";
				else pNewArticulo->m_LV_sCliente = m_RsListadoValorado.m_Cliente;
			}
			
			m_pArrArticulos->Add(pNewArticulo);
			m_RsArticulo.MoveNext();
		}
	}            
	m_RsArticulo.Close();
	m_RsArticulo.m_strFilter = "";
	m_RsArtMol.Close();
	m_RsArtMol.m_strFilter = "";

// Ahora metemos en el cache los moldes, para lo que hay que acceder a ArtMol por Molde

	m_RsArtMol.m_strFilter = "";
	m_RsArtMol.m_strSort = "IDMolde";
	if (!m_RsArtMol.Open()) return;
	if (m_RsArtMol.GetRecordCount()) m_RsArtMol.MoveFirst();
	
	while (!m_RsMoldes.IsEOF())
	{   
		if (TRUE)
		{
			CBufMolde* pNewMoldes = new CBufMolde(m_RsMoldes);
			while (!m_RsArtMol.IsEOF() && m_RsMoldes.m_ID > m_RsArtMol.m_IDMolde) m_RsArtMol.MoveNext();
			if (m_RsArtMol.IsEOF()) m_RsArtMol.m_IDMolde = "";
			
			while (!m_RsArtMol.IsEOF() && m_RsMoldes.m_ID == m_RsArtMol.m_IDMolde)
			{
				CBufArtMol* pNewArtMol = new CBufArtMol(m_RsArtMol);
				ASSERT_VALID(pNewMoldes->m_pArrMolArt);
				pNewMoldes->m_pArrMolArt->Add(pNewArtMol);   
				m_RsArtMol.MoveNext();
			}
		
			while (!m_RsMolMaq.IsEOF() && m_RsMoldes.m_ID > m_RsMolMaq.m_IDMolde) m_RsMolMaq.MoveNext();
			if (m_RsMolMaq.IsEOF()) m_RsMolMaq.m_IDMolde = "";
			
			while (!m_RsMolMaq.IsEOF() && m_RsMoldes.m_ID == m_RsMolMaq.m_IDMolde)
			{
				CBufMolMaq* pNewMolMaq = new CBufMolMaq(m_RsMolMaq);
				ASSERT_VALID(pNewMoldes->m_pArrMolMaq);
				pNewMoldes->m_pArrMolMaq->Add(pNewMolMaq);   
				m_RsMolMaq.MoveNext();
			}
		
			m_pArrMoldes->Add(pNewMoldes);
			m_RsMoldes.MoveNext();
		}
	}            
	m_RsMoldes.Close();
	m_RsMoldes.m_strFilter = "";
	m_RsArtMol.Close();
	m_RsArtMol.m_strFilter = "";
	m_RsMolMaq.Close();
	m_RsMolMaq.m_strFilter = "";

}
void CCache::LinkPointer()
{
	// Recorremos los articulos
	int iLim = m_pArrArticulos->GetSize();
	for(int i = 0; i < iLim ; i++)
	{
		CBufArticulo* pBufArticulo = (CBufArticulo*) m_pArrArticulos->GetAt(i);
		ASSERT_VALID(pBufArticulo);
		// Primero buscamos las mezclas
		pBufArticulo->m_pBufMezcla = FindpMezcla( pBufArticulo->m_sMezcla );
		// Y luego las relaciones con los modles
		int iLimArtMol = pBufArticulo->m_pArrArtMol->GetSize();
		for (int j = 0; j < iLimArtMol; j++)
		{
			CBufArtMol* pBufArtMol = (CBufArtMol*) pBufArticulo->m_pArrArtMol->GetAt(j);
			ASSERT_VALID(pBufArtMol);
			pBufArtMol->m_pBufMolde = FindpMolde( pBufArtMol->m_sIDMolde );
			
		}
	}
	// Y ahora recorremos los moldes
	iLim = m_pArrMoldes->GetSize();
	for( i = 0; i < iLim ; i++)
	{
		CBufMolde* pBufMolde = (CBufMolde*) m_pArrMoldes->GetAt(i);
		ASSERT_VALID(pBufMolde);
		int iLimMolArt = pBufMolde->m_pArrMolArt->GetSize();
		for (int j = 0; j < iLimMolArt; j++)
		{
			CBufArtMol* pBufArtMol = (CBufArtMol*) pBufMolde->m_pArrMolArt->GetAt(j);
			ASSERT_VALID(pBufArtMol);
			pBufArtMol->m_pBufArticulo = FindpArticulo( pBufArtMol->m_sIDArticulo );
			
		}

		int iLimMolMaq = pBufMolde->m_pArrMolMaq->GetSize();
		for ( j = 0; j < iLimMolMaq; j++)
		{
			CBufMolMaq* pBufMolMaq = (CBufMolMaq*) pBufMolde->m_pArrMolMaq->GetAt(j);
			ASSERT_VALID(pBufMolMaq);
			pBufMolMaq->m_pBufMaquina = FindpMaquina( pBufMolMaq->m_sIDMaquina );
			
		}

	}
	
	// Y los moldes-m�quinas
	int iLimMolMaq = m_pArrMolMaq->GetSize();
	for (int j = 0; j < iLimMolMaq; j++)
	{
		CBufMolMaq* pBufMolMaq = (CBufMolMaq*) m_pArrMolMaq->GetAt(j);
		ASSERT_VALID(pBufMolMaq);
		pBufMolMaq->m_pBufMaquina = FindpMaquina( pBufMolMaq->m_sIDMaquina );
	}


}

void
CCache::IniFillMaquinas()
{

	m_RsMaquinas.m_strFilter = "";
	m_RsMaquinas.m_strSort = "ID";
                                
	if (m_RsMaquinas.IsOpen()) m_RsMaquinas.Close();
	if (!m_RsMaquinas.Open()) return;
	if (!m_RsMaquinas.GetRecordCount()) return;
	
	m_RsMaquinas.MoveFirst();
		 		
	while (!m_RsMaquinas.IsEOF())
	{   
		CBufMaquina* pNewMaquinas = new CBufMaquina(m_RsMaquinas);
		m_pArrMaquinas->Add(pNewMaquinas);
		m_RsMaquinas.MoveNext();
	}            
	m_RsMaquinas.Close();
	m_RsMaquinas.m_strFilter = "";

}

void
CCache::IniFillMolMaq()
{

	m_RsMolMaq.m_strFilter = "";
	m_RsMolMaq.m_strSort = "IDMaquina, Prioridad";
                                
	if (m_RsMolMaq.IsOpen()) m_RsMolMaq.Close();
	if (!m_RsMolMaq.Open()) return;
	if (!m_RsMolMaq.GetRecordCount()) return;
	
	m_RsMolMaq.MoveFirst();
		 		
	while (!m_RsMolMaq.IsEOF())
	{   
		CBufMolMaq* pNewMolMaq = new CBufMolMaq(m_RsMolMaq);
		m_pArrMolMaq->Add(pNewMolMaq);
		m_RsMolMaq.MoveNext();
	}            
	m_RsMolMaq.Close();
	m_RsMolMaq.m_strFilter = "";

}

void 
CCache::IniFillOFs()
{

	m_RsPedidos.m_strFilter = "";
	m_RsPedidos.m_strSort = "IDArticulo, FecNec";
	if (m_RsPedidos.IsOpen()) m_RsPedidos.Close();
	if (m_RsPedidos.Open())
	{
		int iCnt = m_RsPedidos.GetRecordCount();
		if (iCnt)
		{
			m_RsPedidos.MoveFirst();
		 		
			while (!m_RsPedidos.IsEOF())
			{   
				CBufOF* pBufOF = new CBufOF( m_RsPedidos );
				m_pArrOFs->Add(pBufOF);
				// Lo a�adimos tambien a la ordenacion por seccion
				m_pArrOFSeccion->Add(pBufOF);
				m_RsPedidos.MoveNext();
			} 

		}
	}
	m_RsPedidos.Close();
	// Ahora calculamos los acumulados
	CString sCodAnt;
	sCodAnt = "";
	BOOL bRep = FALSE;
	long lCantAcum = 0;

	int iLim = m_pArrOFs->GetSize();
	int iComb = 0;
	for (int i = 0; i < iLim; i++)
	{
		CBufOF* pBufOF = (CBufOF*) m_pArrOFs->GetAt(i);
		if (sCodAnt == pBufOF->m_sIDArticulo) bRep = TRUE;
		else bRep = FALSE;
		if (!bRep) lCantAcum = 0;
		lCantAcum += (long) pBufOF->m_dCantPend;
		pBufOF->m_dPendAcum = lCantAcum;
		pBufOF->m_dNoProg = pBufOF->m_dPendAcum - 
							pBufOF->m_dCantAlmac -
							pBufOF->m_dCantCurso -
		//					pBufOF->m_dCantStockSeguridad -
							pBufOF->m_dCantObsoletos 
							; 
		pBufOF->m_dNoCubierta = pBufOF->m_dPendAcum - 
							pBufOF->m_dCantAlmac -
							pBufOF->m_dCantCurso -
		//					pBufOF->m_dCantStockSeguridad -
							pBufOF->m_dCantObsoletos 
							; 
		
		//					(pBufOF->m_dCantAlmac > 0 ? pBufOF->m_dCantAlmac : 0) -
		//					(pBufOF->m_dCantCurso > 0 ? pBufOF->m_dCantCurso : 0); 
		//Ahora calculamos un array ordenado de punteros a ordenes, para encontrarlas mas r�pido
		// Este array es combinado, es decir hay un solo elemento por cada art�culo, se�alando
		// el �ndice superior e inferior de OFs
		if (!bRep)
		{
			COFComb* pOFComb = new COFComb;
			pOFComb->m_sID = pBufOF->m_sIDArticulo;
			pOFComb->m_iIni = i;
			m_pArrOFComb->Add(pOFComb);
			if (iComb > 0)
			{
				COFComb* pOFCombAnt = (COFComb*) m_pArrOFComb->GetAt(iComb - 1);
				pOFCombAnt->m_iFin = i - 1;
			}

			iComb++;
		}
			
		sCodAnt = pBufOF->m_sIDArticulo;
	}
	COFComb* pOFCombAnt = (COFComb*) m_pArrOFComb->GetAt(iComb - 1);
	pOFCombAnt->m_iFin = i - 1;
	

}

void 
CCache::IniFillOFsAyer()
{

	m_RsPedidosAyer.m_strFilter = "";
	m_RsPedidosAyer.m_strSort = "IDArticulo, FecNec";
	if (m_RsPedidosAyer.IsOpen()) m_RsPedidosAyer.Close();
	if (m_RsPedidosAyer.Open())
	{
		int iCnt = m_RsPedidosAyer.GetRecordCount();
		if (iCnt)
		{
			m_RsPedidosAyer.MoveFirst();
		 		
			while (!m_RsPedidosAyer.IsEOF())
			{   
				CBufOF* pBufOF = new CBufOF( m_RsPedidosAyer );
				m_pArrOFAyer->Add(pBufOF);
				m_RsPedidosAyer.MoveNext();
			} 

		}
	}
	m_RsPedidosAyer.Close();
	// Ahora calculamos los acumulados
	CString sCodAnt;
	sCodAnt = "";
	BOOL bRep = FALSE;
	long lCantAcum = 0;

	int iLim = m_pArrOFAyer->GetSize();
	int iComb = 0;
	for (int i = 0; i < iLim; i++)
	{
		CBufOF* pBufOF = (CBufOF*) m_pArrOFAyer->GetAt(i);
		CBufArticulo* pBufArt = NULL;
		if (sCodAnt == pBufOF->m_sIDArticulo) bRep = TRUE;
		else bRep = FALSE;
		if (!bRep) 
		{
			lCantAcum = 0;
			pBufArt = FindpArticulo(pBufOF->m_sIDArticulo);
		}
		lCantAcum += (long) pBufOF->m_dCantPend;
		pBufOF->m_dPendAcum = lCantAcum;
		pBufOF->m_dNoProg = pBufOF->m_dPendAcum - 
							pBufOF->m_dCantAlmac -
							pBufOF->m_dCantCurso -
//							pBufOF->m_dCantStockSeguridad -
							pBufOF->m_dCantObsoletos 
							;
		pBufOF->m_dNoCubierta = pBufOF->m_dPendAcum - 
							pBufOF->m_dCantAlmac -
							pBufOF->m_dCantCurso -
//							pBufOF->m_dCantStockSeguridad -
							pBufOF->m_dCantObsoletos 
							;
		if (pBufArt) 
		{
		//	pBufOF->m_dNoProg -= pBufArt->m_LV_lCantidad_Fabricada; 
		}
		sCodAnt = pBufOF->m_sIDArticulo;

	}	

}

void 
CCache::IniFillMezclas()
{

	CString sFilter;
	BOOL bEntregas = TRUE;

	m_RsMezclas.m_strFilter = "";
	m_RsMezclas.m_strSort = "ID";
	if (m_RsMezclas.IsOpen()) m_RsMezclas.Close();
	if (!m_RsMezclas.Open()) return;

	m_RsEntregas.m_strFilter = "";
	m_RsEntregas.m_strSort = "IDMezcla";
	if (m_RsEntregas.IsOpen()) m_RsEntregas.Close();
	if (!m_RsEntregas.Open()) bEntregas = FALSE;
	
	int iCnt = m_RsMezclas.GetRecordCount();
	if (iCnt)
	{
		m_RsMezclas.MoveFirst();
		
		while (!m_RsMezclas.IsEOF())
		{   
			CBufMezcla* pBufMezcla = new CBufMezcla( m_RsMezclas );

			
			while (!m_RsEntregas.IsEOF() && m_RsMezclas.m_ID > m_RsEntregas.m_IDMezcla) m_RsEntregas.MoveNext();
			if (m_RsEntregas.IsEOF()) m_RsEntregas.m_IDMezcla = "";
			
			while (!m_RsEntregas.IsEOF() && m_RsMezclas.m_ID == m_RsEntregas.m_IDMezcla)
			{
				CBufEntregas* pNewEntregas = new CBufEntregas(m_RsEntregas);
				ASSERT_VALID(pBufMezcla->m_pArrEntregas);
				pBufMezcla->m_pArrEntregas->Add(pNewEntregas);   
				m_RsEntregas.MoveNext();
			}

			
			m_pArrMezclas->Add(pBufMezcla);
			m_RsMezclas.MoveNext();
		} 
		
	}

	m_RsMezclas.Close();
	UpdateMezclasPlanta();
	
}

int
CCache::GetiNumTurnos(CFecTur p_FecTur, const CProgMaq& p_PM, BOOL p_pBTurnos[]) 
{
// Funci�n que devuelve para una fecha y una m�quina, el n�mero de turnos que trabajan

	CTime p_Fec = p_FecTur.GetFec();
	int iTurnos = 0;
	int iDefTurnos = GetDefaultTurnos(p_FecTur, p_pBTurnos);
	
	CString sFilter;
	// Primero miramos si hay un registro en la base de datos.
	// Si no lo hay devolveremos un valor por defecto.
	sFilter.Format( "Fecha = #%s# AND ID = '%s'"
					, FormatFec (p_Fec, FechaDB) 
					, p_PM.GetsID() );
    m_RsCalendario.m_strFilter = sFilter;                                 
	
	if ( m_RsCalendario.IsOpen() )	
		m_RsCalendario.Close();
	if ( m_RsCalendario.Open() )
		if ( m_RsCalendario.GetRecordCount() )
			m_RsCalendario.MoveFirst();
		else 
			return iDefTurnos;

	
	if ( m_RsCalendario.IsEOF() ) return iDefTurnos;
	
	if ( m_RsCalendario.m_Turno1 ) iTurnos++;
	if ( m_RsCalendario.m_Turno2 ) iTurnos++;
	if ( m_RsCalendario.m_Turno3 ) iTurnos++;

	if (p_pBTurnos) 
	{
		p_pBTurnos[0] = m_RsCalendario.m_Turno1;
		p_pBTurnos[1] = m_RsCalendario.m_Turno2;
		p_pBTurnos[2] = m_RsCalendario.m_Turno3;
	}
	
	return iTurnos;
}

void
CCache::SetTurnos(const CFecTur p_FecTur, const CProgMaq* p_pPM)
{
	// Esta funci�n nos indica que en la maquina p_pPM, en la Fecha/Turno p_FecTur
	// la situaci�n de trabajo de ese turno ha cambiado.
	// Lo cambiamos en la base de datos y luego volvemos a crear las inactividades
	// de esa m�quina.
	BOOL BTurnos[TK_NUM_TURNOS];
	int i = GetDefaultTurnos(p_FecTur.GetFec(), BTurnos);
	// Funci�n que devuelve para una fecha y una m�quina, el n�mero de turnos que trabajan
	
	CString sFilter;
	BOOL bNewRec = FALSE;
	sFilter.Format( "Fecha = #%s# AND ID = '%s'"
		, FormatFec (p_FecTur.GetFec(), FechaDB) 
		, p_pPM->GetsID() );
    m_RsCalendario.m_strFilter = sFilter;                                 
	if ( m_RsCalendario.IsOpen() ) 
		m_RsCalendario.Close();
	if (m_RsCalendario.Open())
	{
		if (!m_RsCalendario.CanUpdate())
		{
			AfxMessageBox(STRID(IDS_ERR_NOMODCAL));
			return;
		}
		if (m_RsCalendario.IsBOF() || m_RsCalendario.IsEOF())
		{
			GetDefaultTurnos(p_FecTur, BTurnos);
			bNewRec = TRUE;
			//m_RsCalendario.AddNew();
			m_RsCalendario.m_Fecha = p_FecTur.GetFec();
			m_RsCalendario.m_ID = p_pPM->GetsID();
		} else 
		{
			m_RsCalendario.Edit();
			// Si hay un registro, sus datos suprimen al valor por defecto.
			BTurnos[0] = m_RsCalendario.m_Turno1;
			BTurnos[1] = m_RsCalendario.m_Turno2;
			BTurnos[2] = m_RsCalendario.m_Turno3;
		}
		
		// Cambiamos el estado del Turno seleccionado antes de actualizar
		int iTurno = p_FecTur.GetTurno() - 1;
		ASSERT((iTurno >= 0) && (iTurno <= TK_NUM_TURNOS));
		BTurnos[iTurno] = BTurnos[iTurno] ? FALSE : TRUE;
		m_RsCalendario.m_Turno1 = BTurnos[0];
		m_RsCalendario.m_Turno2 = BTurnos[1];
		m_RsCalendario.m_Turno3 = BTurnos[2];
		
		if (bNewRec)
		{
			m_RsCalendario.Close();
			CString sCmd;
			sCmd.Format("INSERT INTO Calendario VALUES ('%s', #%s#, %d, %d, %d)",
				m_RsCalendario.m_ID,
				FormatFec(m_RsCalendario.m_Fecha, FechaDB),
				m_RsCalendario.m_Turno1,
				m_RsCalendario.m_Turno2,
				m_RsCalendario.m_Turno3
				);
			m_pDB->ExecuteSQL(sCmd);
			
		} else
		{
			if (!m_RsCalendario.Update())
			{
				AfxMessageBox(STRID(IDS_ERR_NOMODCAL));
				return;
			}
			m_RsCalendario.Close();
		}            
	}
}

CBufOF* 
CCache::FindOFNum( long p_lOFNum )
{
	// Busca una orden por el n�mero de OF, NO por el ID �nico
	int iLim = m_pArrOFs->GetSize();
	for( int i = 0; i < iLim ; i++)
	{	
		CBufOF* pBufOF = (CBufOF*) m_pArrOFs->GetAt(i);
		ASSERT( pBufOF->IsKindOf( RUNTIME_CLASS( CBufOF ) ) );
//		if (pBufOF->m_OrdFab == p_lOFNum) return pBufOF;
	}                                            
	return NULL;
}

// Busca una orden por el c�digo de art�culo, se queda con la primera que ecuentra
CBufOF* 
CCache::FindOFArt( const CString& p_sArticulo )
{
	int iLim = m_pArrOFs->GetSize();
	for( int i = 0; i < iLim ; i++)
	{	
		CBufOF* pBufOF = (CBufOF*) m_pArrOFs->GetAt(i);
		ASSERT( pBufOF->IsKindOf( RUNTIME_CLASS( CBufOF ) ) );
		if (pBufOF->m_sIDArticulo == p_sArticulo) return pBufOF;
	}                                            
	return NULL;
}

void
CCache::UpdateOF( const CString& p_sIDArt , int p_iCant)
{
	CBufOF* pBufOF = FindOFArt(p_sIDArt);
	if (!pBufOF) return;
	int iLim = m_pArrOFs->GetSize();
	for( int i = 0; i < iLim ; i++)
	{	
		CBufOF* pBufOF = (CBufOF*) m_pArrOFs->GetAt(i);
		ASSERT( pBufOF->IsKindOf( RUNTIME_CLASS( CBufOF ) ) );
		if (pBufOF->m_sIDArticulo == p_sIDArt)
			pBufOF->m_dCantCurso += p_iCant;
	}                                            


	CString sFilter;
	if (m_RsPedidos.IsOpen()) m_RsPedidos.Close();
	CString strCmd;
	strCmd.Format("UPDATE Pedidos SET CantCurso = CantCurso + %d WHERE IDArticulo = '%s'",
						p_iCant, p_sIDArt );
	m_pDB->ExecuteSQL(strCmd);


}

CBufArticulo*
CCache::AddArticulo (const char* p_IDArticulo)
{
	BOOL BEnBD = TRUE;
	// Primero comprobamos si el identificador ya existe
	for( int i=0; i< m_pArrArticulos->GetSize(); i++)
	{	
		CBufArticulo* pBufArt = (CBufArticulo*) m_pArrArticulos->GetAt(i);
		ASSERT( pBufArt->IsKindOf( RUNTIME_CLASS( CBufArticulo ) ) );
		if (pBufArt->m_sID == p_IDArticulo) return pBufArt;
	}

	return NULL;
/*
	m_RsArticulo.m_IDParam = p_IDArticulo;
	if (!m_RsArticulo.CanRestart()) BEnBD = FALSE;
	if (BEnBD && !m_RsArticulo.Requery()) BEnBD = FALSE;
	if (BEnBD && m_RsArticulo.IsEOF()) BEnBD = FALSE;

	if (!BEnBD)
	{
		CString sMsg;
		CString sForm = STRID( IDS_ERR_NOART );
		
		sMsg.Format( sForm,	p_IDArticulo);
		g_bException = TRUE;
		AfxMessageBox(sMsg);
		ExitProcess(0);
		
	}
	
	CBufArticulo* pNewArticulo = new CBufArticulo(m_RsArticulo);

	ASSERT_VALID (pNewArticulo);
	m_RsArtGFH.m_IDParam = p_IDArticulo;
	if (!m_RsArtGFH.CanRestart()) BEnBD = FALSE;
	if (BEnBD && !m_RsArtGFH.Requery())  BEnBD = FALSE;
	
	if (!BEnBD)
	{
		CString sMsg;
		TRACE(STRID(IDS_ERR_NOGFHART ));
			
		CString sForm = STRID( IDS_ERR_NOGFHART );
		
		sMsg.Format( sForm,	p_IDArticulo);
		g_bException = TRUE;
		AfxMessageBox(sMsg);
		ExitProcess(0);
		
	}
	
	while ( !m_RsArtGFH.IsEOF())
	{ 
		CBufArtGFH* pNewArtGFH = new CBufArtGFH(m_RsArtGFH);
		ASSERT_VALID(pNewArticulo->m_pArrArtGFH);
		pNewArticulo->m_pArrArtGFH->Add(pNewArtGFH);   
		m_RsArtGFH.MoveNext();
	}
	m_RsArtMaq.m_IDParam = p_IDArticulo;
	if (!m_RsArtMaq.CanRestart()) BEnBD = FALSE;
	if (!m_RsArtMaq.Requery()) BEnBD = FALSE;
	if (BEnBD)
	{
		while (!m_RsArtMaq.IsEOF())
		{ 
			CBufArtMaq* pNewArtMaq = new CBufArtMaq(m_RsArtMaq);
			ASSERT_VALID(pNewArticulo->m_pArrArtMaq);
			pNewArticulo->m_pArrArtMaq->Add(pNewArtMaq);
			m_RsArtMaq.MoveNext();
		}
	}
	m_pArrArticulos->Add(pNewArticulo);
	return pNewArticulo;
*/
}

CBufMaquina*
CCache::AddMaquina (const char* p_IDMaquina)
{
	
	// Primero comprobamos si el identificador ya existe
	for( int i=0; i< m_pArrMaquinas->GetSize(); i++)
	{	
		CBufMaquina* pBufMaq = (CBufMaquina*) m_pArrMaquinas->GetAt(i);
		ASSERT( pBufMaq->IsKindOf( RUNTIME_CLASS( CBufMaquina ) ) );
		if (pBufMaq->m_sID == p_IDMaquina) return pBufMaq;
	}

	return NULL;
}

void
CCache::AddOF( CBufOF* p_pOF )
{
}

// GetArrGFHs : Nos da un Array de * a Strings, vac�o, y lo llenamos con 
// los GFH programables en orden de programa. El recordset de GFHs est�
// preparado para acceso directo, por lo que hay que cerrarlo y abrirlo para
// poder acceder secuencialmente. Esto no est� documentado pero parece que
// funciona.
int 
CCache::GetArrGFHs( CStringArray& p_ArrGFHs )
{
	p_ArrGFHs.Add("");
	return 1;
}

// GetArrBloques : Nos da un Array de enteros vacio y lo llenamos con los bloques  
// disponibles en orden de mayor a menor
int
CCache::GetArrBloques( CUIntArray& p_ArrBloques )
{
	return 0;
}


void
CCache::GetMaxMinBlq( int p_iBloque, int& p_iMinBlq, int& p_iMaxBlq)
{
	p_iMinBlq = p_iMaxBlq = 0;
}


CBufOF* 
CCache::AddOF( long p_IDOF , BOOL p_bUpdateFec )
{
	return NULL;
/*
	for( int i=0; i< m_pArrOFs->GetSize(); i++)
	{	
		CBufOF* pBufOF = (CBufOF*) m_pArrOFs->GetAt(i);
		ASSERT( pBufOF->IsKindOf( RUNTIME_CLASS( CBufOF ) ) );
		if (pBufOF->m_ID == p_IDOF) return pBufOF;
	}                                            

	BOOL BEnBD = TRUE;
	
	CString sFilter;
    sFilter.Format("ID = %ld", p_IDOF);
	m_RsBlqLin.m_strFilter = sFilter;
	if (!m_RsBlqLin.Open()) BEnBD = FALSE;
	if (BEnBD) if (!m_RsBlqLin.GetRecordCount()) BEnBD = FALSE;
	if (BEnBD)
	{
		m_RsBlqLin.MoveFirst();
		if (m_RsBlqLin.IsEOF()) BEnBD = FALSE;
	}
	// Si hay que actualizar la fecha de traspaso, lo hacemos ahora
	if (p_bUpdateFec)
	{
		if (!m_RsBlqLin.CanUpdate())
		{	
			TRACE(STRID(IDS_ERR_NOACT));
			AfxMessageBox(STRID(IDS_ERR_NOACT));
		} else
		{
			m_RsBlqLin.Edit();
			m_RsBlqLin.m_FecTrasp = CTime::GetCurrentTime();
			m_RsBlqLin.Update();
		}
	}

	m_RsBlqLin.Close();
	
	if (!BEnBD) 
	{
		CString sMsg;
		CString sForm = STRID( IDS_ERR_NOID );
		
		sMsg.Format( sForm,	p_IDOF);
		g_bException = TRUE;
		AfxMessageBox(sMsg);
		ExitProcess(0);
		
	}
	
	
	CBufOF* pNewBufOF = new CBufOF(m_RsBlqLin);
	m_pArrOFs->Add(pNewBufOF);
	
	return pNewBufOF;
*/

}

// Recibe un codigo de articulo y para este articulo rellena dos Arrays con punteros
// a las m�quinas que pueden fabricarlo, y con qu� moldes
int 
CCache::GetArrMaq(const CString &p_sArticulo, CObArray &p_ArrMaq, CObArray &p_ArrMoldes)
{
	// Vaciamos los arrays
	p_ArrMaq.RemoveAll();
	p_ArrMoldes.RemoveAll();
	// Buscamos el articulo indicado
	CBufArticulo* pBufArticulo = FindpArticulo(p_sArticulo);
	if (pBufArticulo == NULL) return 0;
	// Recorremos los moldes posibles de este articulo
	int iLimArtMol = pBufArticulo->m_pArrArtMol->GetSize();
	for (int i = 0; i < iLimArtMol; i++)
	{
		CBufArtMol* pBufArtMol = (CBufArtMol*) pBufArticulo->m_pArrArtMol->GetAt(i);
		ASSERT_VALID(pBufArtMol);
		CBufMolde* pBufMolde = pBufArtMol->m_pBufMolde;
		if (!pBufMolde) continue;
		int iLimMolMaq = pBufMolde->m_pArrMolMaq->GetSize();
		for (int j = 0; j < iLimMolMaq; j++)
		{
			// Obtenemos las maquinas del molde
			CBufMolMaq* pBufMolMaq = (CBufMolMaq*) pBufMolde->m_pArrMolMaq->GetAt(j);
			ASSERT_VALID(pBufMolMaq);
			// Y a�adimos la maquina al array de maquinas. Nos dan igual los duplicados por el
			// momento.
			if (pBufMolMaq->m_pBufMaquina != NULL)
			{
				p_ArrMaq.Add(pBufMolMaq->m_pBufMaquina);
				p_ArrMoldes.Add(pBufMolde);
			}
		}
	}

	return p_ArrMaq.GetSize();

}

// Recibe un codigo de maquina y para esta maquina rellena un Arrays con punteros
// a objetos CMolMaq que esa m�quina puede realizar, en orden de prioridad
// Si se da una referencia a un c�digo de art�culo, se seleccionan s�lo los moldes
// que pudan fabricar ese art�culo
int 
CCache::GetArrMolMaq(const CString &p_sMaquina, CObArray &p_ArrMolMaq, const CString* p_psIDArt)
{
	// Vaciamos el array
	p_ArrMolMaq.RemoveAll();
	// Buscamos la m�quina indicada
	CBufMaquina* pBufMaquina = FindpMaquina(p_sMaquina);
	if (pBufMaquina == NULL) return 0;
	BOOL bFinMaq = FALSE;
	for (int i=0; i < m_pArrMolMaq->GetSize() ; i++)
	{
		CBufMolMaq* pBufMolMaq = (CBufMolMaq*) m_pArrMolMaq->GetAt(i);
		if ( pBufMolMaq->m_sIDMaquina == p_sMaquina )
		{
			if (p_psIDArt)
			{
				CBufMolde* pBufMolde = FindpMolde(pBufMolMaq->m_sIDMolde);
				int iLim = pBufMolde->m_pArrMolArt->GetSize();
				for (int iArt = 0; iArt < iLim; iArt ++)
				{
					CBufArtMol* pBufArtMol = (CBufArtMol*) pBufMolde->m_pArrMolArt->GetAt(iArt);
					ASSERT( pBufArtMol->IsKindOf( RUNTIME_CLASS( CBufArtMol ) ) );
 
					if (pBufArtMol->m_sIDArticulo == *p_psIDArt)
					{
						p_ArrMolMaq.Add(pBufMolMaq);
					}
				}
			} else
			{
				p_ArrMolMaq.Add(pBufMolMaq);
			}
		}
	}
	return p_ArrMolMaq.GetSize();
}

// Recibe un codigo de maquina y para esta maquina rellena un Arrays con punteros
// a los art�culos 
int 
CCache::GetArrMolArt(const CString &p_sMaquina, CObArray &p_ArrInfoMolArt)
{
	CObArray ArrMoldes;
	CUIntArray ArrPrioridad;
	// Vaciamos los arrays
	for (int iB = 0; iB < p_ArrInfoMolArt.GetSize(); iB++)
	{
		CInfoMolArt* pInfoMolArt = (CInfoMolArt*) p_ArrInfoMolArt.GetAt(iB);
		delete pInfoMolArt;
	}
	p_ArrInfoMolArt.RemoveAll();
	// Buscamos la m�quina indicada
	CBufMaquina* pBufMaquina = FindpMaquina(p_sMaquina);
	if (pBufMaquina == NULL) return 0;
	BOOL bFinMaq = FALSE;
	for (int i=0; i < m_pArrMolMaq->GetSize() ; i++)
	{
		CBufMolMaq* pBufMolMaq = (CBufMolMaq*) m_pArrMolMaq->GetAt(i);
		if ( pBufMolMaq->m_sIDMaquina == p_sMaquina )
		{
			CBufMolde* pBufMolde = FindpMolde(pBufMolMaq->m_sIDMolde);
			ArrMoldes.Add(pBufMolde);
			ArrPrioridad.Add(pBufMolMaq->m_lPrioridad);
			bFinMaq = TRUE;
		}
		if (bFinMaq && pBufMolMaq->m_sIDMaquina != p_sMaquina) // para hacerlo m�s corto, ya que est� ordenado por maq.
			break;
	}
	// Ahora para cada molde buscamos su art�culo
	for ( i = 0; i < ArrMoldes.GetSize(); i++)
	{
		CBufMolde* pBufMolde = (CBufMolde*) ArrMoldes.GetAt(i);
		long lPrioridad = ArrPrioridad.GetAt(i);
		// Un molde puede hacer varias referencias
		for (int j=0; j < pBufMolde->m_pArrMolArt->GetSize(); j++)
		{
			CBufArtMol* pBufArtMol = (CBufArtMol*) pBufMolde->m_pArrMolArt->GetAt(j);
			ASSERT( pBufArtMol->IsKindOf( RUNTIME_CLASS( CBufArtMol ) ) );
  
			// Nos aseguramos de que no est� ya en la matriz
			BOOL bInMatrix = FALSE;
			for ( int k = 0; k < p_ArrInfoMolArt.GetSize(); k++)
			{
				CInfoMolArt* pInfoMolArt = (CInfoMolArt*) p_ArrInfoMolArt.GetAt(k);
				ASSERT( pInfoMolArt->IsKindOf( RUNTIME_CLASS( CInfoMolArt ) ) );
  
				if (pBufArtMol->m_sIDArticulo == pInfoMolArt->m_sIDArticulo )
				{
					bInMatrix = TRUE;
					break;
				}
			}
			if (!bInMatrix)
			{
				CBufArticulo* pBufArticulo = g_pCache->FindpArticulo(pBufArtMol->m_sIDArticulo);
				if (pBufArticulo) 
				{
					CInfoMolArt* pInfoMolArt = new CInfoMolArt;
					pInfoMolArt->m_sIDArticulo = pBufArtMol->m_sIDArticulo;
					pInfoMolArt->m_lPrioridad = lPrioridad;
					pInfoMolArt->m_lPorcHist = 0;
					p_ArrInfoMolArt.Add(pInfoMolArt);
				}
			}
		}

	}
	return p_ArrInfoMolArt.GetSize();

}

/*
// Recibe un codigo de maquina y para esta maquina rellena un Arrays con punteros
// a los moldes que puede recibir
int 
CCache::GetArrMolArt(const CString &p_sMaquina, CObArray &p_ArrInfoMolArt)
{
	CObArray ArrMoldes;
	CUIntArray ArrPrioridad;
	// Vaciamos los arrays
	for (int iB = 0; iB < p_ArrInfoMolArt.GetSize(); iB++)
	{
		CInfoMolArt* pInfoMolArt = (CInfoMolArt*) p_ArrInfoMolArt.GetAt(iB);
		delete pInfoMolArt;
	}
	p_ArrInfoMolArt.RemoveAll();
	// Buscamos la m�quina indicada
	CBufMaquina* pBufMaquina = FindpMaquina(p_sMaquina);
	if (pBufMaquina == NULL) return 0;
	BOOL bFinMaq = FALSE;
	for (int i=0; i < m_pArrMolMaq->GetSize() ; i++)
	{
		CBufMolMaq* pBufMolMaq = (CBufMolMaq*) m_pArrMolMaq->GetAt(i);
		if ( pBufMolMaq->m_sIDMaquina == p_sMaquina )
		{
			CBufMolde* pBufMolde = FindpMolde(pBufMolMaq->m_sIDMolde);
			ArrMoldes.Add(pBufMolde);
			ArrPrioridad.Add(pBufMolMaq->m_lPrioridad);
			bFinMaq = TRUE;
		}
		if (bFinMaq && pBufMolMaq->m_sIDMaquina != p_sMaquina) // para hacerlo m�s corto, ya que est� ordenado por maq.
			break;
	}
	// Ahora para cada molde buscamos su art�culo
	for ( i = 0; i < ArrMoldes.GetSize(); i++)
	{
		CBufMolde* pBufMolde = (CBufMolde*) ArrMoldes.GetAt(i);
		long lPrioridad = ArrPrioridad.GetAt(i);
		// Un molde puede hacer varias referencias
		for (int j=0; j < pBufMolde->m_pArrMolArt->GetSize(); j++)
		{
			CBufArtMol* pBufArtMol = (CBufArtMol*) pBufMolde->m_pArrMolArt->GetAt(j);
			ASSERT( pBufArtMol->IsKindOf( RUNTIME_CLASS( CBufArtMol ) ) );
  
			// Nos aseguramos de que no est� ya en la matriz
			BOOL bInMatrix = FALSE;
			for ( int k = 0; k < p_ArrInfoMolArt.GetSize(); k++)
			{
				CInfoMolArt* pInfoMolArt = (CInfoMolArt*) p_ArrInfoMolArt.GetAt(k);
				ASSERT( pInfoMolArt->IsKindOf( RUNTIME_CLASS( CInfoMolArt ) ) );
  
				if (pBufArtMol->m_sIDArticulo == pInfoMolArt->m_sIDArticulo )
				{
					bInMatrix = TRUE;
					break;
				}
			}
			if (!bInMatrix)
			{
				CBufArticulo* pBufArticulo = g_pCache->FindpArticulo(pBufArtMol->m_sIDArticulo);
				if (pBufArticulo) 
				{
					CInfoMolArt* pInfoMolArt = new CInfoMolArt;
					pInfoMolArt->m_sIDArticulo = pBufArtMol->m_sIDArticulo;
					pInfoMolArt->m_lPrioridad = lPrioridad;
					pInfoMolArt->m_lPorcHist = 0;
					p_ArrInfoMolArt.Add(pInfoMolArt);
				}
			}
		}

	}
	return p_ArrInfoMolArt.GetSize();

}
*/

CBufArticulo* 
CCache::FindpArticulo(const CString &p_sArticulo)
{
	CBufArticulo BufArt;
	BufArt.m_sID = p_sArticulo;
	int iRes = FindOrd(m_pArrArticulos, &BufArt, BufArt_Equal, BufArt_Bigger );
	if (iRes >= 0) return (CBufArticulo*) m_pArrArticulos->GetAt(iRes);
	return NULL;
}


CBufMolde* 
CCache::FindpMolde(const CString &p_sMolde)
{
	int iLim = m_pArrMoldes->GetSize();
	for(int i = 0; i < iLim ; i++)
	{
		CBufMolde* pBufMoldes = (CBufMolde*) m_pArrMoldes->GetAt(i);
		ASSERT_VALID(pBufMoldes);
		if (pBufMoldes->m_sID == p_sMolde) return pBufMoldes;
	}
	return NULL;
}

CBufMezcla* 
CCache::FindpMezcla(const CString &p_sMezcla)
{
	int iLim = m_pArrMezclas->GetSize();
	for(int i = 0; i < iLim ; i++)
	{
		CBufMezcla* pBufMezclas = (CBufMezcla*) m_pArrMezclas->GetAt(i);
		ASSERT_VALID(pBufMezclas);
		if (pBufMezclas->m_sID == p_sMezcla) return pBufMezclas;
	}
	return NULL;
}

CBufMaquina* 
CCache::FindpMaquina(const CString &p_sMaquina)
{
	int iLim = m_pArrMaquinas->GetSize();
	for(int i = 0; i < iLim ; i++)
	{
		CBufMaquina* pBufMaquinas = (CBufMaquina*) m_pArrMaquinas->GetAt(i);
		ASSERT_VALID(pBufMaquinas);
		if (pBufMaquinas->m_sID == p_sMaquina) return pBufMaquinas;
	}
	return NULL;

}

void 
CCache::SelectToBufOF(CBufOF *p_pBufOF)
{
	CBufOF* pBufOFAct;
	CBufOF* pBufOFUltSel = 0;

	// MaxInd y MinInd indican los �ndices del primero y el �ltimo
	// seleccionados. ActInd el de la Orden actual
	int MaxInd = -1;
	int MinInd = -1;
	int ActInd = -1;
	int TopInd = GetNumOF();
	// DesInd y HasInd marcan los l�mites de selecci�n finales
	int DesInd;
	int HasInd;

	for(int ind = 0; ind < TopInd; ind++)
	{
		pBufOFAct = GetpOFAt(ind);
		ASSERT_VALID (pBufOFAct);
		if (pBufOFAct == p_pBufOF)
			ActInd = ind;
		if (pBufOFAct->GetbSelected()) 
		{
			MaxInd = ind;
			if (MinInd == -1)
				MinInd = ind;		
		}
	}

	// Ahora calculamos DesInd y HasInd
	// Por defecto 
	DesInd = ActInd;	// Seleccionaremos desde la actual
	HasInd = ActInd;	// Hasta la misma
	if (MaxInd == - 1)	// Ninguna orden seleccionada
	{	
	} else // Una o varias �rdenes
	{
		if (ActInd < MinInd)	// Si actual menor que el m�nimo
		{
			DesInd = ActInd;	// Seleccionamos desde la seleccionada
			HasInd = MinInd;	// Hasta la actual
		} else	if (MinInd < ActInd  && ActInd < MaxInd) // Si entremedias
		{
		} else 
		{
			DesInd = MaxInd;	// Seleccionamos desde la �ltima
			HasInd = ActInd+1;	// Hasta la actual
		}
	}
	// Realizamos la verdadera selecci�n
	for(ind = DesInd; ind < HasInd; ind++)
	{
		pBufOFAct = GetpOFAt(ind);
		ASSERT_VALID (pBufOFAct);
	
		pBufOFAct->SetSelect(TRUE);
	}

}

void CCache::UnselectAllBufOF()
{
	int TopInd = GetNumOF();

	for(int ind = 0; ind < TopInd; ind++)
	{
		CBufOF* pBufOFAct = GetpOFAt(ind);
		ASSERT_VALID (pBufOFAct);
	
		pBufOFAct->SetSelect(FALSE);
	}
}


int CCache::SearchIndOF(const CString &p_sSearch)
{
	int TopInd = GetNumOF();
	int iLen = p_sSearch.GetLength();
	if (iLen <= 0) return -1;

	for(int ind = 0; ind < TopInd; ind++)
	{
		CBufOF* pBufOFAct = GetpOFAt(ind);
		if (pBufOFAct->m_sIDArticulo.Left(iLen) == p_sSearch) return ind;
	}
	return -1;
}

void 
CCache::RecalcOFs(CProg *p_pProg)
{
	CString sCodAnt = "";
	BOOL bRep = FALSE;
	long lCantAcum = 0;
	
	// Hacemos un ciclo por las OFs de Ayer
	int iNumOF = m_pArrOFAyer->GetSize();
	
	for(int ind = 0; ind < iNumOF; ind++)
	{
		CBufOF* pBufOF = (CBufOF*) m_pArrOFAyer->GetAt(ind);
		
		// Calculamos las cantidades acumuladas
	
		long lNumProg = p_pProg->GetlCantArt(pBufOF->m_sIDArticulo);
		pBufOF->m_dNoProg = pBufOF->m_dPendAcum - 
							pBufOF->m_dCantAlmac - 
							pBufOF->m_dCantCurso - 
//							pBufOF->m_dCantStockSeguridad -
							pBufOF->m_dCantObsoletos -
							(double) lNumProg;
		pBufOF->m_dNoCubierta = pBufOF->m_dPendAcum - 
							pBufOF->m_dCantAlmac - 
							pBufOF->m_dCantCurso - 
//							pBufOF->m_dCantStockSeguridad -
							pBufOF->m_dCantObsoletos;
							
			
	}
	
	// Hacemos un ciclo por las OFs
	iNumOF = GetNumOF();
	
	for( ind = 0; ind < iNumOF; ind++)
	{
		CBufOF* pBufOF = GetpOFAt(ind);
		
		// Calculamos las cantidades acumuladas
	
		CBufArticulo* pBufArt = g_pCache->FindpArticulo(pBufOF->m_sIDArticulo);
		
		long lNumProg = p_pProg->GetlCantArt(pBufOF->m_sIDArticulo);
		pBufOF->m_dNoProg = pBufOF->m_dPendAcum - 
							pBufOF->m_dCantAlmac - 
							pBufOF->m_dCantCurso - 
//							pBufOF->m_dCantStockSeguridad -
							pBufOF->m_dCantObsoletos -
							(double) lNumProg;
		pBufOF->m_dNoCubierta = pBufOF->m_dPendAcum - 
							pBufOF->m_dCantAlmac - 
							pBufOF->m_dCantCurso - 
//							pBufOF->m_dCantStockSeguridad -
							pBufOF->m_dCantObsoletos ;
			
		pBufOF->m_FecFab =
			p_pProg->CalcFecParaCant(pBufOF->m_sIDArticulo, (long) (pBufOF->m_dNoProg + (double) lNumProg));
		if (pBufOF->m_FecFab == p_pProg->GetFecFin())
		{
			pBufOF->m_lMargenMed = INT_MIN;
			pBufOF->m_lMargenMin = INT_MIN;
			pBufOF->m_lMargenMax = INT_MIN;
		} else if (pBufOF->m_FecFab == p_pProg->GetFecIni())
		{
			pBufOF->m_lMargenMed = INT_MAX;
			pBufOF->m_lMargenMin = INT_MAX;
			pBufOF->m_lMargenMax = INT_MAX;
		} else
		{
			CTimeSpan tsMargen = pBufOF->m_FecNec - pBufOF->m_FecFab;
			pBufOF->m_lMargenMed = tsMargen.GetTotalHours() - pBufArt->m_lMaduracionMed;
			pBufOF->m_lMargenMin = tsMargen.GetTotalHours() - pBufArt->m_lMaduracionMin;
			pBufOF->m_lMargenMax = tsMargen.GetTotalHours() - pBufArt->m_lMaduracionMax;
		}
		// Ahora que tenemos el margen, se lo pasamos a las OMs

		COMC* pOMC = p_pProg->GetpOMC(pBufOF->m_sIDArticulo);
		if (pOMC)
		{		
			if (pOMC->m_pOM)
			{
				if (pBufOF->m_lMargenMin != INT_MAX && pBufOF->m_lMargenMin != INT_MIN)
					if ( pOMC->m_pOM->GetTsMargen() >= (pBufOF->m_lMargenMin * TK_SEGS_HORA ))
						pOMC->m_pOM->SetTsMargen((CTimeSpan) (pBufOF->m_lMargenMin * TK_SEGS_HORA ));
			} else if (pOMC->m_pArrOM)
			{
				int iNumOM = pOMC->m_pArrOM->GetSize();
				for (int iD=0; iD< iNumOM; iD++)
				{
					COrdMaq* pOM = (COrdMaq*) pOMC->m_pArrOM->GetAt(iD);
					if (pBufOF->m_lMargenMin != INT_MAX && pBufOF->m_lMargenMin != INT_MIN)
						if ( pOM->GetTsMargen() >= (pBufOF->m_lMargenMin * TK_SEGS_HORA ))
								pOM->SetTsMargen((CTimeSpan) (pBufOF->m_lMargenMin * TK_SEGS_HORA ));
				}
			}


		}
	}
}
/////////////////////////////////////////////////////////////////////////////
// COFComb

IMPLEMENT_SERIAL(COFComb, CObject, 1)

COFComb::COFComb()
{
}


COFComb::~COFComb()
{
}


/////////////////////////////////////////////////////////////////////////////
// COFComb diagnostics

#ifdef _DEBUG
void COFComb::AssertValid() const
{
	CObject::AssertValid();
}

void COFComb::Dump(CDumpContext& dc) const
{
	CObject::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// COFComb serialization

void COFComb::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}


// Funciones de ordenacion por seccion

BOOL 
OFSeccion_Bigger( CObject* p_pA, CObject* p_pB )
{
	CBufOF* pOFa = (CBufOF*) p_pA;
	CBufOF* pOFb = (CBufOF*) p_pB;
	if (pOFa->m_lSeccion > pOFb->m_lSeccion ) return TRUE;
	if (pOFa->m_lSeccion == pOFb->m_lSeccion && 
		pOFa->m_sIDArticulo > pOFb->m_sIDArticulo ) return TRUE;
	if (pOFa->m_lSeccion == pOFb->m_lSeccion && 
		pOFa->m_sIDArticulo == pOFb->m_sIDArticulo &&
		pOFa->m_FecNec > pOFb->m_FecNec ) return TRUE;
	if (pOFa->m_lSeccion == pOFb->m_lSeccion && 
		pOFa->m_sIDArticulo == pOFb->m_sIDArticulo &&
		pOFa->m_FecNec == pOFb->m_FecNec ) return TRUE;
	return FALSE;

}

BOOL 
OFSeccion_Equal( CObject* p_pA, CObject* p_pB )
{
	CBufOF* pOFa = (CBufOF*) p_pA;
	CBufOF* pOFb = (CBufOF*) p_pB;
	return (pOFa->m_lSeccion == pOFb->m_lSeccion && 
			pOFa->m_sIDArticulo == pOFb->m_sIDArticulo &&
			pOFa->m_FecNec == pOFb->m_FecNec );
}

BOOL 
BufArt_Bigger( CObject* p_pA, CObject* p_pB )
{
	CBufArticulo* pBufArta = (CBufArticulo*) p_pA;
	CBufArticulo* pBufArtb = (CBufArticulo*) p_pB;
	return pBufArta->m_sID > pBufArtb->m_sID;
}

BOOL 
BufArt_Equal( CObject* pBufArtA, CObject* pBufArtB )
{
	CBufArticulo* pBufArta = (CBufArticulo*) pBufArtA;
	CBufArticulo* pBufArtb = (CBufArticulo*) pBufArtB;
	return pBufArta->m_sID == pBufArtb->m_sID;

}



void CCache::SelecToFec(CTime p_Fec)
{
	UnselectAllBufOF();
	
	int TopInd = GetNumOF();
	
	for(int ind = 0; ind < TopInd; ind++)
	{
		CBufOF* pBufOFAct = GetpOFAt(ind);
		ASSERT_VALID (pBufOFAct);
		
		if (pBufOFAct->m_FecNec <= p_Fec)
			pBufOFAct->SetSelect(TRUE);
		else
			pBufOFAct->SetSelect(FALSE);
	}
	
}

int CCache::GetiOFSec(int p_iOFAct, BOOL p_bNext )
{
	int iLim = GetNumOF();
	long lSec = GetpOFAt(p_iOFAct)->m_lSeccion;
	int i;
	if (p_bNext)
		for( i=p_iOFAct; i < iLim && lSec == GetpOFAt(i)->m_lSeccion; i++)
			;
		else
		{
			for( i=p_iOFAct; i >= 0 && lSec == GetpOFAt(i)->m_lSeccion; i--)
				;
			if (i > 0)
			{
				lSec = GetpOFAt(i)->m_lSeccion;
				for( i=i-1; i >= 0 && lSec == GetpOFAt(i)->m_lSeccion; i--)
					;
				i++;
			}	
		}
		return i;
}

int CCache::GetiOFArt(int p_iOFAct, BOOL p_bNext )
{
	int iLim = GetNumOF();
	CString sArt = GetpOFAt(p_iOFAct)->m_sIDArticulo;
	int i;
	if (p_bNext)
		for( i=p_iOFAct; i < iLim && sArt == GetpOFAt(i)->m_sIDArticulo; i++)
			;
		else
		{
			for( i=p_iOFAct; i >= 0 && sArt == GetpOFAt(i)->m_sIDArticulo; i--)
				;
			if (i > 0)
			{
				sArt = GetpOFAt(i)->m_sIDArticulo;
				for( i=i-1; i >= 0 && sArt == GetpOFAt(i)->m_sIDArticulo; i--)
					;
				i++;
			}	
		}
		
		return i;
}

void CCache::SetOrdenOF()
{
	CObArray* pObArrayOF;
	if (g_VerOF.m_OrdenOF == Seccion)
		pObArrayOF = m_pArrOFSeccion;
	else
		pObArrayOF = m_pArrOFs;
	
	
	m_pArrOFSel->RemoveAll();
	m_pArrOFAcum->RemoveAll();
	int iLim = pObArrayOF->GetSize();
	
	CBufOF* pBufOFNext;
	
	for(int i=0; i < iLim; i++)
	{
		CBufOF* pBufOF = (CBufOF*) pObArrayOF->GetAt(i);
		if (i < (iLim-1)) pBufOFNext = (CBufOF*) pObArrayOF->GetAt(i+1);
		else pBufOFNext = NULL;
		
		if (g_VerOF.m_bSelecFec)
			if (pBufOF->m_FecNec > g_VerOF.m_FecSelec ) continue;
			
		if (g_VerOF.m_bSoloNoProg)
			if (pBufOF->m_dNoProg <= 0) continue;
		
		m_pArrOFSel->Add(pBufOF);

		if ( pBufOFNext)
		{
			if ( pBufOF->m_sIDArticulo != pBufOFNext->m_sIDArticulo ||
				 pBufOF->m_FecNec != pBufOFNext->m_FecNec ) 
			{
				if  (g_VerOF.Selec())
				{
					if ( pBufOF->m_dNoProg > 0) 
					{
						m_pArrOFAcum->Add(pBufOF);
					}
				} else
				{
						m_pArrOFAcum->Add(pBufOF);
				}
			}
		} else
		{
			m_pArrOFAcum->Add(pBufOF);
		}
			
	}
}

void CCache::ActLimitMaq(const CString &p_sMolde, const CString &p_sMaq)
{
	CString sMsg;
	sMsg.Format( STRID( IDS_CONF_ACTLIMIT ), p_sMolde, p_sMaq);
	
	if (AfxMessageBox(sMsg, MB_YESNO)  != IDYES)
		return;
	
	if (m_RsMolMaq.IsOpen()) m_RsMolMaq.Close();
	if (!m_RsMolMaq.Open()) return;
	if (!m_RsMolMaq.CanUpdate())
	{	
		TRACE(STRID(IDS_ERR_NOACT));
		AfxMessageBox(STRID(IDS_ERR_NOACT));
		return;
	} 
	CBufMolde* pBufMolde = FindpMolde(p_sMolde);
	int iUltMolde = 1;
	if (pBufMolde)
	{
		int iLimMolMaq = pBufMolde->m_pArrMolMaq->GetSize();
		for (int j = 0; j < iLimMolMaq; j++)
		{
			CBufMolMaq* pBufMolMaq = (CBufMolMaq*) pBufMolde->m_pArrMolMaq->GetAt(j);
			ASSERT_VALID(pBufMolMaq);
			if (pBufMolMaq->m_lPrioridad >= iUltMolde) iUltMolde = pBufMolMaq->m_lPrioridad + 1;
		}
		
	} 
	// A�adimos el nuevo al cache
	CBufMolMaq* pBufMolMaq = new CBufMolMaq;
	pBufMolMaq->m_sIDMaquina = p_sMaq;
	pBufMolMaq->m_sIDMolde = p_sMolde;
	pBufMolMaq->m_pBufMaquina = FindpMaquina( p_sMaq );
	pBufMolMaq->m_lPrioridad = iUltMolde;
	pBufMolde->m_pArrMolMaq->Add(pBufMolMaq);
	
	// Y a la base de datos

	m_RsMolMaq.AddNew();
	
	m_RsMolMaq.m_IDMaquina = p_sMaq;
	m_RsMolMaq.m_IDMolde = p_sMolde;
	m_RsMolMaq.m_Prioridad = 0;
	
	m_RsMolMaq.Update();

	m_RsMolMaq.Close();
	
}

static int s_iGetCambioMolde_count = 0;
CBufCambiosMoldes*
CCache::GetFirstCambioMolde(CTime p_Fec)
{

	m_pArrCambMold->RemoveAll();
	
	m_RsCambiosMoldes.m_strFilter = "";
	m_RsCambiosMoldes.m_strSort = "Contador";
                                
	if (m_RsCambiosMoldes.IsOpen()) m_RsCambiosMoldes.Close();
	if (!m_RsCambiosMoldes.Open()) return NULL;
	if (!m_RsCambiosMoldes.GetRecordCount()) return NULL;
	
	m_RsCambiosMoldes.MoveFirst();
		 		
	while (!m_RsCambiosMoldes.IsEOF())
	{   
		CBufCambiosMoldes* pNewCM = new CBufCambiosMoldes(m_RsCambiosMoldes);
		m_pArrCambMold->Add(pNewCM);
		m_RsCambiosMoldes.MoveNext();
	}            
	m_RsCambiosMoldes.Close();
	m_RsCambiosMoldes.m_strFilter = "";
	s_iGetCambioMolde_count = 0;

	return GetNextCambioMolde(p_Fec);
}


CBufCambiosMoldes*
CCache::GetNextCambioMolde(CTime p_Fec)
{
	if (s_iGetCambioMolde_count < m_pArrCambMold->GetSize())
	{
		s_iGetCambioMolde_count++;
		return (CBufCambiosMoldes*) m_pArrCambMold->GetAt(s_iGetCambioMolde_count-1);
	}
	else
		return NULL;
}

// UpdateMezclasPlanta : Actualizar los datos de Mezcla de plantas
void
CCache::UpdateMezclasPlanta()
{
    if (m_RsMezclasPlanta.IsOpen())
		m_RsMezclasPlanta.Close();
	m_RsMezclasPlanta.m_strFilter = "";

	if (m_RsMezclasPlanta.Open())
	{
		if (!m_RsMezclasPlanta.GetRecordCount()) return;
		m_RsMezclasPlanta.MoveFirst();
 		
		while (!m_RsMezclasPlanta.IsEOF())
		{
			for (int i = 0; i < m_pArrMezclas->GetSize(); i++)
			{
				CBufMezcla* pBufMezcla = (CBufMezcla*) m_pArrMezclas->GetAt(i);
				ASSERT( pBufMezcla->IsKindOf( RUNTIME_CLASS( CBufMezcla ) ) );
				if (pBufMezcla->m_sID == m_RsMezclasPlanta.m_ID)
					pBufMezcla->m_lCantPlanta = m_RsMezclasPlanta.m_Cantidad;
	
			}
			m_RsMezclasPlanta.MoveNext();
		}
	}            
	m_RsMezclasPlanta.Close();
}

// CargaLisMezclas : Carga la tabla del listado de Mezclas desde un Array de BufLisMezclas
void CCache::CargaLisMezclas(CObArray* p_pArrBufLisMezclas)
{
	if (m_RsLisMezclas.IsOpen())
		m_RsLisMezclas.Close();
	// Borramos lo que pueda haber de antes
	CString strCmd;
	strCmd.Format("DELETE * FROM Lis_Mezclas");
	m_pDB->ExecuteSQL(strCmd);
	// Insertamos un registro "Dummy" porque las fechas no se insertan bien en Recordsets vac�os
	strCmd.Format("INSERT INTO Lis_Mezclas VALUES ('***DUMMY', #01/01/01#, '0', '0', 0, 0)");
	m_pDB->ExecuteSQL(strCmd);

	
	m_RsLisMezclas.m_strFilter = "";
	
	if (!m_RsLisMezclas.Open()) return;
	for (int i = 0; i < p_pArrBufLisMezclas->GetSize(); i++)
	{
		CBufLisMezclas* pBufLisMezclas = (CBufLisMezclas*) p_pArrBufLisMezclas->GetAt(i);
		ASSERT( pBufLisMezclas->IsKindOf( RUNTIME_CLASS( CBufLisMezclas ) ) );
		m_RsLisMezclas.AddNew();

		m_RsLisMezclas.m_IDLocal = pBufLisMezclas->m_sIDLocal;
		m_RsLisMezclas.m_IDArticulo = pBufLisMezclas->m_sIDArticulo;
		m_RsLisMezclas.m_IDCliente = pBufLisMezclas->m_sIDCliente;
		m_RsLisMezclas.m_FecIni = pBufLisMezclas->m_FecIni;
		m_RsLisMezclas.m_Mezcla = pBufLisMezclas->m_lMezcla;
		m_RsLisMezclas.m_Cant = pBufLisMezclas->m_lCant;
		
		m_RsLisMezclas.Update();
	}

	m_RsLisMezclas.Close();

	// Borramos el registro "Dummy"
	strCmd.Format("DELETE * FROM Lis_Mezclas WHERE [IDLocal] = '***DUMMY'");
	m_pDB->ExecuteSQL(strCmd);

}

void CCache::AddHistorico(COrdMaq* p_pOM)
{
	BOOL bVacio = !m_RsHistorico.GetRecordCount();
	if (bVacio)
	{
		m_RsHistorico.Close();
		CString strCmd;
		// Insertamos un registro "Dummy" porque las fechas no se insertan bien en Recordsets vac�os
		strCmd.Format("INSERT INTO Historico VALUES ('***DUMMY', ' ', #01/01/01#, #01/01/01#, 0, ' ')");
		m_pDB->ExecuteSQL(strCmd);
		m_RsHistorico.Open();
	}
	
	m_RsHistorico.m_strFilter = "";
	
    TRY
    {
		
		m_RsHistorico.AddNew();
		
		m_RsHistorico.m_IDMolde = p_pOM->GetsMolde();
		m_RsHistorico.m_IDMaquina = p_pOM->GetsMaquina();
		m_RsHistorico.m_FecIni = p_pOM->GetFecIni();
		m_RsHistorico.m_FecFin = p_pOM->GetFecFin();
		m_RsHistorico.m_Cantidad = p_pOM->GetlCantidad();
		m_RsHistorico.m_IDArticulo = p_pOM->GetsID();
		m_RsHistorico.m_Cadencia = p_pOM->GetdCadencia();
		m_RsHistorico.m_Rechazos = p_pOM->GetdChatarras();
		
		m_RsHistorico.Update();
	}
	    CATCH_ALL(e)
    {
		AfxMessageBox("El Hist�rico no se Actualiz�, normalmente por tratar de guardar el mismo bloque 2 veces.");
	}
    END_CATCH_ALL

	if (bVacio)
	{
		CString strCmd;
		// Borramos el registro "Dummy"
		strCmd.Format("DELETE * FROM Historico WHERE [IDMolde] = '***DUMMY'");
		m_pDB->ExecuteSQL(strCmd);
	}


}
