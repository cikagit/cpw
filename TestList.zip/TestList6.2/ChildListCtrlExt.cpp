// ChildListCtrlExt.cpp : implementation file
//

#include "stdafx.h"
#include "ChildListCtrlExt.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CChildListCtrlExt

CChildListCtrlExt::CChildListCtrlExt()
{
}

CChildListCtrlExt::~CChildListCtrlExt()
{
}


BEGIN_MESSAGE_MAP(CChildListCtrlExt, CListCtrlExt)
	//{{AFX_MSG_MAP(CChildListCtrlExt)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CChildListCtrlExt diagnostics

/////////////////////////////////////////////////////////////////////////////
// CChildListCtrlExt message handlers
