//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TestList6.rc
//
#if _MSC_VER <= 1200
#ifndef IDR_MANIFEST
#define IDR_MANIFEST                    1
#endif
#ifndef	RT_MANIFEST
#define RT_MANIFEST                     24
#endif
#endif // _MSC_VER <= 1200
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_TESTLITYPE                  129
#define IDC_DATE                        1002
#define IDC_COMBO                       1003
#define IDC_EDIT                        1004
#define ID_VIEW_REFRESH                 32771

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
